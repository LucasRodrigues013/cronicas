

<!-- WORLDROOT LIVRO-VI-C01 PARTE I / LVI-C01-PI-D538-REAUTHORIZED-R2-AUTHOR-SOURCE -->

CRÔNICAS DE UM NOVO MUNDO · WORLDROOT · HISTÓRIA VIVA

A ERA DAS NOVE COROAS

LIVRO VI — AS COROAS PARTIDAS

CAPÍTULO 1 — O CRIADOR E A CIDADE DAS MIL FONTES

PARTE I DE V · A CIDADE QUE CABIA EM UM SONHO

“Alguns homens atravessam o mundo para conquistar cidades. Outros acordam certa manhã e descobrem que a cidade que amam pode transformar o mundo inteiro.”

CALENDÁRIO DO HORIZONTE

Dia acumulado

538

Calendário

Ano II · Mês 06 · Dia 23

Local de abertura

Casa do Jardim Branco

Primeira cena

06h08 · Amanhecer

Continuidade: Livro V encerrado no Dia 537, às 23h46. Esta nova Parte I permanece rascunho narrativo até a próxima escolha autoral.

Na noite anterior, o céu de Três Arcos havia recebido constelações que não existiam.

Um homem capaz de dar forma à matéria transformara, por algumas horas, o firmamento numa celebração de pessoas livres.

Depois apagara a luz.

Dormira abraçado à mulher que amava.

E, enquanto ele descansava, comerciantes fecharam suas lojas, guardas trocaram turnos, crianças tiveram sonhos e trabalhadores prepararam o dia seguinte.

O mundo continuara.

Agora, pela primeira vez em muito tempo, aquele homem acordaria com uma ideia que não começaria numa arma, numa guerra ou numa expedição.

Começaria com uma janela aberta.

Uma cidade despertando.

E um problema profundamente pessoal com o próprio despertador.

I — O homem que podia dobrar a realidade, mas não conseguia negociar com a manhã

DIA 538 · 06h08 · CASA DO JARDIM BRANCO — QUARTO

Plic.

Lucas franziu a testa.

Plic.

Abriu um olho.

Uma gota de água havia caído em seu nariz.

A segunda acertou sua sobrancelha.

A terceira encontrou a ponta de sua orelha.

Por alguns segundos, ele permaneceu perfeitamente imóvel.

Então ergueu lentamente os olhos.

Uma pequena folha, carregada pela brisa através da janela entreaberta, havia parado junto ao vaso suspenso acima da cabeceira. A chuva da madrugada deixara algumas gotas em suas bordas.

Outra gota se desprendeu.

Plic.

LUCAS — ...Eu estou sendo atacado.

Silêncio.

Ele observou a folha.

A folha não demonstrou arrependimento.

LUCAS — Dentro da minha própria residência.

Uma voz familiar surgiu em sua percepção.

SISTEMA — Bom dia, Criador.

LUCAS — Não começa.

SISTEMA — Você acaba de sofrer quatro impactos de água, nenhum deles potencialmente perigoso.

Lucas estreitou os olhos.

LUCAS — QUATRO IMPACTOS SÃO QUATRO ATAQUES!

SISTEMA — Deseja registrar uma declaração de guerra contra a vegetação doméstica?

LUCAS — EU DESEJO DORMIR!

Foi nesse instante que alguma coisa se moveu ao lado dele.

Miren.

A esposa estava deitada de lado, com uma mão descansando sobre o peito de Lucas e os cabelos espalhados pelo travesseiro. A claridade começava a iluminar seu rosto.

Ela abriu os olhos devagar.

MIREN — ...Você está brigando com as plantas?

Lucas virou a cabeça.

O rosto mudou imediatamente.

A indignação deu lugar a um sorriso.

LUCAS — Bom dia, meu amor.

Miren piscou.

Olhou para ele.

Depois para a folha suspensa.

MIREN — Bom dia.

Uma pausa.

MIREN — Por que está molhado?

Lucas apontou solenemente para cima.

LUCAS — Sofri uma tentativa de assassinato.

Ela observou o vaso.

Depois o marido.

MIREN — Por uma folha?

LUCAS — UMA FOLHA EXTREMAMENTE HOSTIL!

Miren soltou uma risada sonolenta.

Aproximou-se e beijou o rosto dele.

MIREN — Coitado do meu marido.

Lucas abriu os braços, satisfeito.

LUCAS — Finalmente, empatia!

Ela segurou seu queixo e aproximou o rosto.

MIREN — Quer que eu prenda a folha?

LUCAS — Quero justiça.

Miren beijou seus lábios.

Demoradamente.

Quando se afastou, Lucas parecia ter esquecido a existência de toda a botânica conhecida.

MIREN — Melhor?

Ele piscou duas vezes.

LUCAS — ...Qual era a pergunta?

Miren começou a gargalhar.

A madrugada havia sido tranquila.

Depois da celebração na cidade, os dois tinham conversado mais um pouco, guardado a pequena peça de metal oferecida por Brannik e deixado, sobre uma mesa próxima, os desenhos que Miren ainda pretendia examinar.

Nenhum deles abrira aqueles papéis novamente.

Tinham passado o restante da noite juntos.

E, naquela manhã, Lucas gostava da sensação de não precisar correr para resolver uma emergência.

Miren se espreguiçou.

MIREN — Você acordou cedo.

LUCAS — Estava pensando em correr.

MIREN — Outra vez?

LUCAS — Minha senhora, estou construindo um histórico respeitável de comportamento saudável.

MIREN — Você também está construindo um histórico de comer pão suficiente para alimentar uma pequena patrulha depois de cada corrida.

Lucas levou a mão ao peito.

LUCAS — O CORPO DE UM ATLETA EXIGE COMBUSTÍVEL!

Uma faixa discreta de NÓX se movimentou sobre o antebraço dele.

NÓX — O consumo de pão não constitui evidência de desempenho atlético.

Lucas virou lentamente a cabeça.

LUCAS — NÓX.

NÓX — Sim?

LUCAS — Você estava esperando uma oportunidade para falar isso?

NÓX — A oportunidade apresentou-se espontaneamente.

O SISTEMA acrescentou:

SISTEMA — O usuário possui capacidade de manifestação material extraordinária, mas ainda não desenvolveu resistência emocional adequada a comentários sobre seus hábitos alimentares.

LUCAS — VOCÊS DOIS SÃO UMA ORGANIZAÇÃO CRIMINOSA!

Miren já ria tanto que precisou esconder o rosto no travesseiro.

Quando o riso diminuiu, ela permaneceu observando Lucas.

MIREN — Vai correr por onde?

LUCAS — Ainda não decidi. Talvez pela Grande Avenida. Depois pelo mercado, o Anel dos Ofícios... dar uma volta pelos bairros.

MIREN — Só não tente chegar ao Campo Aurora correndo antes do café.

Lucas abriu um sorriso suspeito.

LUCAS — Tecnicamente...

MIREN — Lucas.

LUCAS — ...eu tenho pernas excelentes.

MIREN — E um aeroporto a muitos quilômetros daqui.

Ele ergueu as mãos.

LUCAS — ESTÁ BEM! CORRIDA URBANA!

Miren sorriu, satisfeita.

Mas, quando ele começou a se levantar, segurou-lhe o pulso.

Lucas parou.

Ela não disse nada imediatamente.

Apenas o puxou de volta por um instante.

Ele se inclinou, e os dois se beijaram outra vez.

MIREN — Volte para tomar café comigo.

Lucas acariciou seu rosto.

LUCAS — Sempre que eu puder.

Miren sorriu.

MIREN — E compre alguma coisa gostosa no caminho.

Ele abriu os olhos com indignação teatral.

LUCAS — AH! ENTÃO ERA ESSE O VERDADEIRO OBJETIVO DO BEIJO!

MIREN — Você descobriu meu plano.

LUCAS — UMA MULHER EXTREMAMENTE PERIGOSA!

Ela o puxou para mais um beijo rápido.

MIREN — E você gosta.

Lucas sorriu.

LUCAS — Gosto pra caralho.

Às 06h26, ele terminou de se vestir.

Calças leves, calçado apropriado para corrida, uma camisa confortável e o pequeno reprodutor musical que costumava utilizar.

NÓX acomodou sua estrutura numa forma discreta, sem prejudicar seus movimentos.

A katana e os demais equipamentos permaneceriam disponíveis conforme seus vínculos habituais. Não havia motivo para sair ostensivamente armado para comprar pão.

Ao passar pelo corredor, Lucas encontrou Rumo.

O autômato estava junto à janela, examinando uma pequena bandeja de peças de madeira.

Não parecia ocupado com nenhuma tarefa da residência.

LUCAS — Bom dia, meu querido!

Rumo ergueu a cabeça.

RUMO — Bom dia, Lucas.

Lucas olhou para a bandeja.

LUCAS — O que está fazendo?

RUMO — Estou decidindo como organizar estas peças.

LUCAS — Algum projeto?

RUMO — Talvez.

Lucas ergueu uma sobrancelha.

Rumo prosseguiu:

RUMO — Ontem escrevi uma palavra no céu.

Lucas sorriu.

LUCAS — Eu lembro.

RUMO — Escolher.

O autômato olhou novamente para as peças.

RUMO — Hoje quero experimentar fazer alguma coisa sem ter decidido antes para que ela servirá.

Lucas permaneceu em silêncio.

Depois sorriu ainda mais.

LUCAS — Isso é perigosíssimo.

Rumo inclinou a cabeça.

RUMO — Por quê?

LUCAS — Porque foi exatamente assim que Brannik começou.

O autômato considerou a informação.

RUMO — Então talvez seja melhor utilizar ferramentas pequenas.

Lucas soltou uma gargalhada.

LUCAS — UMA EXCELENTE PRIMEIRA MEDIDA!

Antes de sair, apontou para a bandeja.

LUCAS — Depois quero ver o que você inventou.

Rumo assentiu.

RUMO — Se eu gostar do resultado, mostrarei.

Lucas parou por um instante.

Então abriu um sorriso genuinamente orgulhoso.

LUCAS — Combinado.

E saiu.

O jardim ainda guardava a umidade da madrugada.

Pequenas gotas brilhavam nas folhas, e a água do lago refletia as primeiras faixas douradas do amanhecer.

Lucas respirou fundo.

O ar estava fresco.

Cheirava a grama úmida, flores e terra.

Ao longe, Três Arcos começava a despertar.

O Criador alongou os braços.

Flexionou os joelhos.

Deu dois pequenos saltos.

E sorriu.

LUCAS — Certo, mundo.

Ajustou os fones.

Uma música começou.

LUCAS — Vamos ver o que você tem para mim hoje.

E começou a correr.

II — Uma cidade que não precisava mais pedir licença para existir

DIA 538 · 06h47 · GRANDE AVENIDA DOS TRÊS HORIZONTES

Três Arcos estava linda.

Não perfeita.

Não concluída.

Mas viva.

O sol aparecia entre telhados de cerâmica, torres de pedra clara e fachadas cujos ornamentos haviam sido trabalhados por artesãos de diferentes povos.

Em algumas construções, bandeiras da Cidade Livre se movimentavam acima de balcões.

Em outras, pequenos jardins pendiam das janelas.

A Grande Avenida dos Três Horizontes estendia-se diante de Lucas, com suas vias restauradas, travessias e corredores que já haviam recebido anos de esforço, discussão, experiência e invenções.

Carroças comerciais avançavam em ritmo constante.

Um pequeno grupo de ciclistas passou por um trecho apropriado.

Pessoas caminhavam para o trabalho.

Uma mulher organizava flores diante de uma loja.

Dois aprendizes discutiam qual deles havia chegado primeiro à oficina.

E, numa esquina, um legionário tentava convencer um cachorro enorme a devolver a luva que havia roubado.

Lucas reduziu o ritmo.

Observou.

O cachorro segurava a luva com a expressão satisfeita de quem acabara de vencer uma batalha de importância histórica.

LEGIONÁRIO — Devolva.

O cachorro abanou o rabo.

LEGIONÁRIO — Isso pertence ao equipamento de serviço.

O cachorro sentou.

LEGIONÁRIO — Não é uma negociação.

Lucas tirou um dos fones.

LUCAS — BOM DIA, SOLDADO!

O legionário se virou.

Reconheceu-o imediatamente.

LEGIONÁRIO — Bom dia, Lucas!

Lucas apontou para o cachorro.

LUCAS — SITUAÇÃO DO FRONT?!

O homem respirou fundo.

LEGIONÁRIO — Perdemos uma luva.

LUCAS — BAIXAS?!

LEGIONÁRIO — Nenhuma, até agora.

LUCAS — ENTÃO AINDA HÁ ESPERANÇA!

Uma gargalhada veio da floricultura.

A dona do estabelecimento apareceu à porta.

FLORISTA — Ele faz isso toda manhã! Pega alguma coisa e espera que alguém venha brincar.

Lucas olhou novamente para o animal.

LUCAS — Ah.

Abaixou-se.

O cachorro o encarou.

Lucas estendeu a mão.

LUCAS — Escuta aqui, meu consagrado.

O animal inclinou a cabeça.

LUCAS — Você está segurando material militar de uma instituição respeitadíssima.

O cachorro continuou abanando o rabo.

LUCAS — E eu respeito profundamente sua capacidade de negociação.

O animal se aproximou.

Lucas retirou do chão um pequeno graveto caído.

Mostrou-o.

O cachorro abandonou imediatamente a luva.

Agarrou o graveto.

E saiu trotando, glorioso.

O legionário recuperou seu equipamento.

Por alguns segundos, permaneceu olhando para Lucas.

LEGIONÁRIO — ...Obrigado.

Lucas ergueu o queixo.

LUCAS — ANOS DE EXPERIÊNCIA ESTRATÉGICA!

NÓX comentou:

NÓX — O cachorro aceitou uma troca de objetos sem valor militar equivalente.

LUCAS — É ASSIM QUE FUNCIONA A DIPLOMACIA, PARCEIRO!

A florista começou a rir novamente.

O legionário agradeceu e voltou ao trabalho.

Lucas recolocou o fone.

E continuou correndo.

Mas a cena ficou com ele.

Não pela luva.

Pelo legionário.

Pelo cachorro.

Pela mulher que conhecia os hábitos do animal.

Pelas pessoas que se cumprimentavam sem precisar olhar para o Criador em busca de instruções.

A Cidade Livre possuía uma rotina própria.

E ele adorava fazer parte dela.

07h03 · MERCADO DOS OFÍCIOS — PASSAGEM CENTRAL

O mercado já estava movimentado.

O cheiro de pão quente chegou primeiro.

Depois especiarias.

Frutas maduras.

Madeira recém-cortada.

Metal aquecido.

Uma barraca vendia pequenas peças de vidro colorido. Outra expunha utensílios de cerâmica. Havia tecidos de diferentes regiões, ferramentas, livros encadernados à mão e alimentos que Lucas ainda não sabia identificar sem perguntar.

Passou por uma banca de frutas.

O vendedor ergueu a mão.

VENDEDOR — Bom dia, Criador!

Lucas respondeu sem parar:

LUCAS — BOM DIA, DONO DAS MAÇÃS!

VENDEDOR — HOJE SÃO PERAS!

Lucas diminuiu a corrida.

Virou a cabeça.

LUCAS — ENTÃO MUDE A PLACA!

VENDEDOR — A PLACA DIZ FRUTAS!

Lucas ficou imóvel por uma fração de segundo.

Depois começou a rir.

LUCAS — ...O senhor me derrotou.

O vendedor abriu os braços.

VENDEDOR — Acontece!

Mais adiante, Lucas encontrou uma pequena aglomeração.

Não era uma emergência.

Uma mulher conduzia um carrinho carregado com cestas de pão. A roda dianteira havia ficado presa no encaixe irregular entre duas superfícies de uma passagem lateral.

Ela tentava libertá-la enquanto outros clientes precisavam contornar o veículo.

Um aprendiz se aproximou para ajudar.

APRENDIZ — Se levantar por este lado...

MULHER — Vai derrubar as cestas.

APRENDIZ — Então pelo outro?

MULHER — Vai bater na banca.

Lucas se aproximou.

LUCAS — Podemos tentar uma terceira possibilidade.

A mulher o reconheceu.

MULHER — Lucas?

Ele sorriu.

LUCAS — O próprio. Especialista internacional em ficar preso onde não deveria.

Ela riu, apesar da irritação.

O aprendiz apontou para a roda.

APRENDIZ — Está encaixada.

Lucas se ajoelhou.

Examinou a passagem.

A superfície principal da avenida estava em boas condições.

O problema era a pequena transição entre a área de pedestres e o acesso antigo da banca.

LUCAS — Ah, entendi.

A mulher cruzou os braços.

MULHER — Já avisei sobre isso.

Ele ergueu os olhos.

LUCAS — Faz tempo?

MULHER — Algumas semanas. Disseram que iam examinar. Mas não sou a única pessoa com problema de passagem no mercado.

Lucas assentiu.

Não tentou justificar a demora.

LUCAS — Posso ajudar com o carrinho primeiro?

MULHER — Pode.

Lucas colocou a mão sob a estrutura.

Ergueu-a com uma facilidade absurda, sustentando o peso com uma única mão, enquanto o aprendiz reposicionava a roda.

A mulher observou.

Depois olhou para os braços dele.

MULHER — Pelos deuses...

LUCAS — Eu treino.

O SISTEMA surgiu discretamente.

SISTEMA — A explicação é tecnicamente verdadeira, porém insuficiente.

Lucas ignorou.

O carrinho voltou ao chão.

Inteiro.

As cestas permaneceram em seus lugares.

MULHER — Obrigada.

LUCAS — Disponha.

Ele examinou novamente o desnível.

Poderia eliminá-lo instantaneamente.

Não havia dificuldade de poder.

Mas aquela passagem era utilizada diariamente por pessoas que conheciam melhor o funcionamento do mercado.

LUCAS — Posso perguntar uma coisa?

A mulher assentiu.

LUCAS — Se corrigirmos esse encaixe, resolveremos o problema?

Ela apontou mais adiante.

MULHER — O meu, provavelmente. Mas aquela passagem fica apertada quando as carroças de abastecimento chegam. E ali, perto da banca azul, a água fica acumulada quando chove.

O aprendiz acrescentou:

APRENDIZ — Minha avó evita esse caminho. Tem degraus demais.

Lucas acompanhou os gestos.

O olhar mudou.

Não ficou triste.

Ficou atento.

Observou a rua como se estivesse enxergando alguma coisa por trás das pedras.

LUCAS — Entendi.

A mulher pareceu desconfiada.

MULHER — Vai fazer alguma coisa gigantesca?

Lucas abriu um sorriso.

LUCAS — Minha senhora, eu saí de casa para correr.

Ela o examinou.

MULHER — Isso não respondeu.

O aprendiz começou a rir.

NÓX respondeu:

NÓX — A preocupação dela possui fundamento histórico.

LUCAS — VOCÊS ESTÃO TODOS ORGANIZADOS CONTRA MIM?!

A mulher riu.

Mas Lucas permaneceu mais alguns segundos observando a passagem.

Uma pequena irregularidade.

Uma rua movimentada.

Um mercado que já funcionava.

E pessoas cuja vida poderia ser muito melhor sem que precisassem abandonar o lugar.

Antes de partir, perguntou o nome da vendedora.

MULHER — Salma.

LUCAS — Prazer, Salma. Espero encontrar você outra vez sem precisar levantar seu carrinho.

SALMA — Eu também.

Ele voltou a correr.

E, dessa vez, diminuiu o volume da música.

Queria ouvir a cidade.

III — As coisas que ainda não existiam entre os lugares que já existiam

DIA 538 · 07h24 · ANEL DOS OFÍCIOS — RUA DAS FORJAS

O som dos martelos começou antes de Lucas alcançar a primeira oficina.

Tang.

Tang. Tang.

O Anel dos Ofícios estava acordado havia bastante tempo.

Forjas lançavam pequenas colunas de fumaça pelas chaminés. Artesãos carregavam madeira, aprendizes varriam os pátios e uma equipe preparava materiais para uma construção próxima.

Um dos autômatos da Malha Aurora transportava peças pesadas sob orientação de dois profissionais.

O trabalhador à frente indicou a posição da carga.

TRABALHADOR — Mais para a esquerda.

O autômato ajustou o movimento.

TRABALHADOR — Isso. Agora pode baixar.

A carga desceu suavemente.

Lucas observou com satisfação.

A Malha Aurora já possuía milhares de unidades, e algumas delas participavam de serviços reais da cidade. Vértice coordenava sua atuação técnica, sem substituir os responsáveis pelos trabalhos.

Lucas conhecia aquela conquista.

Acompanhara sua evolução.

Não precisava descobrir novamente que máquinas podiam ajudar pessoas.

O interessante era observar o que as pessoas estavam começando a fazer com aquela capacidade.

Perto de uma oficina, um artesão de cabelos grisalhos examinava a armação de uma roda.

Um menino acompanhava seus movimentos.

MENINO — Mas por que não fazemos tudo com os autômatos?

O artesão deu uma pequena risada.

ARTESÃO — Porque eu ainda quero ensinar você a fazer uma roda.

O menino pareceu considerar.

MENINO — Mas eles fazem mais rápido.

ARTESÃO — Então faça uma que seja boa o suficiente para competir.

Lucas passou ao lado deles.

Parou.

Deu dois passos para trás.

LUCAS — ...Esse é o espírito!

O artesão ergueu a cabeça.

ARTESÃO — Lucas?

LUCAS — Bom dia!

O menino arregalou os olhos.

MENINO — Você é o Criador?!

Lucas abriu os braços.

LUCAS — DEPENDE! A RODA ESTÁ QUEBRADA?!

A criança começou a rir.

MENINO — Não!

LUCAS — ENTÃO SOU APENAS UM HOMEM CORRENDO!

O artesão sorriu.

ARTESÃO — Quer examinar o trabalho dele?

Lucas aproximou-se imediatamente.

O menino mostrou uma pequena roda de madeira, ainda inacabada.

Uma peça simples.

Com marcas irregulares.

O encaixe central precisava de acabamento.

Lucas a girou cuidadosamente entre os dedos.

LUCAS — Você fez isso?

MENINO — Fiz.

LUCAS — Sozinho?

MENINO — Meu mestre ajudou no começo.

Lucas assentiu.

LUCAS — Ótimo. E o que pretende fazer depois?

O menino pareceu desconcertado.

MENINO — Outra roda.

Lucas examinou a primeira.

Depois abriu um sorriso de orelha a orelha.

LUCAS — MARAVILHOSO!

O artesão começou a rir.

LUCAS — Porque aí você terá duas!

MENINO — Sim!

LUCAS — E SABE O QUE PODE FAZER COM DUAS RODAS?!

O menino abriu os olhos.

MENINO — Uma carroça pequena?

Lucas ficou imóvel.

Depois levou lentamente a mão ao peito.

LUCAS — ...Esse garoto tem futuro.

NÓX respondeu:

NÓX — A utilização de duas rodas numa estrutura móvel já constitui tecnologia estabelecida.

LUCAS — EU ESTOU INCENTIVANDO A PRÓXIMA GERAÇÃO DE ENGENHEIROS!

O artesão gargalhou.

O menino também.

Lucas devolveu a peça.

LUCAS — Continua. Quero ver sua carroça quando estiver pronta.

O garoto assentiu com entusiasmo.

Lucas voltou à corrida.

Mas não sem ouvir o artesão comentar atrás dele:

ARTESÃO — Agora vou ter de ensinar o menino a construir o resto da carroça.

O sorriso de Lucas aumentou.

À medida que se afastava das oficinas, a cidade mudava de aparência.

A grandiosidade da Grande Avenida dava lugar a caminhos menores.

Sobrados se erguiam próximos uns dos outros.

Havia sacadas com vasos floridos, pequenas pontes de pedra sobre canais antigos, muros cobertos de trepadeiras e fachadas de diferentes épocas.

Em alguns lugares, a arquitetura tinha a elegância planejada das construções recentes.

Em outros, as casas pareciam ter sido erguidas conforme suas famílias encontravam recursos e oportunidades.

Lucas gostava daquela mistura.

Era impossível caminhar por Três Arcos e acreditar que a cidade pertencia a uma única pessoa.

O próprio desenho das ruas parecia contar histórias diferentes.

Uma curva existia porque uma construção antiga antecedera a avenida.

Uma praça havia crescido onde comerciantes começaram a se reunir.

Uma escadaria ligava dois níveis de terreno que, muitos anos antes, provavelmente pareciam impossíveis de conectar.

O mundo tinha memória.

E Lucas começou a pensar que o futuro precisaria aprender a conversar com ela.

07h39 · BAIRROS RESIDENCIAIS — PRAÇA DAS JANELAS ABERTAS

A praça era pequena.

Uma fonte de pedra ocupava o centro.

A água escorria por três bacias circulares, caindo num reservatório cercado por bancos.

Havia árvores.

Flores.

Um pequeno espaço onde crianças brincavam.

E uma senhora sentada junto à fonte, alimentando pássaros com migalhas apropriadas, que trazia numa sacola.

Lucas diminuiu o passo.

A música terminou.

Ele retirou os fones.

E ouviu o som da água.

Ficou ali por alguns instantes.

Observando a fonte.

Era bonita.

Talvez não fosse a mais impressionante de Três Arcos.

Certamente não possuía as maravilhas de AERÚN ou a escala dos grandes projetos que ajudara a construir.

Mas havia quatro pessoas sentadas à sua sombra.

Uma criança estava desenhando num pedaço de papel.

Um homem lia um livro.

E duas mulheres conversavam sobre algo que as fazia rir.

Lucas sorriu.

Aquele lugar não precisava ser monumental para funcionar.

Precisava existir.

A senhora junto à fonte percebeu sua presença.

SENHORA — Está cansado, rapaz?

Lucas virou a cabeça.

LUCAS — EU?! JAMAIS!

Ela o examinou.

Observou sua camisa úmida.

Depois as mãos apoiadas na cintura.

SENHORA — Então por que está respirando como meu velho cavalo quando puxava pedras?

Lucas abriu a boca.

Fechou.

O SISTEMA surgiu imediatamente.

SISTEMA — Uma comparação particularmente precisa, considerando a atividade atual.

LUCAS — VOCÊS COMBINARAM ISSO?!

A senhora começou a rir, sem saber a quem ele se dirigia.

SENHORA — Venha sentar um pouco. Não precisa provar nada para uma praça.

Lucas ficou olhando para ela.

Depois sorriu.

LUCAS — ...Sabe de uma coisa? A senhora está certa.

Sentou-se.

A pedra estava fria.

O vento passava entre as árvores.

Por alguns minutos, ele simplesmente descansou.

SENHORA — Você parece estar pensando em alguma coisa.

Lucas observou a fonte.

LUCAS — Estou.

SENHORA — É grave?

Ele abriu um sorriso.

LUCAS — Acho que não.

SENHORA — Então conte.

Lucas apontou para as casas ao redor.

LUCAS — A senhora gosta de morar aqui?

Ela respondeu sem hesitar:

SENHORA — Gosto.

LUCAS — Por quê?

A mulher olhou para a praça.

Depois para a rua.

SENHORA — Porque conheço as pessoas. Porque posso sentar aqui de manhã. Porque o padeiro sabe de qual pão gosto. Porque o menino daquela casa sempre me ajuda quando preciso carregar alguma coisa.

Ela apontou para uma janela.

SENHORA — E porque minha filha mora perto.

Lucas assentiu.

LUCAS — Entendi.

A senhora o examinou.

SENHORA — Mas eu gostaria de algumas coisas diferentes.

Ele se inclinou, interessado.

LUCAS — Como o quê?

Ela apontou para uma escadaria na extremidade da praça.

SENHORA — Aquela subida é uma desgraça.

Lucas olhou.

Os degraus eram estreitos.

A passagem ligava a praça a uma rua mais elevada.

SENHORA — Quando era jovem, subia aquilo sem pensar. Hoje preciso dar uma volta enorme para chegar ao outro lado.

Lucas observou os caminhos.

Depois perguntou:

LUCAS — Se houvesse uma passagem mais suave, a senhora usaria?

SENHORA — Claro.

Ela estreitou os olhos.

SENHORA — Mas não vá destruir minha fonte para fazer uma estrada.

Lucas abriu os braços.

LUCAS — MINHA SENHORA! EU JAMAIS ATENTARIA CONTRA UM PATRIMÔNIO HIDRÁULICO TÃO RESPEITÁVEL!

A senhora o encarou.

Depois começou a gargalhar.

SENHORA — Você fala coisas muito estranhas.

LUCAS — OUÇO ISSO COM FREQUÊNCIA!

A criança que desenhava aproximou-se.

Era uma menina de cabelos encaracolados, com manchas de tinta nos dedos.

Ela olhou para Lucas.

Depois para o papel.

MENINA — Você faz prédios?

Lucas sorriu.

LUCAS — Faço.

MENINA — Grandes?

LUCAS — Alguns.

Ela mostrou seu desenho.

Havia casas.

Uma fonte.

Árvores.

E uma estrutura enorme que parecia uma ponte atravessando o céu.

MENINA — Eu queria uma cidade assim.

Lucas pegou o papel com cuidado.

LUCAS — ...Caramba.

A menina sorriu.

MENINA — Gostou?

LUCAS — Muito.

Ele apontou para a ponte.

LUCAS — Isso aqui liga o quê?

MENINA — Duas partes da cidade.

LUCAS — E por que ela é tão alta?

A menina pareceu surpresa com a pergunta.

MENINA — Para a gente ver o pôr do sol.

Lucas ficou imóvel.

Olhou novamente para o desenho.

Uma ponte.

Não para atravessar um abismo perigoso.

Não para transportar um exército.

Não para demonstrar o poder de alguém.

Uma ponte para ver o pôr do sol.

O Criador começou a sorrir lentamente.

LUCAS — ...Eu gostei muito da sua ideia.

A menina apontou para outro elemento.

MENINA — E aqui tem um jardim em cima das casas.

LUCAS — UM JARDIM ELEVADO?!

MENINA — Sim.

LUCAS — MINHA JOVEM, VOCÊ É UMA VISIONÁRIA!

A senhora começou a rir.

A menina também.

MENINA — O que é visionária?

Lucas pensou.

LUCAS — Alguém que imagina uma coisa bonita antes de ela existir.

A criança observou o próprio desenho.

Depois sorriu.

MENINA — Então você também é.

Lucas ficou quieto.

Por um instante, a resposta atingiu algo que ele não esperava.

Olhou para a praça.

Para a fonte.

Para a senhora.

Para as casas.

Depois para o desenho.

LUCAS — ...É.

Sorriu.

LUCAS — Acho que somos.

Quando voltou a correr, levou consigo uma ideia.

Não o desenho.

A menina quis ficar com ele, para terminar de colorir as árvores.

Lucas respeitou.

Mas guardou na memória a ponte impossível.

E, principalmente, o motivo de ela existir.

IV — A lembrança de um mundo que também sonhava

DIA 538 · 07h57 · CAMINHO DOS JARDINS — MIRANTE DA CIDADE ANTIGA

Lucas alcançou uma passagem elevada entre dois setores residenciais.

Não era o Observatório do Criador.

A Crista do Vento Claro permanecia mais distante, acima das ruas, com seu verdadeiro observatório e o caminho histórico que ele construíra no Dia 171.

Aquele lugar era apenas um pequeno mirante público.

Mas oferecia uma boa visão.

Lucas parou.

Apoiou as mãos no parapeito.

E olhou.

Três Arcos espalhava-se diante dele.

Os telhados recebiam a luz da manhã.

As bandeiras movimentavam-se com o vento.

A Grande Avenida cortava parte da paisagem como uma linha cuidadosamente desenhada.

Mais longe, as oficinas da Forja Aurora anunciavam sua atividade pelas chaminés.

Em outra direção, AERÚN parecia quase inacreditável.

A cidadela de pesquisa integrava arquitetura, ciência e a ambição de pessoas determinadas a compreender mistérios que haviam sobrevivido a civilizações.

E, além dos bairros, o Eixo Aurora seguia em direção ao Campo onde ARGOS repousava depois de seu quinto voo.

Lucas conhecia tudo aquilo.

Havia ajudado a criar uma parte extraordinária daquela paisagem.

Mas, naquela manhã, a observava de outra maneira.

Na Terra, ele já vira imagens de cidades monumentais.

Não precisava ter visitado todas elas para lembrar.

Recordava fotografias de praças italianas, cúpulas que pareciam flutuar sobre edifícios antigos, jardins simétricos, pontes de pedra atravessando rios e avenidas iluminadas à noite.

Lembrava de cidades modernas que se estendiam até onde a vista alcançava.

De arranha-céus.

De estações de transporte.

De aeroportos.

De enormes sistemas urbanos capazes de levar milhões de pessoas de um lugar para outro.

Mas também lembrava de coisas menores.

Um parque aberto numa tarde comum.

Pessoas sentadas no gramado.

Uma bicicleta encostada perto de uma árvore.

Uma criança descobrindo uma fonte.

O som de uma cidade que continuava funcionando enquanto quase todo mundo dormia.

E lembrava das telas.

Da possibilidade de ver o rosto de alguém distante.

De conversar com uma pessoa sem precisar viajar dias.

De receber notícias.

De aprender alguma coisa com alguém que morava do outro lado do mundo.

Lucas ergueu lentamente os olhos.

A Costura de Dados já permitia comunicações por imagem entre alguns pontos autorizados de Três Arcos, AERÚN, Forja e Campo Aurora.

Não era uma rede mundial.

Ainda havia muito a desenvolver.

Mas a possibilidade existia.

Assim como os autômatos.

Assim como ARGOS.

Assim como o conhecimento das pessoas que trabalhavam na Forja.

Assim como GÊNESE.

LUCAS — ...Puta que pariu.

A voz saiu baixa.

NÓX se manifestou.

NÓX — Encontrou algum problema?

Lucas continuou olhando para a cidade.

LUCAS — Encontrei uma coisa maravilhosa.

NÓX — Qual?

Lucas apontou para a paisagem.

LUCAS — Tudo isso.

Houve uma pausa.

NÓX — Três Arcos?

LUCAS — Sim.

Ele se virou.

Abriu os braços.

LUCAS — Olha para ela, parceiro!

Um grupo de pássaros atravessou o céu acima dos telhados.

Lucas começou a caminhar de um lado para outro.

A expressão mudava conforme as ideias se encontravam.

LUCAS — A gente já tem uma cidade. Uma cidade de verdade! Temos ruas, oficinas, mercados, escolas, casas, jardins, instituições, gente vivendo, gente trabalhando, gente criando coisas!

NÓX — Correto.

LUCAS — Temos uma Forja que está aprendendo a construir máquinas que ninguém imaginava possíveis!

NÓX — Correto.

LUCAS — Temos uma cidadela de pesquisa que parece ter saído do sonho mais absurdo de um arqueólogo!

NÓX — Também correto.

LUCAS — Temos milhares de autômatos, comunicação arcana e uma aeronave que acabou de mostrar ao mundo o que pode acontecer quando você dá a uma equipe de malucos as ferramentas certas!

NÓX aguardou.

Lucas parou.

Olhou para a cidade.

Um sorriso absolutamente perigoso apareceu em seu rosto.

LUCAS — ...E se a gente juntasse tudo?

Silêncio.

NÓX — Defina juntar.

Lucas abriu os braços outra vez.

LUCAS — Não as instituições! AS IDEIAS!

O SISTEMA surgiu discretamente.

SISTEMA — Atenção: o usuário apresenta sinais clássicos de uma proposta de grandes proporções.

LUCAS — VOCÊ NÃO TEM A MENOR IDEIA!

SISTEMA — Essa frase foi historicamente associada a iniciativas cuja área construída excedeu suas estimativas iniciais.

LUCAS — DESSA VEZ EU QUERO UMA COISA MUITO MAIOR!

SISTEMA — Registro atualizado.

Lucas gargalhou.

Depois voltou ao parapeito.

A imaginação começou a trabalhar.

Ele viu a Grande Avenida transformada num corredor magnífico de vida urbana.

Não uma superfície fria e uniforme.

Uma avenida de pedra clara e mosaicos, com árvores antigas preservadas, colunatas elegantes, fontes, jardins, esculturas feitas por artistas e passagens para pedestres que convidassem as pessoas a caminhar.

Imaginou os mercados funcionando sem que carroças de carga disputassem cada palmo com crianças e idosos.

Imaginou canais de água limpos.

Transporte público silencioso.

Veículos arcanos movendo-se entre os bairros.

Pontos de embarque integrados a pequenas praças.

Bibliotecas.

Hospitais.

Oficinas.

Escolas.

Jardins suspensos.

Pontes que também fossem lugares bonitos para visitar.

E uma rede de comunicação capaz de aproximar famílias e estudiosos sem exigir que todos atravessassem enormes distâncias.

Mas a visão não parou no que já existia.

Muito além das casas atuais, Lucas imaginou um novo distrito.

Um bairro tão extraordinário que viajantes parariam diante de suas portas para perguntar quem o construíra.

Não um palácio particular.

Não uma fortaleza vazia.

Uma cidade dentro da cidade.

Moradias preparadas para receber pessoas que ainda não haviam chegado.

Ruas amplas.

Áreas verdes.

Comércio.

Espaços culturais.

Oficinas onde anões, humanos, elfos, orcs e povos que ele ainda nem conhecia pudessem trabalhar, discutir, ensinar e aprender.

Um lugar onde a arte de séculos diferentes encontrasse tecnologias que aquele mundo ainda não imaginara.

A beleza das cidades antigas da Terra.

A ousadia das cidades futuras.

E a magia de um mundo que possuía leis inteiramente novas.

Lucas parou de caminhar.

Sua expressão ficou séria.

O que lhe viera à mente não era apenas um projeto bonito.

Era uma possibilidade.

A capacidade de Três Arcos poderia deixar de crescer somente em resposta aos problemas imediatos.

Ela poderia se preparar para oportunidades que ainda não haviam chegado.

Para pessoas que ainda não conheciam a Cidade Livre.

Para crianças que nasceriam ali.

Para estudantes que desejariam atravessar reinos em busca de AERÚN.

Para comerciantes que encontrariam novos mercados.

Para inventores que teriam condições de construir coisas que nem o próprio Lucas sabia imaginar.

Ele olhou para as mãos.

GÊNESE permanecia ali.

Inteira.

Vasta.

Pronta.

Ele podia materializar edifícios, estruturas, instrumentos e maravilhas com uma autoridade que já havia demonstrado muitas vezes.

Não precisaria fingir que uma parede levaria meses para surgir.

A matéria não era o problema.

E as pessoas não eram peças que precisassem ser fabricadas para completar a paisagem.

Elas já existiam.

Possuíam sonhos.

Vontades.

Profissões.

Culturas.

Famílias.

E outras poderiam escolher chegar.

Lucas começou a sorrir novamente.

LUCAS — ...Não precisamos criar os moradores.

NÓX respondeu:

NÓX — Não.

LUCAS — Podemos criar oportunidades para que venham.

O vento atravessou o mirante.

Lucas observou a praça abaixo.

A menina do desenho provavelmente continuava colorindo sua ponte.

A senhora ainda precisava dar uma volta enorme para evitar a escadaria.

Salma continuaria transportando pão por uma passagem difícil.

O aprendiz da Forja construiria sua segunda roda.

Todas aquelas vidas já estavam acontecendo.

Três Arcos não precisava ser substituída.

Precisava ter espaço para se tornar ainda mais extraordinária.

LUCAS — ...Eu consigo fazer isso.

Não foi uma afirmação arrogante.

Tampouco uma dúvida sobre suas capacidades.

Foi o reconhecimento de uma possibilidade real.

Então ele começou a rir.

Primeiro, baixinho.

Depois mais alto.

Um riso de entusiasmo genuíno.

LUCAS — HAHAHAHA!

Um homem que passava pelo caminho olhou para ele.

Lucas virou a cabeça imediatamente.

LUCAS — BOM DIA!

O homem hesitou.

HOMEM — ...Bom dia?

LUCAS — TENHA UMA MANHÃ MARAVILHOSA!

O homem assentiu, desconcertado.

E acelerou o passo.

NÓX comentou:

NÓX — Você o assustou.

LUCAS — EU ESTOU FELIZ!

NÓX — São condições que, em seu caso, ocasionalmente apresentam sintomas semelhantes.

Lucas gargalhou outra vez.

Então lembrou de Miren.

Do café.

Da promessa de voltar.

E da expressão que ela provavelmente faria quando descobrisse o tamanho da ideia que nascera durante uma simples corrida.

Lucas olhou para a cidade mais uma vez.

LUCAS — ...Ela vai me chamar de louco.

O SISTEMA respondeu:

SISTEMA — A hipótese é consistente com os registros anteriores.

Lucas abriu um sorriso de pura malícia.

LUCAS — E DEPOIS VAI QUERER PARTICIPAR!

SISTEMA — Essa segunda hipótese possui evidências igualmente favoráveis.

Lucas apontou para o ar.

LUCAS — AHAHA! EU CONHEÇO MINHA MULHER!

Guardou os fones.

Respirou fundo.

E começou a correr de volta para casa.

Dessa vez, mais depressa.

Não porque estivesse fugindo de alguma coisa.

Mas porque tinha uma ideia extraordinária.

E conhecia exatamente a pessoa com quem queria dividi-la primeiro.

V — O café da manhã em que uma cidade inteira quase entrou pela janela

DIA 538 · 08h26 · CASA DO JARDIM BRANCO — JARDIM E COZINHA

Miren ouviu a porta abrir.

Depois passos.

Depois uma voz extraordinariamente alegre:

LUCAS — AMOOOOOR!

Ela fechou os olhos.

Estava sentada junto à mesa da cozinha, examinando algumas anotações enquanto esperava a água esquentar.

Sorriu lentamente.

MIREN — ...Pronto.

Rumo, que organizava alguns utensílios depois de concluir uma tarefa doméstica, virou a cabeça.

RUMO — O que aconteceu?

Miren pousou a pena.

MIREN — Meu marido teve uma ideia.

Rumo permaneceu em silêncio.

Depois olhou para a porta.

RUMO — Como sabe?

MIREN — Pelo volume.

Lucas apareceu naquele instante.

Suado.

Descabelado.

Com uma expressão tão satisfeita que parecia ter acabado de descobrir uma nova lei da física.

LUCAS — BOM DIA NOVAMENTE!

Miren ergueu os olhos.

Examinou-o.

Depois sorriu.

MIREN — ...O que você fez?

Lucas levou a mão ao peito.

LUCAS — POR QUE ESSA É SEMPRE A PRIMEIRA PERGUNTA?!

MIREN — Porque você entrou em casa sorrindo desse jeito.

LUCAS — NÃO POSSO ESTAR FELIZ?!

MIREN — Pode.

Ela inclinou a cabeça.

MIREN — Mas está com aquele sorriso.

Lucas tentou parecer inocente.

Foi uma tentativa desastrosa.

Miren começou a rir.

MIREN — Lucas.

LUCAS — Oi, meu amor maravilhoso.

MIREN — Quantos hectares?

Houve silêncio.

Rumo permaneceu absolutamente imóvel.

NÓX não disse nada.

O SISTEMA pareceu apreciar profundamente a pergunta.

Lucas abriu a boca.

Fechou.

Depois arregalou os olhos.

LUCAS — EU NEM DISSE O QUE QUERO FAZER!

Miren caiu na gargalhada.

MIREN — Então existe alguma coisa!

Lucas abriu os braços.

LUCAS — EXISTE UMA COISA FANTÁSTICA!

Rumo olhou para Miren.

RUMO — Sua dedução foi correta.

LUCAS — RUMO! VOCÊ É MEU PARCEIRO!

RUMO — Continuo sendo. Mas também reconheço uma boa dedução.

Miren precisou apoiar a cabeça nas mãos.

Lucas aproximou-se da esposa.

Inclinou-se para beijá-la.

Ela o segurou pelos ombros, afastando-o alguns centímetros.

MIREN — Nem pense nisso.

Ele ficou imóvel.

LUCAS — ...O quê?

MIREN — Primeiro, banho.

Lucas olhou para a própria camisa.

Depois para ela.

LUCAS — Amor, eu corri pela cidade inteira.

MIREN — Percebi.

LUCAS — ISSO É O PERFUME DA DEDICAÇÃO!

Miren ergueu uma sobrancelha.

MIREN — O perfume da dedicação vai tomar banho.

Rumo comentou:

RUMO — Posso providenciar uma toalha.

Lucas apontou para ele.

LUCAS — NÃO ALIMENTE A REVOLTA!

Mas já estava rindo quando subiu para o quarto.

08h43 · COZINHA

Quando voltou, estava limpo, com roupas leves e os cabelos ainda úmidos.

Miren havia colocado pão, frutas, queijo e algumas conservas sobre a mesa.

Havia também um pequeno pacote embrulhado em tecido.

Lucas parou.

Os olhos se iluminaram.

LUCAS — ...Você comprou?

Ela sorriu.

MIREN — Não. Halden mandou entregar.

Lucas aproximou-se do pacote com a expressão de um homem diante de um tesouro antigo.

Abriu cuidadosamente.

Dentro havia pequenos pães recheados, ainda mornos.

Uma anotação acompanhava:

Para a arqueóloga e o sujeito que costuma alegar que só come um.

Lucas leu.

Depois olhou para Miren.

LUCAS — ...Esse homem é um gênio.

MIREN — Ele conhece você.

LUCAS — É POR ISSO QUE É UM GÊNIO!

Rumo aproximou-se da porta.

RUMO — Conseguiu decidir como deseja seu café?

Lucas olhou para o autômato.

Depois para a própria esposa.

LUCAS — Hoje eu quero preparar alguma coisa também.

Miren sorriu.

MIREN — Desde que não use GÊNESE para manifestar uma cozinha inteira.

Lucas abriu os braços.

LUCAS — EU NÃO PRECISO MAIS PROVAR MINHA SUPERIORIDADE SOBRE OS UTENSÍLIOS DOMÉSTICOS!

O SISTEMA apareceu:

SISTEMA — Não há registro conclusivo de que essa superioridade tenha sido alcançada.

LUCAS — CALADO!

A manhã continuou com uma disputa muito específica.

Lucas queria preparar ovos.

Miren queria cortar as frutas.

Ambos queriam aproveitar o tempo juntos.

O único obstáculo era que Lucas insistia em demonstrar que possuía uma técnica culinária absolutamente revolucionária.

MIREN — Você está mexendo demais.

LUCAS — ESTOU DISTRIBUINDO O CALOR!

MIREN — Está tentando impedir que os ovos grudem?

LUCAS — TAMBÉM!

Ela aproximou-se.

Observou a frigideira.

MIREN — Quer ajuda?

Lucas ficou pensativo.

Depois ergueu o utensílio.

LUCAS — Minha senhora, aceito uma aliança estratégica.

Miren segurou a colher.

MIREN — Então abaixe o fogo.

Ele obedeceu.

MIREN — Agora deixe descansar um pouco.

Lucas observou.

LUCAS — ...Hum.

Ela sorriu.

MIREN — Viu?

LUCAS — Você acabou de derrotar um problema que minha genialidade estava prestes a resolver.

MIREN — Claro.

Ela provou um pequeno pedaço.

MIREN — Ficou bom.

Lucas abriu os braços.

LUCAS — UM TRIUNFO DA COOPERAÇÃO ENTRE CIVILIZAÇÕES!

Miren começou a rir novamente.

Às 09h02, sentaram-se.

O sol iluminava a mesa.

A janela permanecia aberta.

O perfume do jardim entrava com o vento, misturando-se ao aroma do pão recém-aquecido.

Lucas estava faminto.

Miren percebeu imediatamente.

MIREN — Coma primeiro.

Ele ergueu os olhos.

LUCAS — Eu ainda não falei da ideia.

MIREN — Exatamente. Pretendo alimentá-lo antes que esqueça o que é uma refeição.

Lucas pegou um dos pães de Halden.

Deu uma mordida.

Fechou os olhos.

Ficou imóvel.

Miren o observou.

MIREN — ...Está bom?

Lucas não respondeu.

Apenas ergueu o polegar.

Miren começou a rir.

LUCAS — Mmm.

Engoliu.

LUCAS — Eu vou construir uma estátua para esse homem.

MIREN — Pergunte antes se ele quer uma.

Lucas pensou.

LUCAS — ...Justo.

Outra mordida.

Uma pausa.

LUCAS — Mas ele merece.

Miren esperou que ele terminasse o primeiro pão.

Depois apoiou os cotovelos na mesa.

MIREN — Muito bem, meu amor.

Lucas ergueu os olhos.

MIREN — Conte.

Ele ficou sério por um instante.

Não aquela seriedade que surgia diante de uma ameaça.

Era a concentração de alguém tentando encontrar a melhor maneira de explicar uma coisa que ainda estava tomando forma.

LUCAS — Eu saí para correr.

Miren assentiu.

MIREN — Até aqui, nenhuma surpresa.

LUCAS — Passei pela avenida. Pelo mercado. Pelas oficinas. Pelos bairros...

Começou a contar.

O cachorro que roubara a luva do legionário.

O vendedor de peras.

Salma e o carrinho de pão.

O menino que construía sua primeira roda.

A senhora da praça.

A menina que desenhara uma ponte para ver o pôr do sol.

Miren ouviu tudo.

Não interrompeu quando Lucas imitou solenemente a expressão do cachorro.

Não conteve a gargalhada quando ele reproduziu sua própria derrota diante do vendedor de frutas.

Mas seu olhar ficou diferente quando ouviu sobre Salma.

E mais atento ainda quando Lucas descreveu a senhora que precisava evitar a escadaria.

MIREN — Conheço passagens semelhantes.

Lucas assentiu.

LUCAS — Imagino.

MIREN — Algumas foram construídas antes de termos condições de pensar em circulação mais ampla. Outras atendem bem aos moradores que as utilizam, mas não a todos.

Lucas apontou para ela.

LUCAS — EXATAMENTE!

Miren olhou para o dedo erguido.

Depois para ele.

MIREN — Você está prestes a levantar da cadeira.

LUCAS — ESTOU!

MIREN — Ainda estamos comendo.

Ele sentou novamente.

LUCAS — ...Certo.

Miren sorriu.

MIREN — Continue.

Lucas pegou um pedaço de pão.

Não comeu.

Ficou girando-o entre os dedos enquanto pensava.

LUCAS — Quando cheguei ao mirante, comecei a lembrar da Terra.

Miren apoiou a mão sobre a dele.

MIREN — Do quê?

LUCAS — Das cidades.

Ela sorriu discretamente.

MIREN — Você já me mostrou algumas imagens.

LUCAS — Eu sei. Mas hoje pensei nelas de outro jeito.

Ele se inclinou.

LUCAS — Lembra das praças antigas? Das avenidas com árvores? Daquelas cidades com edifícios enormes e cúpulas? E das telas de comunicação?

Miren assentiu.

MIREN — Lembro especialmente das bibliotecas.

Lucas abriu um sorriso.

LUCAS — É CLARO QUE LEMBRA!

MIREN — Havia uma quantidade absurda de livros.

LUCAS — Tinha.

MIREN — E você ficou mostrando veículos.

Ele levou a mão ao peito.

LUCAS — EU ESTAVA APRESENTANDO A EVOLUÇÃO TECNOLÓGICA DA HUMANIDADE!

MIREN — Você passou vários minutos explicando um motor.

LUCAS — UM MOTOR EXTRAORDINÁRIO!

Ela riu.

Lucas também.

Mas o sorriso dele se tornou pensativo.

LUCAS — O que me ocorreu hoje foi que a Terra construiu muitas daquelas coisas ao longo de séculos. Com muita gente. Muita tentativa. Muito conhecimento acumulado.

MIREN — E muita diferença entre lugares.

LUCAS — Sim.

Ele assentiu.

LUCAS — Algumas cidades são maravilhosas de olhar, mas difíceis de viver. Outras parecem simples e funcionam muito bem. E outras conseguem combinar coisas incríveis.

Miren ficou atenta.

Lucas prosseguiu:

LUCAS — Nós temos uma vantagem que não existia daquele jeito na Terra.

Ela olhou para suas mãos.

MIREN — GÊNESE.

Lucas assentiu.

LUCAS — GÊNESE. E a magia deste mundo. E a Forja. E você. E Astra. E Kael. E Lysa. E todos os malucos geniais que vivem aqui.

Miren sorriu.

MIREN — Você incluiu a mim na lista dos malucos?

Lucas ficou imóvel.

Olhou para a esposa.

A expressão de absoluto terror teatral surgiu em seu rosto.

LUCAS — ...AMOR, EU USEI A PALAVRA GENIAIS PRIMEIRO!

Miren gargalhou.

Ele também.

Depois, Lucas se levantou.

Dessa vez, Miren não o impediu.

Ele foi até a janela.

Olhou para a cidade que aparecia além do jardim.

LUCAS — E se a gente transformasse Três Arcos na cidade mais extraordinária que esse mundo já viu?

Miren permaneceu sentada.

Observando-o.

Lucas virou-se.

Os olhos brilhavam.

LUCAS — Não só uma cidade bonita. Uma cidade maravilhosa de viver.

Ele começou a caminhar pela cozinha.

LUCAS — Imagina ruas que sejam obras de arte. Pontes com jardins. Praças enormes. Fontes. Palácios cívicos. Bibliotecas abertas para as pessoas. Hospitais. Escolas. Parques que parecem ter saído de um conto de fadas!

Miren começou a sorrir.

LUCAS — Agora coloca transporte público funcionando o dia inteiro! Veículos arcanos! Sistemas de comunicação! Iluminação linda! Água limpa! Coleta organizada! Oficinas modernas! Lugares onde as pessoas possam criar, trabalhar, estudar e viver sem depender de uma carroça para atravessar a cidade inteira!

Ele abriu os braços.

LUCAS — E tudo com arquitetura fantástica! Pedra, mármore, vitrais, cúpulas, jardins suspensos! Nada de transformar nossa cidade numa floresta de caixas metálicas!

Miren soltou uma gargalhada.

MIREN — Você tem alguma coisa contra caixas metálicas?

LUCAS — TENHO CONTRA AS FEIAS!

Ela continuou rindo.

Lucas se aproximou da mesa.

Abaixou o tom.

LUCAS — E imagina que, além de melhorar o que já existe, a gente prepare um distrito novo.

Miren ergueu os olhos.

MIREN — Um distrito?

LUCAS — Sim.

Ele sorriu.

LUCAS — Grande. Muito grande.

Ela cruzou os braços.

MIREN — ...Aí está.

LUCAS — O QUÊ?!

MIREN — Os hectares.

Lucas levou as mãos à cabeça.

LUCAS — VOCÊ NÃO ME DEIXA TER UM MOMENTO DE GRANDEZA!

Miren começou a rir tão alto que precisou se recostar na cadeira.

Quando recuperou o fôlego, apontou para uma folha vazia.

MIREN — Mostre.

Lucas a observou.

LUCAS — Sério?

MIREN — Sério.

LUCAS — Mesmo?

MIREN — Lucas.

Ele pegou imediatamente a folha.

Arrastou uma cadeira até ficar ao lado dela.

Depois começou a desenhar.

Não era um projeto executivo.

Não havia medidas precisas.

A primeira linha saiu torta.

A segunda parecia uma estrada.

A terceira produziu uma forma circular.

Miren observou.

MIREN — Isso é uma praça?

LUCAS — Sim!

Ele desenhou outra estrutura.

MIREN — E isso?

LUCAS — Um jardim.

Outra.

MIREN — E isso?

Lucas hesitou.

LUCAS — ...Ainda não sei.

Miren sorriu.

MIREN — Ótimo.

Ele olhou para ela.

LUCAS — Ótimo?

MIREN — Significa que ainda podemos descobrir.

Lucas soltou uma risada.

Depois voltou ao desenho.

LUCAS — Pensa comigo. Um distrito planejado para poder receber cem mil pessoas no futuro.

Miren ergueu os olhos.

MIREN — Capacidade?

LUCAS — Exatamente. Não cem mil moradores aparecendo de repente.

MIREN — Isso eu espero.

Ele abriu os braços.

LUCAS — MINHA SENHORA, NÃO VOU MANIFESTAR UMA MULTIDÃO!

Ela sorriu.

MIREN — Bom.

LUCAS — Quero que as pessoas escolham vir. Que tenham motivos para isso.

Ele apontou para o papel.

LUCAS — Podemos preparar moradias, ruas, serviços, comércio, escolas. Tudo isso. E, enquanto ainda não estiver ocupado, a Malha pode ajudar a conservar os espaços.

MIREN — E onde pretende colocá-lo?

Lucas parou.

Olhou para o desenho.

Depois para a esposa.

LUCAS — ...Essa é uma excelente pergunta.

Ela sorriu, satisfeita.

MIREN — Eu imaginei.

Lucas começou a rir.

LUCAS — Pensei numa região que permita conexão com a cidade e acesso ao Eixo Aurora. Mas não quero simplesmente escolher um pedaço do mapa e descobrir depois que construí em cima de alguma coisa importante.

Miren inclinou a cabeça.

MIREN — Principalmente perto de AERÚN.

LUCAS — Sim.

Ela se levantou.

Foi buscar seu próprio caderno.

Voltou.

Abriu numa página com algumas anotações de pesquisa.

MIREN — Nossa área científica possui setores protegidos, rotas específicas de acesso, zonas de investigação e espaços que não devem ser tratados como terrenos urbanos disponíveis.

Lucas assentiu.

LUCAS — Concordo.

MIREN — E o Campo Aurora precisa continuar trabalhando. ARGOS não pode perder suas condições de operação porque você achou bonito colocar uma avenida monumental no caminho.

Lucas levou a mão ao peito.

LUCAS — VOCÊ ACHA QUE EU FARIA ISSO?!

Miren permaneceu olhando para ele.

Silêncio.

Lucas suspirou.

LUCAS — ...Está bem. Eu provavelmente desenharia primeiro e perguntaria depois.

Ela gargalhou.

MIREN — É por isso que estamos conversando.

Miren examinou a folha novamente.

Depois pegou a pena.

Fez uma pequena marca ao lado do desenho de Lucas.

MIREN — Eu acrescentaria uma coisa.

Ele se inclinou.

LUCAS — O quê?

MIREN — Um grande jardim de conhecimento.

Lucas observou a esposa.

LUCAS — ...Um jardim?

Ela assentiu.

MIREN — Não apenas um jardim bonito. Um lugar para aprender.

Começou a desenhar pequenas estruturas.

MIREN — Árvores de diferentes regiões, identificadas. Pavilhões de exposição. Bibliotecas. Espaços para oficinas públicas. Galerias onde crianças possam conhecer os povos do mundo.

Lucas abriu um sorriso lento.

MIREN — Um lugar onde um estudante veja uma planta desconhecida e queira descobrir de onde veio. Onde um artesão encontre uma ideia de outro povo. Onde alguém possa conversar com pesquisadores.

Ela apontou para outra parte.

MIREN — E eu gostaria de uma área dedicada à história da cidade. Não apenas aos grandes feitos. Aos moradores, às famílias, aos trabalhos e às mudanças que aconteceram.

Lucas ficou olhando.

Depois soltou um assobio baixo.

LUCAS — ...Amor.

Miren ergueu os olhos.

LUCAS — Isso é muito melhor do que o que eu tinha desenhado aqui.

Ela sorriu.

MIREN — Então vamos manter.

Lucas se inclinou.

Beijou sua bochecha.

LUCAS — EU CASEI COM UMA GÊNIA!

MIREN — Você já sabia disso.

LUCAS — MAS EU GOSTO DE REAFIRMAR PUBLICAMENTE!

MIREN — Estamos sozinhos na cozinha.

Lucas apontou para NÓX.

LUCAS — TEMOS TESTEMUNHAS!

O sorriso de Miren diminuiu um pouco.

Ela continuou observando o desenho.

MIREN — Também existe outra coisa que eu gostaria de discutir.

Lucas percebeu a mudança.

Sentou-se novamente.

LUCAS — Fala, amor.

Ela pensou durante alguns segundos.

MIREN — Quando você fala de uma cidade capaz de receber tanta gente, penso em todas as pessoas que poderão chegar com conhecimentos que ainda não temos.

LUCAS — Sim.

MIREN — AERÚN precisa crescer dessa maneira.

Lucas a observou.

Ela prosseguiu:

MIREN — Temos pesquisadores excelentes. Astra e os demais fizeram um trabalho extraordinário. Mas estamos diante de perguntas que podem exigir especialidades que ainda não reunimos.

LUCAS — Você quer trazer mais gente.

MIREN — Quero oferecer oportunidades reais para que especialistas venham. Mestres de outras tradições. Pessoas que estudam plantas, estruturas antigas, inscrições, fenômenos arcanos, matemática, línguas.

Lucas sorriu.

LUCAS — Professores também?

MIREN — Principalmente.

Ela abriu um sorriso.

MIREN — E estudantes que talvez sejam capazes de fazer perguntas que nós não sabemos formular.

Lucas ficou pensativo.

LUCAS — Podemos transformar AERÚN num lugar ainda mais extraordinário.

MIREN — Podemos.

Ela ergueu um dedo.

MIREN — Mas não quero confundir abrir oportunidades de estudo com abrir todas as salas de pesquisa.

Lucas assentiu.

LUCAS — Claro.

MIREN — Temos materiais antigos, investigações incompletas e áreas onde o acesso precisa continuar controlado.

LUCAS — E o Coração continua selado.

Ela assentiu.

MIREN — Continua.

A expressão dela ficou um pouco distante.

MIREN — E ainda existem coisas que não compreendemos.

Lucas não tentou completar as respostas.

Conhecia aquela expressão.

Era a mesma de quando Miren encontrava uma pergunta difícil e já imaginava três maneiras de investigá-la.

LUCAS — Vocês vão continuar com os registros de Tessa Arin?

Miren assentiu.

MIREN — Astra quer comparar novamente alguns procedimentos de isolamento com os registros que conseguimos reunir.

LUCAS — Encontraram alguma coisa nova?

Ela balançou a cabeça.

MIREN — Nada que eu possa chamar de conclusão. Temos descrições parciais e questões antigas que continuam sem resposta.

Lucas apoiou os braços na mesa.

LUCAS — Então vocês precisam de melhores instrumentos, mais gente e liberdade para investigar.

MIREN — Precisamos de tudo isso.

Ela sorriu.

MIREN — E de pessoas que estejam dispostas a nos dizer quando uma hipótese está errada.

Lucas soltou uma risada.

LUCAS — Isso eu posso arrumar. A Forja está cheia de indivíduos que adoram dizer que alguma coisa está errada.

MIREN — Principalmente quando você apresenta uma invenção.

LUCAS — É UMA PERSEGUIÇÃO CIENTÍFICA!

Ela gargalhou.

O assunto caminhou naturalmente para a comunicação.

Miren apontou para a pequena esfera de luz utilizada em algumas demonstrações.

MIREN — A Costura de Dados já nos mostrou como é útil conversar por imagem entre pontos distantes.

LUCAS — Sim!

MIREN — Imagine uma professora de AERÚN conseguindo conversar com uma turma num bairro da cidade. Ou um pesquisador da Forja mostrando um instrumento para alguém da Cidadela sem precisar atravessar o Eixo.

Lucas abriu um sorriso gigantesco.

LUCAS — AMOR, EU PENSEI EXATAMENTE NISSO!

MIREN — E imagine uma família que mora longe conseguindo ver o rosto de alguém querido.

O sorriso dele mudou.

Tornou-se mais suave.

Na Terra, aquela possibilidade havia sido parte comum de sua vida.

Ali, ainda era uma conquista extraordinária.

Lucas observou a esposa.

LUCAS — ...Isso seria lindo.

Miren assentiu.

MIREN — Seria.

Depois estreitou os olhos.

MIREN — Mas nada de transformar a comunicação de todas as casas num instrumento de observação.

Lucas franziu a testa.

LUCAS — Amor, por que eu faria isso?

MIREN — Não acho que você faria. Acho que devemos construir um sistema no qual ninguém possa fazer isso facilmente.

Lucas permaneceu quieto.

Então sorriu.

LUCAS — ...Excelente.

Pegou a pena.

Escreveu uma pequena anotação.

LUCAS — Comunicação pública. Privacidade por projeto.

Miren olhou para ele.

MIREN — Gostei.

Ele ergueu a cabeça.

LUCAS — E eu gostei de você.

Ela arqueou uma sobrancelha.

MIREN — Só agora?

Lucas ficou absolutamente horrorizado.

LUCAS — NÃO! NÃO FOI ISSO QUE EU QUIS DIZER!

Miren começou a rir.

LUCAS — EU TE AMO DESDE MUITO ANTES DESSA CONVERSA!

Ela se aproximou.

Segurou o rosto dele.

MIREN — Eu sei, bobo.

Beijou-o.

Lucas correspondeu, abraçando sua cintura.

O beijo durou tempo suficiente para ambos esquecerem as folhas sobre a mesa.

Quando Miren se afastou, ainda permanecia muito próxima.

MIREN — Também te amo.

Lucas sorriu.

LUCAS — ...Mesmo quando tenho ideias desse tamanho?

Ela olhou para os desenhos.

Depois para ele.

MIREN — Principalmente quando consegue me deixar participar delas sem tentar decidir tudo sozinho.

Ele inclinou a cabeça.

LUCAS — Então temos um problema.

Ela ergueu uma sobrancelha.

MIREN — Qual?

Lucas abriu um sorriso absolutamente descarado.

LUCAS — Porque eu estava planejando fazer você se apaixonar ainda mais por mim com uma cidade inteira.

Miren soltou uma gargalhada.

MIREN — Você é insuportável!

LUCAS — MAS SOU UM INSUportável AMBICIOSO!

NÓX comentou:

NÓX — A classificação parece correta.

Lucas apontou para o braço.

LUCAS — VOCÊ NÃO FOI CONVIDADO PARA ESTA CONVERSA ROMÂNTICA!

Quando voltaram a sentar-se, o café já estava morno.

Lucas comeu outro pão.

Miren tomou um pouco de sua bebida.

E, durante alguns minutos, conversaram sobre coisas menores.

Uma planta que começara a florescer no jardim.

A visita que Astra pretendia fazer a uma pesquisadora.

O trabalho recente de Rumo.

O modo como Brannik parecia descobrir um novo problema mecânico sempre que resolvia o anterior.

Lucas contou que encontrara o autômato experimentando montar alguma coisa sem definir antes sua utilidade.

Miren sorriu.

MIREN — Gosto disso.

LUCAS — Eu também.

MIREN — Ele ainda está descobrindo o que deseja fazer com parte do próprio tempo.

Lucas assentiu.

LUCAS — E talvez termine construindo alguma coisa completamente inútil.

Miren começou a rir.

MIREN — Como algumas das suas invenções?

Lucas levou a mão ao peito.

LUCAS — MINHA SENHORA, TODAS AS MINHAS INVENÇÕES SÃO EXTREMAMENTE IMPORTANTES!

Ela ergueu uma sobrancelha.

MIREN — Inclusive o Capitão Bico de Horizonte?

Lucas ficou em silêncio.

O SISTEMA surgiu discretamente.

SISTEMA — Recomendo cautela. O usuário ainda defende a relevância estratégica da máscara.

LUCAS — ...O CAPITÃO BICO É PATRIMÔNIO CULTURAL!

Miren caiu na gargalhada.

O riso foi diminuindo.

A manhã avançava.

Lucas permaneceu olhando para os desenhos.

Então fez uma pergunta:

LUCAS — Amor, você acha que as pessoas vão gostar?

Miren não respondeu imediatamente.

Olhava para a folha onde ele havia desenhado a grande avenida.

Depois para o jardim de conhecimento que acrescentara.

MIREN — De algumas coisas, certamente.

Lucas assentiu.

MIREN — De outras, talvez não.

Ele sorriu.

LUCAS — Isso eu imagino.

MIREN — Mas acho que você está fazendo uma pergunta pequena demais.

Lucas ergueu os olhos.

LUCAS — Como assim?

Ela aproximou-se da janela.

Observou as árvores.

MIREN — Não precisamos que todo mundo goste do mesmo desenho.

Voltou-se para ele.

MIREN — Precisamos descobrir o que cada parte da cidade pode se tornar sem perder as coisas pelas quais as pessoas a amam.

Lucas permaneceu quieto.

Miren prosseguiu:

MIREN — Aquela senhora gosta da fonte. O aprendiz gosta da oficina. Salma precisa trabalhar. As crianças querem brincar.

Ela apontou para a folha.

MIREN — Uma cidade extraordinária precisa continuar oferecendo tudo isso.

Lucas olhou para os desenhos novamente.

Depois ergueu a cabeça.

A expressão tornou-se decidida.

LUCAS — Então não vamos destruir a cidade antiga para construir uma nova.

Miren sorriu.

MIREN — Bom começo.

LUCAS — Vamos fazer a cidade antiga ficar ainda mais extraordinária.

Ela assentiu.

Lucas prosseguiu, empolgado:

LUCAS — E construir novos espaços para quem quiser chegar. Com uma arquitetura que faça as pessoas pararem na rua só para olhar!

MIREN — Desde que consigam atravessar a rua também.

Lucas soltou uma gargalhada.

LUCAS — VOCÊ ESTÁ COMPLETAMENTE CERTA!

Ele se levantou.

Aproximou-se da esposa.

Abraçou-a por trás.

Miren descansou as mãos sobre os braços dele.

Os dois ficaram olhando para o jardim.

LUCAS — Sabe o que eu gostaria?

MIREN — O quê?

LUCAS — Que algum dia a gente subisse ao nosso observatório e visse tudo isso.

Ela sorriu.

LUCAS — As avenidas. Os parques. As novas casas. As luzes. As pessoas caminhando. E AERÚN lá no horizonte, maior ainda, cheia de gente descobrindo coisas absurdas.

Miren encostou a cabeça no ombro dele.

MIREN — Eu gostaria.

Lucas beijou seus cabelos.

LUCAS — E aí você me diria...

Ele tentou imitar a voz dela:

LUCAS — "Lucas, você exagerou um pouquinho."

Miren começou a rir.

MIREN — Eu provavelmente diria.

LUCAS — E eu responderia...

Ele abriu os braços ao redor dela.

LUCAS — "AMOR, NÓS NEM COMEÇAMOS!"

Ela gargalhou.

Depois se virou em seus braços.

MIREN — Então comece do jeito certo.

Lucas sorriu.

LUCAS — Conversando com Kael e Lysa?

MIREN — Sim.

Ela acariciou seu rosto.

MIREN — E ouvindo o que os moradores gostariam de construir com você.

Lucas assentiu.

LUCAS — Vou procurá-los hoje.

MIREN — Eu vou encontrar Astra. Temos pesquisas para organizar e quero conversar sobre novas áreas de estudo.

LUCAS — Depois me conta?

Ela sorriu.

MIREN — Claro.

Lucas beijou sua testa.

LUCAS — E eu conto o que Kael e Lysa disserem quando descobrirem o tamanho da minha ideia.

Miren abriu um sorriso travesso.

MIREN — Vou preparar alguma coisa para você comer quando voltar.

Lucas arregalou os olhos.

LUCAS — VOCÊ ACHA QUE EU NÃO VOU SOBREVIVER À REUNIÃO?!

MIREN — Acho que vai ficar com fome.

Ele pensou.

Depois assentiu gravemente.

LUCAS — ...Uma avaliação científica perfeitamente fundamentada.

E os dois começaram a rir outra vez.

VI — A pior notícia possível para o homem que organizava a cidade

DIA 538 · 10h17 · TRÊS ARCOS — CAMINHO DA CASA CÍVICA

Kael estava tendo uma manhã perfeitamente administrável.

Não extraordinária.

Mas administrável.

Havia recebido duas solicitações comerciais, discutido uma questão de circulação de mercadorias e conversado com Lysa sobre propostas que deveriam seguir para os representantes civis.

Nada exigia uma mobilização extraordinária.

Nenhum reino havia declarado guerra.

Nenhum exército estava diante dos portões.

Tudo parecia razoavelmente normal.

Até que um funcionário da Casa Cívica apareceu à porta.

FUNCIONÁRIO — Kael?

O estrategista ergueu os olhos.

KAEL — Sim?

FUNCIONÁRIO — Lucas está vindo.

Kael assentiu.

KAEL — Certo.

O homem hesitou.

FUNCIONÁRIO — Ele está sorrindo.

Kael parou de escrever.

Levantou lentamente a cabeça.

KAEL — ...Como?

FUNCIONÁRIO — Bastante.

Houve silêncio.

Lysa, que examinava documentos ao lado, fechou os olhos.

LYSA — Ah, não.

Kael pousou a pena.

KAEL — Ele está carregando alguma coisa?

FUNCIONÁRIO — Um caderno.

Lysa abriu os olhos.

Olhou para Kael.

LYSA — Estamos perdidos.

Poucos instantes depois, a porta se abriu.

LUCAS — MEUS QUERIDOS AMIGOS!

Kael permaneceu sentado.

Lysa também.

Ambos observaram o visitante.

Lucas entrou com a expressão de alguém que estava prestes a anunciar um presente de aniversário para o mundo.

KAEL — Bom dia, Lucas.

LYSA — Bom dia.

LUCAS — QUE MANHÃ MAGNÍFICA, NÃO É?!

Kael virou-se para Lysa.

KAEL — Você ouviu o tom?

Ela assentiu.

LYSA — Ouvi.

Lucas estreitou os olhos.

LUCAS — VOCÊS ESTÃO ME JULGANDO ANTES DE EU FALAR!

Kael apontou para uma cadeira.

KAEL — Sente-se.

LUCAS — NÃO!

Houve silêncio.

Lucas pensou.

Depois puxou a cadeira.

LUCAS — ...Está bem, vou sentar.

Lysa começou a rir.

Kael cruzou os braços.

KAEL — Como foi a manhã?

Lucas abriu um sorriso.

LUCAS — Maravilhosa!

LYSA — Miren está bem?

LUCAS — Perfeitamente. Foi pesquisar com Astra.

KAEL — ARGOS?

LUCAS — Em terra, aguardando os trabalhos da equipe.

LYSA — Algum problema com a Legião?

LUCAS — Nenhum que eu saiba.

Kael assentiu lentamente.

KAEL — Então você veio nos visitar.

Lucas abriu os braços.

LUCAS — EXATAMENTE!

Lysa o examinou.

LYSA — Com um caderno.

LUCAS — SIM!

LYSA — E aquele sorriso.

Lucas ficou imóvel.

LUCAS — ...Vocês realmente me conhecem bem demais.

Kael soltou uma gargalhada.

Lucas abriu o caderno.

Não começou com uma grande declaração.

Primeiro contou da corrida.

Falou da cidade.

Das pessoas.

Da alegria de ver os bairros funcionando.

E dos problemas pequenos que começara a perceber entre as grandes conquistas.

Kael ouviu com interesse crescente.

Quando Lucas mencionou Salma, o estrategista reconheceu a situação.

KAEL — A passagem do mercado entrou entre as solicitações de manutenção. Temos algumas intervenções menores a organizar naquela região.

LUCAS — Ótimo. Mas acho que talvez possamos fazer algo maior.

Lysa olhou para ele.

LYSA — Maior quanto?

Lucas abriu um sorriso.

Kael suspirou.

KAEL — Lá vamos nós.

Lucas colocou o desenho sobre a mesa.

LUCAS — Eu quero mostrar uma possibilidade.

Os dois se inclinaram.

Havia avenidas.

Jardins.

Pontes.

Pavilhões.

Fontes.

Uma grande região reservada para expansão.

Alguns desenhos estavam claramente inacabados.

Outros haviam recebido pequenas anotações feitas por Miren.

Lysa examinou a folha.

Depois ergueu os olhos.

LYSA — ...Lucas.

LUCAS — Sim?

LYSA — Isso é uma cidade.

Ele abriu um sorriso gigantesco.

LUCAS — NÃO!

Ela arqueou uma sobrancelha.

LUCAS — É TRÊS ARCOS!

Kael olhou novamente para o desenho.

O sorriso desapareceu de seu rosto.

Não por desaprovação.

Por interesse.

Ele reconheceu a Grande Avenida, o corredor de ligação e alguns dos espaços históricos que Lucas havia indicado.

Também percebeu o que ainda estava indefinido.

KAEL — Você está falando de renovar os bairros existentes?

Lucas assentiu.

LUCAS — Todos os que pudermos melhorar. E preparar novas áreas.

Lysa apontou para o desenho mais distante.

LYSA — Isso é uma expansão?

LUCAS — Uma proposta.

LYSA — Para quantas pessoas?

Lucas respondeu sem hesitar:

LUCAS — Capacidade futura para cem mil.

Silêncio.

Kael recostou-se lentamente.

Lysa olhou para ele.

Depois para Lucas.

Então soltou uma risada incrédula.

LYSA — ...Você saiu para correr.

LUCAS — SAÍ!

LYSA — E voltou querendo preparar moradia e infraestrutura para cem mil pessoas.

LUCAS — QUANDO VOCÊ FALA ASSIM PARECE EXAGERADO!

Kael começou a gargalhar.

KAEL — Porque é exagerado!

Lucas abriu os braços.

LUCAS — MAS É POSSÍVEL!

A risada de Kael diminuiu.

Ele olhou novamente para a folha.

KAEL — ...Sim.

Lysa ergueu os olhos.

Kael continuou:

KAEL — Com o que já sabemos construir, com a capacidade da Forja e de GÊNESE, a escala material não é absurda.

Lucas sorriu.

O estrategista apontou para a cidade desenhada.

KAEL — Mas o que me interessa não é apenas o tamanho.

LUCAS — O quê?

Kael indicou a ligação entre os bairros.

KAEL — Você pensou em integrar a cidade antiga.

Lucas assentiu.

LUCAS — Não quero substituir Três Arcos. Quero fazer dela algo ainda melhor.

Kael observou o desenho durante mais alguns segundos.

Depois sorriu.

KAEL — Então talvez tenhamos uma conversa bastante interessante.

Lysa examinou o caderno.

A expressão dela havia mudado.

O choque inicial deu lugar à atenção.

LYSA — Tenho várias perguntas.

Lucas abriu os braços.

LUCAS — MANDA!

LYSA — Algumas serão desagradáveis.

LUCAS — ESTOU EMOCIONALMENTE PREPARADO!

Kael olhou para ele.

KAEL — Você nunca está.

LUCAS — TRAIDOR!

Lysa riu.

Depois apontou para os desenhos.

LYSA — Quem pretende operar os serviços? Como os novos bairros terão comércio e oportunidades reais? O que acontecerá com os trabalhadores atuais? E como vamos receber pessoas de outros lugares sem prometer aquilo que ainda não conseguimos oferecer?

Lucas ficou pensativo.

Não porque não tivesse respostas para absolutamente nada.

Mas porque algumas delas precisariam ser construídas com outras pessoas.

LUCAS — Tenho ideias.

Lysa assentiu.

LYSA — Imagino.

LUCAS — E quero ouvir as suas.

Ela ergueu os olhos.

O sorriso apareceu lentamente.

LYSA — Então agora estamos falando.

Kael levantou-se.

Foi até uma das janelas.

Observou a rua.

Lá fora, trabalhadores transportavam materiais.

Uma mulher atravessava a praça com duas crianças.

Um pequeno grupo de autômatos seguia com sua equipe de manutenção.

O estrategista permaneceu olhando.

KAEL — Sabe o que aconteceu ontem?

Lucas ergueu os olhos.

LUCAS — O quê?

KAEL — Depois daquela celebração no céu, conversei com algumas pessoas que estavam voltando para casa.

Ele se virou.

KAEL — Uma delas me perguntou quando a cidade teria mais espaços para seus filhos aprenderem ofícios. Outra queria saber se haveria novas oportunidades de comércio perto do Eixo Aurora.

Lysa acrescentou:

LYSA — Também temos recebido perguntas de pessoas de fora interessadas em trabalhar aqui.

Lucas ficou atento.

LUCAS — Sério?

LYSA — Sim. Ainda não são compromissos de mudança nem números que possamos tratar como população futura. Mas o interesse existe.

Lucas sorriu.

Kael voltou à mesa.

KAEL — A cidade já está crescendo. Talvez possamos começar a pensar de maneira mais ampla sobre o que queremos oferecer.

Lucas permaneceu quieto.

Depois sorriu ainda mais.

LUCAS — ...É exatamente isso.

Uma batida interrompeu a conversa.

Lysa ergueu a cabeça.

LYSA — Entre.

Uma mulher apareceu à porta.

Carregava uma pasta com anotações e pequenos desenhos.

Era uma representante de atividades comerciais e circulação urbana, chamada Dália, que havia marcado uma conversa com Lysa naquela manhã.

Ao perceber Lucas, ela hesitou.

DÁLIA — Desculpem. Não sabia que estavam reunidos.

Lysa sorriu.

LYSA — Entre, Dália. Estamos conversando sobre algumas possibilidades para a cidade.

A representante observou os papéis.

Depois se aproximou.

DÁLIA — Posso perguntar uma coisa?

Kael assentiu.

KAEL — Claro.

Ela indicou a grande avenida do desenho.

DÁLIA — Isso é uma proposta de ampliação?

Lucas sorriu.

LUCAS — Talvez.

A mulher examinou a folha.

E apontou para uma passagem lateral.

DÁLIA — Se ampliarem por aqui, precisam conversar com as oficinas dessa rua. Há entregas todos os dias.

Lucas assentiu.

LUCAS — Justamente.

Dália continuou observando.

DÁLIA — Mas, se conseguirem melhorar a circulação de carga e criar caminhos mais seguros para quem anda a pé, seria excelente.

Ela apontou para outro setor.

DÁLIA — E aqui poderíamos ter um mercado coberto. As bancas estão crescendo, e algumas não conseguem trabalhar bem quando chove.

Lucas ficou imóvel.

Olhou para o desenho.

Depois para Dália.

Um sorriso absolutamente radiante apareceu em seu rosto.

LUCAS — ...Um mercado coberto.

Dália assentiu.

DÁLIA — Sim.

Lucas virou-se para Kael e Lysa.

LUCAS — COM VITRAIS!

Dália piscou.

DÁLIA — ...Como?

LUCAS — UM MERCADO MAGNÍFICO! ARCOS DE PEDRA! JARDINS! COBERTURA ELEGANTE! BOA VENTILAÇÃO! PASSAGENS AMPLAS!

Kael cobriu o rosto com uma mão.

Lysa começou a rir.

Dália ficou olhando para Lucas.

Depois sorriu.

DÁLIA — Desde que não chova nas mercadorias.

Lucas bateu a mão na mesa.

LUCAS — ESSA MULHER ENTENDE DE PRIORIDADES!

A conversa mudou.

O que começara como uma ideia extraordinária na cabeça de Lucas encontrava agora uma pessoa que conhecia problemas reais de circulação e comércio.

Dália descreveu dificuldades das bancas.

Lysa mencionou iniciativas que a administração já acompanhava.

Kael falou das ligações entre bairros antigos e novos.

Lucas ouviu.

Fez perguntas.

Em alguns momentos, desenhou.

Em outros, riscou uma linha porque uma sugestão era melhor.

Não havia um plano final.

Ainda não.

Mas havia algo que não existia naquela manhã, quando Lucas saíra de casa.

Um encontro entre a ambição de transformar Três Arcos e as pessoas que poderiam fazer daquela transformação algo verdadeiramente seu.

DIA 538 · 11h32 · CASA CÍVICA — SALA DE CONVERSAS

Kael fechou o caderno.

Lysa permaneceu olhando para o último desenho.

Dália precisava retornar a seus compromissos, mas concordou em trazer representantes de outras atividades comerciais para uma conversa posterior.

A reunião maior ainda não havia acontecido.

Nenhuma obra fora declarada aprovada.

Nenhum distrito surgira por antecipação.

Mas a proposta deixara de ser somente um desenho privado.

Kael olhou para Lucas.

KAEL — Precisaremos ouvir mais pessoas.

Lucas assentiu.

LUCAS — Sim.

LYSA — E decidir o que realmente queremos começar.

Ele sorriu.

LUCAS — Sim.

Kael ergueu uma sobrancelha.

KAEL — Você está concordando depressa demais.

Lucas abriu os braços.

LUCAS — PORQUE ESTOU FELIZ!

Lysa começou a rir.

LYSA — Percebi.

Kael apoiou as mãos sobre a mesa.

KAEL — Então me diga uma coisa.

Lucas se inclinou.

LUCAS — Manda.

KAEL — Você consegue materializar construções extraordinárias. Pode resolver em minutos problemas de produção que levariam anos para outras cidades.

Lucas assentiu.

Kael continuou:

KAEL — Temos uma estrutura civil funcionando, especialistas capazes e pessoas interessadas. Não precisamos transformar isso numa espera interminável.

Lysa concordou.

LYSA — Mas também não precisamos fazer tudo na ordem em que apareceu no seu desenho.

Lucas começou a sorrir.

LUCAS — Justo.

Kael apontou para a cidade visível pela janela.

KAEL — Então vamos fazer uma escolha.

O estrategista aproximou o mapa.

A cidade antiga.

As áreas de expansão ainda por estudar.

O Eixo Aurora.

As conexões existentes.

Lucas olhou para aquelas linhas.

Depois para seus amigos.

Lysa sorriu.

LYSA — Qual é o primeiro passo que você quer propor?

Por um instante, Lucas não respondeu.

Não porque lhe faltassem ideias.

Muito pelo contrário.

Havia tantas possibilidades que sua imaginação parecia prestes a incendiar a mesa.

Do lado de fora, uma fonte continuava correndo.

Uma criança atravessava a praça.

Um artesão carregava ferramentas.

E, longe dali, Miren começava outro dia de trabalho em AERÚN, sem imaginar exatamente como aquela conversa terminaria.

Lucas observou o mapa.

Pensou em Salma.

Na senhora da fonte.

Na menina que queria uma ponte para assistir ao pôr do sol.

No aprendiz e suas duas rodas.

Na mulher que amava.

E na cidade que os acolhera.

O SISTEMA surgiu discretamente diante de seus olhos.

SISTEMA — Criador, observo que sua ideia original aumentou consideravelmente desde o início da corrida.

Lucas quase riu.

LUCAS — Aumentou.

SISTEMA — E você parece satisfeito.

Lucas olhou para Kael.

Depois para Lysa.

E sorriu.

LUCAS — Muito.

NÓX se manifestou baixinho.

NÓX — Então talvez seja uma boa oportunidade para começar algo importante.

O Criador assentiu.

Lá fora, o sol avançava sobre os telhados da Cidade Livre.

O mundo continuava vasto.

As antigas potências possuíam suas próprias estradas, fortalezas, povos e ambições.

Além dos mares que Lucas ainda não atravessara, existiam coroas, exércitos e homens que imaginavam que o futuro de um continente deveria pertencer àquele que conseguisse conquistá-lo.

Lucas não sabia nada sobre os planos daqueles homens naquela manhã.

Não precisava saber.

Porque, naquele instante, sua preocupação era outra.

Como transformar uma cidade extraordinária num lugar onde ainda mais pessoas pudessem construir o próprio futuro?

E a resposta começaria com sua próxima decisão.

Às 11h32 do Dia 538, Três Arcos ainda não havia mudado de aparência.

Suas fontes continuavam correndo.

Seus mercados continuavam trabalhando.

Suas crianças continuavam sonhando.

Mas, numa sala da Casa Cívica, três amigos estavam diante de uma possibilidade tão grande que talvez um dia os historiadores se perguntassem onde tudo começara.

E nenhum deles imaginaria que a resposta verdadeira envolveria um cachorro, um carrinho de pão e uma arqueóloga que obrigara o Criador a tomar banho antes do café.

FIM DA PARTE I DE V · CAPÍTULO 1

A CIDADE QUE CABIA EM UM SONHO

O horizonte ainda não mudou. Mas alguém decidiu enxergar mais longe.

WORLDROOT · CHECKPOINT NARRATIVO Rascunho · Não consolidado

Dia e horário

538 · 11h32

Local

Casa Cívica · Três Arcos

Protagonista

Lucas Rodrigues

Próxima etapa

Cap. 1 · Parte II de V

O que aconteceu nesta parte

Lucas viveu uma nova corrida, conheceu necessidades e sonhos dos moradores, imaginou uma transformação extraordinária para Três Arcos e compartilhou a visão primeiro com Miren. Depois apresentou suas ideias a Kael, Lysa e Dália.

O que permanece em aberto

A escolha da primeira intervenção, a extensão do futuro distrito, a expansão tecnológica, os encaminhamentos civis e qualquer manifestação urbana grandiosa de GÊNESE.

Continuidade protegida

GÊNESE plena; Malha Aurora com 3.600 autômatos; Rumo independente; AERÚN sob pesquisa de Miren e Astra; ARGOS única após voo 005. Nenhuma nova vida consciente criada e nenhum conhecimento antecipado sobre o Dominato ou Talis.

Escolha o próximo passo

LIVRO VI · CAPÍTULO 1 · PARTE II DE V · DIA 538

Kael e Lysa aguardam a resposta de Lucas. A decisão poderá mudar a ordem da revolução urbana e o desenvolvimento das próximas cenas.

1 — A cidade que renasce

Lucas propõe começar pela transformação da Três Arcos existente. Um grande encontro com arquitetos, comerciantes, artistas, engenheiros e moradores dará forma à primeira manifestação monumental de GÊNESE.

Foco: arquitetura fantástica, urbanismo, convivência e primeiras criações.

[Escolher opção 1]

2 — O Horizonte Aberto

Lucas propõe priorizar o novo distrito planejado para comportar até 100 mil residentes futuros. Kael e Lysa começam a discutir como essa expansão poderá redefinir a economia, o acolhimento e a identidade da Cidade Livre.

Foco: novo distrito, desenvolvimento urbano, comércio e imigração voluntária.

[Escolher opção 2]

3 — A cidade que conversa com o futuro

Lucas envolve a Forja Aurora e a Costura de Dados numa proposta revolucionária de transporte, comunicação e serviços. Um primeiro encontro de inventores poderá colocar Brannik, Naira, Aurel e os especialistas diante de possibilidades inimagináveis.

Foco: tecnologia arcana, invenções, comunicação e personagens da Forja.

[Escolher opção 3]

4 — ESPECIAL: O dia em que o impossível ficou pequeno

Lucas decide apresentar uma visão integrada e extraordinariamente ousada: renovar a cidade antiga, preparar o Horizonte Aberto e abrir uma nova era de ciência, transporte, comércio, cultura e vida.

Kael, Lysa, Miren, a Forja e os representantes terão iniciativas próprias. GÊNESE poderá produzir manifestações verdadeiramente monumentais, enquanto consequências inesperadas começam a movimentar um mundo muito maior do que Três Arcos.

Não exige concluir todas as obras nesta parte nem determina previamente os resultados.

[Escolher especial 4]

5 — AÇÃO LIVRE: O que Lucas fará?

Você decide exatamente como Lucas responde a Kael e Lysa, podendo combinar ideias, criar outra estratégia ou seguir um caminho completamente diferente.

[Texto de orientação da área de texto: Escreva a decisão, fala ou ação de Lucas...] (Valor atual indisponível.)

[Confirmar ação livre]

Estado de persistência: consultei o HEAD, CONTEXT, o episódio final do Livro V e os materiais de pré-produção na ramificação privada v18, além da política editorial v12 na main. A estrutura do arquivo estava na raiz dessa ramificação, não sob o prefixo story-archive indicado. A nova Parte I foi entregue aqui, mas não foi arquivada no GitHub nem sincronizada com o Drive; o HEAD permanece no encerramento do Livro V. Nenhuma escolha foi executada.


<!-- WORLDROOT LIVRO-VI-C01 PARTE II / LVI-C01-PII-D538-AUTHOR-SOURCE -->

CRÔNICAS DE UM NOVO MUNDO · WORLDROOT · HISTÓRIA VIVA

A ERA DAS NOVE COROAS

LIVRO VI — AS COROAS PARTIDAS

CAPÍTULO 1 — O CRIADOR E A CIDADE DAS MIL FONTES

PARTE II DE V · ESCOLHA 4 — ESPECIAL

TRÊS DIAS. TRÊS MARCOS. TRÊS ARCOS.

“Um homem pode erguer uma maravilha sozinho. Mas é quando outras pessoas começam a imaginá-la com ele que uma cidade descobre o tamanho do próprio futuro.”

CALENDÁRIO DO HORIZONTE

Continuidade

Dia 538 · 11h32

Calendário

Ano II · Mês 06 · Dia 23

Local

Casa Cívica · Três Arcos

Grande proposta

Três dias · Três marcos

O primeiro dia está em andamento. Os acontecimentos dos dias seguintes ainda dependem das decisões e das consequências da história.

I — A proposta mais perigosa que já entrou naquela sala

DIA 538 · 11h32 · CASA CÍVICA — SALA DE CONVERSAS

KAEL — Qual é o primeiro passo que você quer propor?

Lucas permaneceu observando o mapa.

A sala estava silenciosa.

Lysa esperava.

Dália continuava de pé ao lado da mesa, examinando o desenho do mercado coberto que acabara de sugerir.

Do lado de fora, o movimento da cidade seguia normalmente.

Uma carroça passou pela rua.

Alguém chamou um vendedor.

Uma criança começou a rir.

Lucas olhou para a janela.

Depois para o mapa.

Então sorriu.

Não foi um sorriso comum.

Foi aquele sorriso.

O sorriso que seus amigos haviam aprendido a reconhecer depois de quinhentos e trinta e oito dias convivendo com um homem cujas ideias frequentemente começavam com uma pergunta inocente e terminavam alterando a arquitetura da realidade.

Kael percebeu imediatamente.

KAEL — ...Lucas.

LUCAS — Hum?

KAEL — Por que está sorrindo assim?

Lucas ergueu lentamente três dedos.

LUCAS — Porque eu acabei de perceber uma coisa maravilhosa.

Lysa estreitou os olhos.

LYSA — Três dedos?

LUCAS — TRÊS DEDOS!

Dália olhou de um para outro.

DÁLIA — Estou perdendo alguma coisa?

Kael suspirou.

KAEL — Provavelmente nossa tranquilidade.

Lucas apontou para ele.

LUCAS — EXATAMENTE!

KAEL — Isso não era uma resposta favorável.

Lucas se levantou.

Caminhou até a janela.

Olhou para a cidade.

Depois voltou-se para os três.

A expressão ainda carregava aquele entusiasmo absurdo, mas seus olhos haviam adquirido uma concentração diferente.

LUCAS — Eu quero propor três dias.

Kael ergueu uma sobrancelha.

KAEL — Para quê?

Lucas abriu os braços.

LUCAS — Para começarmos a transformação mais extraordinária da história de Três Arcos.

Silêncio.

Lysa pousou a pena.

Dália olhou novamente para o mapa.

Lucas ergueu o primeiro dedo.

LUCAS — Primeiro dia: a cidade que renasce.

Ergueu o segundo.

LUCAS — Segundo dia: o Horizonte Aberto.

Ergueu o terceiro.

Seu sorriso tornou-se gigantesco.

LUCAS — Terceiro dia: a cidade que conversa com o futuro.

Fez uma pausa teatral.

Depois abriu os braços.

LUCAS — TRÊS DIAS!

Apontou para os dedos.

LUCAS — TRÊS MARCOS!

E, finalmente, para a cidade além da janela.

LUCAS — TRÊS ARCOS!

Kael permaneceu imóvel.

Lysa piscou duas vezes.

Dália ficou olhando para Lucas com a expressão de quem acabara de assistir a um fenômeno natural desconhecido.

O silêncio durou três segundos.

Quatro.

Cinco.

Então Kael começou a rir.

Não uma risada discreta.

Uma gargalhada genuína.

Ele se curvou sobre a mesa.

KAEL — VOCÊ PREPAROU ESSA FRASE?!

Lucas abriu os braços, profundamente ofendido.

LUCAS — É UMA OBRA DE COMUNICAÇÃO ESTRATÉGICA!

Lysa já estava rindo também.

LYSA — Você saiu para correr e voltou com um programa de transformação urbana e um lema de campanha?!

LUCAS — EU SOU UM HOMEM DE MÚLTIPLOS TALENTOS!

DÁLIA — E pretende fazer tudo isso em três dias?

Lucas se virou para ela.

O sorriso diminuiu apenas o suficiente para permitir uma resposta séria.

LUCAS — Quero estabelecer três marcos reais em três dias. Não estou dizendo que em três dias teremos cem mil pessoas vivendo aqui, professores contratados em todas as escolas ou acordos com todos os reinos.

Apontou para o mapa.

LUCAS — Mas as construções? As redes? Os espaços? Os equipamentos? Isso eu posso criar.

Kael assentiu lentamente.

Lucas continuou:

LUCAS — Não precisamos fingir que GÊNESE leva meses para manifestar matéria. Podemos fazer coisas gigantescas. E podemos fazê-las direito, ouvindo quem vai usar tudo isso.

Dália cruzou os braços.

DÁLIA — E onde entram os comerciantes?

Lucas sorriu.

LUCAS — Na parte em que vocês me dizem o que eu ainda não entendi.

A resposta pareceu surpreendê-la mais do que a proposta de três dias.

Lysa observou o rosto de Lucas.

Depois olhou para a folha.

LYSA — Certo. Agora quero entender uma coisa.

LUCAS — Manda.

LYSA — Você está propondo três dias de criação, ou três dias em que vamos prometer coisas para o futuro?

Lucas abriu um sorriso absolutamente desavergonhado.

LUCAS — Lysa, meu amor administrativo...

LYSA — Não comece.

LUCAS — ...EU QUERO CRIAR!

Kael soltou outra gargalhada.

LUCAS — Quero que hoje as pessoas possam sair de casa e ver a cidade ficando mais bonita e melhor de viver. Amanhã quero que olhem além dos bairros e encontrem espaço de verdade para nosso futuro. E no terceiro dia quero que a cidade comece a conversar, se movimentar e funcionar de um jeito que esse mundo ainda não imaginou!

A expressão de Lysa mudou.

Ela se inclinou sobre a mesa.

LYSA — Então teremos de decidir quais partes realmente começam a operar em cada dia.

Lucas assentiu.

LUCAS — Exatamente.

Kael sorriu.

KAEL — E a cidade precisará continuar funcionando durante tudo isso.

LUCAS — É por isso que eu quero vocês comigo.

Houve um pequeno silêncio.

Lucas olhou para os dois amigos.

LUCAS — Eu consigo fazer a matéria obedecer. Vocês sabem disso.

Kael assentiu.

LUCAS — Mas vocês conhecem coisas dessa cidade que eu ainda não conheço. E existem moradores que conhecem ainda mais.

Ele olhou para Dália.

LUCAS — Hoje eu quero descobrir essas coisas antes de começar a fazer uma maravilha completamente idiota no lugar errado.

Dália soltou uma risada.

Lysa sorriu.

LYSA — Essa é uma preocupação surpreendentemente sensata.

LUCAS — ESTOU AMADURECENDO!

KAEL — Não estrague o momento.

Foi então que Lucas percebeu o espaço ao redor.

A sala não era pequena.

Mas também não era a maior da Casa Cívica.

Na extremidade oposta havia portas largas que davam acesso a um salão utilizado para encontros públicos, exposições e reuniões de representantes.

Lucas olhou para aquelas portas.

Depois para o mapa.

Depois para Kael.

O sorriso voltou.

Mais perigoso do que antes.

LUCAS — ...Kael.

KAEL — Não.

LUCAS — MAS EU NÃO PERGUNTEI NADA!

KAEL — Você olhou para o salão.

Lysa virou a cabeça.

Observou as portas.

Depois Lucas.

LYSA — ...O que você está pensando?

Lucas caminhou até elas.

Abriu uma das folhas.

O salão estava desocupado naquela parte da manhã.

Havia grandes janelas, um teto elevado e espaço central suficiente para acomodar uma exposição de proporções consideráveis.

Algumas mesas estavam recolhidas junto às paredes.

A luz entrava pelos vitrais superiores.

Lucas permaneceu observando.

Depois se virou.

LUCAS — Posso usar esse espaço?

Kael se levantou.

Aproximou-se.

Examinou o salão.

KAEL — Para quê?

Lucas sorriu.

LUCAS — Uma maquete.

Lysa apareceu atrás deles.

LYSA — De que tamanho?

Lucas abriu os braços.

LUCAS — ...Grande.

Kael fechou os olhos.

KAEL — Naturalmente.

LYSA — Lucas.

LUCAS — Hm?

LYSA — Quanto é grande?

Ele olhou para o teto.

Depois para as paredes.

E respondeu com a seriedade de um engenheiro diante de um problema importantíssimo:

LUCAS — O suficiente para precisarmos afastar as mesas.

II — A cidade que nasceu sobre uma mesa e se recusou a caber nela

DIA 538 · 11h56 · CASA CÍVICA — GRANDE SALÃO

A primeira coisa que Lucas fez foi pedir ajuda.

Não para manifestar a maquete.

Para afastar os móveis.

Dália e um funcionário da Casa Cívica começaram a retirar algumas cadeiras.

Kael ajudou a deslocar duas mesas.

Lysa verificou se o salão poderia permanecer reservado para uma demonstração até o início da tarde e pediu que mantivessem livres os corredores laterais.

Lucas observou tudo com uma expressão satisfeita.

KAEL — Você está nos fazendo mover móveis enquanto possui GÊNESE.

Lucas apontou para ele.

LUCAS — E ESTAMOS FAZENDO UM TRABALHO EXCELENTE!

KAEL — Você poderia simplesmente deslocá-los.

LUCAS — Poderia.

Lucas sorriu.

LUCAS — Mas eu queria ver você carregando essa mesa.

Kael ficou imóvel.

Lysa começou a rir.

KAEL — ...Você é um péssimo amigo.

LUCAS — MAS SOU DIVERTIDO!

Quando o espaço central ficou livre, Lucas caminhou até o meio do salão.

Não retirou nenhum equipamento.

Não precisou preparar um ritual.

Nenhuma nova habilidade havia despertado.

GÊNESE estava com ele como sempre estivera.

Lucas ergueu a mão.

LUCAS — Certo. Antes de criar, uma pergunta.

Lysa cruzou os braços.

LYSA — Qual?

LUCAS — Temos aqui os mapas mais recentes da cidade, certo?

Kael assentiu.

KAEL — Os registros administrativos, os levantamentos de obras e as representações que conseguimos reunir.

LUCAS — Ótimo. Quero usar o que sabemos de verdade.

Dália ergueu uma sobrancelha.

DÁLIA — E o que não sabemos?

Lucas abriu um sorriso.

LUCAS — Vai aparecer como coisa que não sabemos.

Kael o observou.

KAEL — Isso é importante.

Lucas assentiu.

LUCAS — Não vou transformar um desenho bonito numa mentira só porque consigo fazê-lo parecer real.

Kael providenciou os registros cartográficos disponíveis.

Lucas os examinou rapidamente.

Alguns eram detalhados.

Outros haviam recebido anotações posteriores.

Havia informações de reparos na Grande Avenida, redes existentes, distritos e acessos.

Não existia, contudo, um levantamento perfeito de cada parede, terreno particular e estrutura subterrânea.

Lucas não fingiu que existia.

Escolheu representar aquilo que estava documentado.

E reservar espaço para as informações que os próprios moradores e especialistas acrescentariam.

Então se posicionou no centro.

Abriu as mãos.

E falou:

LUCAS — GÊNESE.

Uma linha de luz dourada apareceu no ar.

Não houve explosão.

Primeiro surgiu um traço fino, flutuando a poucos centímetros do piso.

Ele avançou lentamente, desenhando um grande círculo.

Depois outro.

E outro.

A luz encontrou os limites escolhidos por Lucas.

Então começou a ganhar matéria.

Uma plataforma circular se manifestou sobre o chão do salão.

Parecia construída com pedra branca, metal prateado e um material translúcido que deixava pequenas correntes luminosas atravessarem sua superfície.

Não pressionou as estruturas do edifício além da base de apoio preparada por GÊNESE.

Não avançou sobre as portas.

Não bloqueou os corredores.

Simplesmente tomou forma no espaço central.

Dália recuou um passo.

Kael abriu um sorriso.

Lysa permaneceu olhando.

E então aconteceu a segunda coisa.

Sobre a plataforma, pequenas estruturas começaram a se erguer.

Primeiro as linhas dos caminhos conhecidos.

Depois edifícios.

Praças.

Pontes.

Torres.

Telhados.

Muros.

Jardins.

A Grande Avenida.

O Anel dos Ofícios.

Os bairros históricos.

A Casa do Jardim Branco.

O Observatório na Crista do Vento Claro.

As conexões documentadas em direção a AERÚN e ao Campo Aurora.

A cidade surgiu em miniatura.

Não como um único bloco de pedra.

Como milhares de pequenas peças tridimensionais, algumas não maiores que uma unha, cuidadosamente posicionadas dentro de uma representação que permitia ampliar ou recolher setores.

Nas áreas com informações insuficientes, a matéria se tornava translúcida.

Em alguns trechos, pequenas marcas douradas indicavam obras já documentadas.

Em outros, permaneciam espaços sem detalhes.

A maquete era belíssima.

Mas também honesta.

Dália levou a mão à boca.

DÁLIA — ...Pelos deuses.

Kael se aproximou lentamente.

KAEL — Lucas...

Lysa não disse nada.

Estava olhando para uma representação minúscula da Casa Cívica.

A pequena construção possuía janelas.

Arcos.

Degraus.

Até parte da praça à frente.

Lucas fez um movimento com a mão.

A maquete respondeu.

O setor central ampliou-se, enquanto as regiões mais distantes recuaram proporcionalmente.

Dália observou o mercado crescer diante de seus olhos.

DÁLIA — Aquela é minha rua.

LUCAS — É.

Ela aproximou-se.

Apontou.

DÁLIA — ...Mas essa passagem não é tão larga.

Lucas virou a cabeça.

LUCAS — Sério?

Dália assentiu.

DÁLIA — Não desde que ampliaram a oficina de tecidos.

Lucas tocou a borda da plataforma.

A passagem mudou de cor.

Uma anotação apareceu junto à representação.

Dimensão a conferir.

Ele olhou para Dália.

LUCAS — É disso que eu estou falando.

O SISTEMA apareceu diante de seus olhos.

SISTEMA — Representação física criada. A precisão dos elementos depende da qualidade dos registros utilizados.

Lucas sorriu.

LUCAS — Exatamente.

SISTEMA — Sua capacidade de manifestar uma maquete não constitui automaticamente um levantamento cartográfico.

LUCAS — PARCEIRO, HOJE NÓS ESTAMOS CONCORDANDO!

SISTEMA — Um acontecimento estatisticamente incomum.

Lucas gargalhou.

Kael contornou a plataforma.

A maquete parecia ocupar o salão inteiro e, ao mesmo tempo, permitir que as pessoas circulassem ao redor dela.

Pequenos cristais de comando surgiram nas bordas.

Lucas indicou um deles.

LUCAS — Aqui podemos ampliar regiões.

Tocou outro.

LUCAS — Aqui, esconder edifícios e ver as ruas.

Outro.

LUCAS — Aqui, comparar o que existe com o que estamos propondo.

Lysa se aproximou.

LYSA — E podemos modificar as propostas?

Lucas abriu um sorriso gigantesco.

LUCAS — ESSA É A MELHOR PARTE!

Fez um movimento com a mão.

Acima da cidade existente, surgiu uma segunda camada.

Não sólida.

Uma visão translúcida de possibilidades.

A Grande Avenida ganhou galerias elegantes, arborização e pequenas estações integradas à paisagem.

Em alguns bairros, jardins apareceram sobre coberturas adequadas.

Fontes surgiram onde os espaços públicos permitiam.

Pontes de pedra clara atravessaram canais e passagens.

Praças se ampliaram sem apagar automaticamente os edifícios vizinhos.

Grandes edifícios cívicos de inspiração renascentista apareceram em locais ainda marcados como propostas, não obras decididas.

Ao longe, uma região inteira começou a se formar.

Um novo distrito.

Avenidas arborizadas.

Lagos.

Cúpulas.

Mercados.

Pontes.

Parques.

Edifícios residenciais.

E um grande pavilhão cujo telhado lembrava as páginas de um livro aberto.

A maquete não afirmava que aquele terreno já estava disponível.

Sua base permanecia translúcida, sem posição geográfica definitiva.

Era uma possibilidade de desenho.

Dália permaneceu completamente imóvel.

Lysa levou uma das mãos à boca.

Kael observava a cidade como se tivesse recebido uma janela para um século que ainda não existia.

Lucas abriu os braços.

LUCAS — SENHORAS E SENHORES...

Fez uma reverência absolutamente exagerada.

LUCAS — BEM-VINDOS À TRÊS ARCOS QUE AINDA NÃO EXISTE!

Silêncio.

Depois Lysa começou a rir.

LYSA — Você ensaiou isso também?

LUCAS — EU SOU UM ARTISTA DA APRESENTAÇÃO!

Kael não conseguiu conter o sorriso.

KAEL — Lucas... isso é extraordinário.

Lucas olhou para ele.

O entusiasmo deu lugar a uma expressão mais sincera.

LUCAS — Obrigado.

Mas logo apontou para a plataforma.

LUCAS — E AINDA NÃO TERMINOU!

O centro da maquete se iluminou.

Pequenas correntes de luz azul começaram a percorrer as ruas.

Não eram sistemas de transporte já instalados.

Eram trajetos projetados.

Linhas finas mostravam como uma futura rede de mobilidade poderia conectar bairros.

Outras representavam possibilidades de água, drenagem, energia e comunicação.

A tecnologia permitia comparar cenários sem alterar a cidade real.

Lucas aproximou duas pequenas estruturas.

Uma se ergueu no bairro histórico.

Outra apareceu perto do mercado.

Entre elas, surgiu uma passagem.

Dália inclinou a cabeça.

DÁLIA — Essa ligação seria útil.

Lysa apontou para o lado oposto.

LYSA — Mas concentraria circulação perto de uma escola.

Lucas olhou.

LUCAS — Verdade.

Com um gesto, deslocou a rota proposta para outro corredor.

Kael se inclinou.

KAEL — Ali temos uma subida considerável.

Lucas sorriu.

LUCAS — Então podemos atravessá-la de outro jeito.

Uma ponte elegante apareceu na maquete.

Dália abriu um sorriso.

DÁLIA — Isso ficaria bonito.

Kael observou.

KAEL — E pode funcionar se respeitar os acessos existentes.

Lucas abriu os braços.

LUCAS — ESTÃO VENDO?!

Os três olharam para ele.

LUCAS — É EXATAMENTE ISSO!

Ele apontou para a maquete.

LUCAS — Não quero que vocês fiquem apenas olhando para a minha ideia.

A expressão dele tornou-se séria.

LUCAS — Quero que encontrem os erros.

Uma pausa.

LUCAS — Quero que me digam o que eu não vi.

Dália ergueu os olhos.

Lucas continuou:

LUCAS — Quero saber o que está faltando, o que vocês gostariam de ter, o que os moradores precisam e o que a gente pode fazer de mais extraordinário.

Olhou para Kael.

Depois para Lysa.

LUCAS — Não quero mostrar uma cidade pronta e perguntar se gostaram.

Apontou para a plataforma.

LUCAS — Quero descobrir com vocês qual cidade merece ser construída.

Kael permaneceu observando Lucas por alguns segundos.

Depois abriu um sorriso.

KAEL — Então vamos precisar de mais gente nesta sala.

Lucas abriu os braços.

LUCAS — FINALMENTE!

Lysa assentiu.

LYSA — Pessoas que conheçam os bairros, os ofícios, a manutenção e os serviços.

Dália ergueu a mão.

DÁLIA — E alguém que realmente saiba como funciona a circulação das mercadorias.

Lucas apontou para ela.

LUCAS — VOCÊ ACABA DE SER PROMOVIDA A MINHA CRÍTICA FAVORITA!

Dália soltou uma gargalhada.

DÁLIA — Isso vem acompanhado de salário?

Lysa começou a rir.

Kael também.

Lucas ficou imóvel.

Depois levou a mão ao peito.

LUCAS — ...EU FUI DERROTADO POR UMA COMERCIANTE!

O salão já não parecia uma sala de reuniões.

Era uma janela para o futuro.

E, pela primeira vez naquela manhã, a ideia de Lucas havia se tornado suficientemente concreta para que outras pessoas começassem a transformá-la.

III — O dia em que todos receberam permissão para criticar o Criador

DIA 538 · 12h24 · CASA CÍVICA — GRANDE SALÃO

Brannik entrou primeiro.

Naturalmente.

E entrou gritando.

BRANNIK — ONDE ESTÁ ESSA INVENÇÃO ABSURDA?!

Kael, que conversava com uma responsável pelos serviços urbanos, fechou os olhos.

KAEL — ...Ele chegou.

O anão atravessou a porta carregando um conjunto de instrumentos, dois cadernos e uma peça mecânica cuja finalidade ninguém lhe perguntara.

Atrás dele vinham Aída e Aurel.

Dorek apareceu pouco depois, acompanhado de Alíria, que trazia registros da Forja.

Naira continuava ocupada com ARGOS no Campo Aurora e não havia abandonado a inspeção da aeronave. Concordara em participar de uma conversa técnica pela Costura de Dados, caso os projetos afetassem a região aeroportuária.

Téria, dos serviços urbanos, chegara por outra entrada com Hedra, que acompanhava questões de mobilidade e acessibilidade.

Dália havia trazido duas pessoas que trabalhavam diretamente com circulação comercial.

Não era o conselho inteiro.

Tampouco uma multidão de espectadores.

Eram pessoas capazes de dar respostas concretas às perguntas que Lucas havia feito.

Brannik parou diante da maquete.

Olhou.

Piscou.

Aproximou-se.

Olhou novamente.

BRANNIK — ...

Lucas cruzou os braços, satisfeito.

LUCAS — Bom dia, meu pequeno e glorioso desastre da engenharia.

Brannik não respondeu.

Deu mais três passos.

Examinou a cidade em miniatura.

Depois abriu lentamente a boca.

BRANNIK — ...VOCÊ...

Apontou para a plataforma.

BRANNIK — ...FEZ...

Lucas começou a sorrir.

BRANNIK — ...UMA CIDADE...

O anão abriu os braços.

BRANNIK — ...DENTRO DE UMA SALA?!

Lucas levantou os dois punhos.

LUCAS — HAHAHA! EU SABIA QUE VOCÊ IA GOSTAR!

Brannik correu para o outro lado da plataforma.

BRANNIK — ISSO AUMENTA?!

LUCAS — AUMENTA!

BRANNIK — ISSO DIMINUI?!

LUCAS — DIMINUI!

BRANNIK — ISSO MOSTRA O INTERIOR DOS PRÉDIOS?!

LUCAS — DOS QUE TIVEREM INFORMAÇÕES DOCUMENTADAS OU MODELOS PROPOSTOS, SIM!

Brannik ficou imóvel.

Virou-se para Kael.

BRANNIK — EU QUERO UMA!

KAEL — Bom dia para você também.

Aída se aproximou da maquete.

Ao contrário de Brannik, não gritou.

Examinou as construções propostas, os pequenos corredores de circulação e os espaços que poderiam receber oficinas.

Depois levantou os olhos.

AÍDA — Lucas.

LUCAS — Sim?

Ela apontou para o novo distrito translúcido.

AÍDA — Você está reservando algum espaço para produtores pequenos?

Lucas sorriu.

LUCAS — Sim. Mas quero ouvir sua ideia.

Aída indicou dois setores.

AÍDA — Aqui você colocou oficinas muito próximas das residências. Algumas atividades poderão funcionar assim. Outras produzem ruído, calor e movimentação pesada.

A maquete ampliou-se sob o comando de Lucas.

AÍDA — Eu faria uma separação por tipo de atividade. Não por importância do ofício.

LUCAS — Gostei.

AÍDA — E gostaria que artesãos de outras regiões pudessem instalar oficinas sem precisar começar comprando instalações enormes.

Lysa ergueu os olhos.

LYSA — Espaços compartilhados?

AÍDA — Talvez. Oficinas que possam ser utilizadas por diferentes profissionais, com responsabilidade clara sobre equipamentos.

Lucas começou a sorrir.

LUCAS — Um centro de invenções aberto para aprendizes e mestres...

Aída ergueu um dedo.

AÍDA — Para pessoas que saibam trabalhar com segurança.

LUCAS — ...E QUE POSSAM APRENDER A TRABALHAR COM SEGURANÇA!

Ela sorriu.

AÍDA — Melhor.

Dorek observava a representação dos corredores subterrâneos.

DOREK — Posso fazer uma pergunta desagradável?

Lucas abriu os braços.

LUCAS — VOCÊS ESTÃO ADORANDO ESSA FRASE HOJE!

Dorek apontou para uma das linhas.

DOREK — Você está pensando em instalar transporte e serviços sob as ruas?

LUCAS — Em alguns lugares, sim.

DOREK — Então quero saber o que existe onde pretende passar.

Lucas assentiu.

LUCAS — Também quero.

Dorek aproximou uma camada da maquete.

DOREK — Podemos construir conduítes novos perfeitamente. Mas, se o projeto desconhecer uma estrutura antiga, o problema será de localização, não de fabricação.

Aurel acrescentou:

AUREL — Podemos comparar mapas, registros de manutenção e os trechos já abertos pelas equipes.

Lucas sorriu.

LUCAS — Perfeito.

Dorek observou-o.

DOREK — Você não vai insistir que seu primeiro desenho está certo?

Lucas inclinou a cabeça.

LUCAS — Dorek, meu querido, eu posso criar outro desenho em dois segundos.

Abriu os braços.

LUCAS — POR QUE DIABOS EU INSISTIRIA NUM DESENHO RUIM?!

O engenheiro ficou imóvel.

Depois soltou uma gargalhada inesperada.

DOREK — ...Esse é um excelente argumento.

Brannik gritou do outro lado:

BRANNIK — FOI O QUE EU DISSE SOBRE MINHA TRANSMISSÃO!

DOREK — Você insistiu numa transmissão ruim durante três ensaios.

BRANNIK — PORQUE EU ACREDITAVA NELA!

LUCAS — É UMA QUESTÃO DE FÉ MECÂNICA!

A sala inteira começou a rir.

A pergunta de Hedra

Hedra não estava rindo.

Não porque tivesse desaprovado a maquete.

Estava examinando uma das pequenas estações que Lucas desenhara perto da Grande Avenida.

Quando os outros se aproximaram, ergueu os olhos.

HEDRA — Posso mostrar uma coisa?

Lucas assentiu imediatamente.

LUCAS — Claro.

Ela indicou a estação.

HEDRA — Aqui você colocou uma passagem lateral para quem precisa embarcar.

LUCAS — Sim.

HEDRA — E aqui uma escadaria.

Lucas observou.

LUCAS — ...Verdade.

HEDRA — O que acontece com alguém que não consegue subir os degraus?

Ele movimentou a projeção.

Uma rampa apareceu.

Hedra examinou.

HEDRA — Melhor. Mas veja o espaço necessário.

Lucas ampliou novamente a região.

A rampa atravessava parte do lugar reservado a uma pequena banca comercial.

Ele parou.

Hedra cruzou os braços.

HEDRA — Entendeu?

Lucas olhou para a banca.

Depois para a estação.

LUCAS — Não basta acrescentar uma passagem acessível depois que o resto está decidido.

Ela sorriu.

HEDRA — Exatamente.

Lucas ficou pensativo.

Então seus olhos se iluminaram.

LUCAS — E se o acesso principal já nascesse no mesmo nível?

Hedra se inclinou.

HEDRA — Mostre.

Ele modificou a maquete.

A estação desceu ligeiramente, integrando-se ao nível da passagem principal. A plataforma reorganizou os acessos, sem exigir que o espaço comercial desaparecesse.

Hedra examinou a solução.

Depois apontou para uma curva.

HEDRA — Ainda precisamos verificar o trajeto real e as condições de embarque. Mas essa configuração é muito mais interessante.

Lucas abriu um sorriso.

LUCAS — ENTÃO FICA COMO PROPOSTA!

Ela assentiu.

HEDRA — Para avaliarmos.

Ele apontou para Hedra.

LUCAS — VOCÊ É PERIGOSA!

HEDRA — Muito.

Téria, que acompanhara a conversa, aproximou-se da representação do mercado.

TÉRIA — Tenho outra questão.

Lucas olhou para ela.

LUCAS — Manda.

Ela apontou para o desenho de uma fonte monumental.

TÉRIA — Onde essa água vai circular?

Lucas franziu a testa.

LUCAS — Num sistema fechado de recirculação, com reservação e tratamento próprio.

Téria assentiu.

TÉRIA — Bom. Porque não quero descobrir que uma praça lindíssima está consumindo água destinada ao abastecimento.

Lucas sorriu.

LUCAS — Nem eu.

Ela apontou para as ruas.

TÉRIA — E quero que as redes da cidade antiga continuem funcionando enquanto forem melhoradas.

Lucas assentiu.

LUCAS — Podemos criar sistemas novos e independentes, testar e depois conectar.

TÉRIA — Excelente. Então você acabou de me dar uma das melhores notícias do dia.

LUCAS — Qual?!

TÉRIA — Não teremos de interromper o abastecimento de um bairro inteiro para descobrir se um novo projeto funciona.

Lucas levantou os braços.

LUCAS — ESSE É O ESPÍRITO!

A conversa prosseguiu.

Mas já não se parecia com uma exposição da invenção de Lucas.

A maquete havia se tornado um lugar onde pessoas discordavam, corrigiam e imaginavam juntas.

E Lucas estava adorando.

Até que Dália fez a pergunta que mudaria o rumo da tarde.

DÁLIA — Posso mostrar uma coisa que não gostei?

Lucas virou-se imediatamente.

LUCAS — POR FAVOR!

Ela apontou para uma das grandes galerias projetadas sobre o mercado antigo.

Era belíssima.

Arcos monumentais.

Colunas.

Vitrais.

Uma cobertura magnífica sobre as bancas.

Dália observou tudo por alguns segundos.

Depois apontou para uma pequena fachada.

DÁLIA — Esta loja pertence a uma família que trabalha ali há muitos anos.

Lucas assentiu.

DÁLIA — Sua galeria fica tão bonita que quase esconde a entrada.

O salão ficou silencioso.

Lucas aproximou a representação.

A fachada permanecia ali.

Mas era verdade.

O novo conjunto monumental roubava parte de sua visibilidade.

Dália cruzou os braços.

DÁLIA — Quero uma cidade bonita. Mas não quero que os comerciantes antigos pareçam ter sido colocados no fundo de uma exposição.

Lucas observou a maquete.

Durante alguns segundos, não respondeu.

Depois sorriu.

LUCAS — ...Você tem razão.

Com um movimento, recolheu parte da galeria.

As colunas mudaram de posição.

A cobertura ficou mais elevada e se abriu para a rua.

As fachadas antigas voltaram a ocupar o primeiro plano.

A nova construção tornou-se uma extensão da arquitetura existente, não uma parede escondendo-a.

Dália observou.

Aproximou-se.

Depois sorriu.

DÁLIA — Assim.

Lucas abriu os braços.

LUCAS — MUITO MELHOR!

Lysa ficou olhando para os dois.

LYSA — Acabamos de evitar uma reforma que teria deixado algumas pessoas profundamente irritadas.

Lucas assentiu.

LUCAS — E ainda ficou mais bonito.

Kael observou a maquete.

Depois olhou para os presentes.

KAEL — Acho que encontramos a maneira de trabalhar.

IV — AERÚN também tinha algo a dizer

DIA 538 · 13h18 · AERÚN — GALERIA DE PESQUISA

Miren estava examinando um registro antigo quando Astra entrou.

A galeria permanecia iluminada por uma combinação de luz natural e instrumentos arcanos.

Sobre uma bancada repousavam cópias de transcrições, desenhos de canais de mana e registros experimentais que as pesquisadoras vinham comparando havia dias.

Nenhum deles oferecia uma resposta completa sobre a Rede dos Arquitetos.

O Coração de Convergência continuava selado sob Três Arcos.

Sua função conhecida de receber e redistribuir mana era apenas uma parte de um sistema que permanecia incompreendido.

E os procedimentos deixados por Tessa Arin ainda exigiam investigação.

Astra pousou uma folha sobre a mesa.

ASTRA — Recebemos uma solicitação da Casa Cívica.

Miren ergueu os olhos.

MIREN — Sobre?

Astra sorriu discretamente.

ASTRA — Uma maquete.

Miren permaneceu imóvel.

Depois fechou os olhos.

MIREN — ...Lucas.

Astra começou a rir.

ASTRA — Ele está na Casa Cívica com Kael, Lysa e vários especialistas.

Miren sorriu.

MIREN — A ideia cresceu.

ASTRA — Muito?

Miren inclinou a cabeça.

MIREN — Ele estava falando de transformar a cidade inteira durante o café da manhã.

Astra ficou em silêncio.

Depois abriu um sorriso.

ASTRA — Ah.

Uma pausa.

ASTRA — Então uma maquete parece uma evolução bastante modesta.

Miren soltou uma gargalhada.

A solicitação não exigia que as duas interrompessem suas pesquisas.

Havia um pedido para examinar as futuras conexões urbanas próximas à parte pública de AERÚN.

Miren estudou o documento.

Depois apontou para uma representação de acesso.

MIREN — Eles precisam distinguir esta passagem pública do corredor de pesquisa.

Astra assentiu.

ASTRA — E manter separados os sistemas de comunicação cívica e os arquivos protegidos.

MIREN — Sim.

Ela pegou a pena.

Fez algumas anotações.

Astra observou o desenho.

ASTRA — Você gostou da proposta?

Miren demorou um instante.

Depois sorriu.

MIREN — Muito.

Olhou pela janela.

As torres e jardins de AERÚN se estendiam além da galeria.

MIREN — Imagine quantas pessoas poderíamos receber para estudar aqui se a cidade tivesse mais lugares para morar, novas bibliotecas e uma rede de comunicação melhor.

Astra acompanhou seu olhar.

ASTRA — Seria extraordinário.

Miren assentiu.

Depois olhou para a bancada.

MIREN — E ainda precisaríamos terminar isto.

Astra sorriu.

ASTRA — Naturalmente.

A arqueóloga tocou uma das transcrições.

Uma pequena irregularidade entre duas cópias permanecia sem explicação.

Não era uma descoberta conclusiva.

Nem uma mensagem secreta recentemente decifrada.

Mas era uma questão real, identificada pela equipe, que ainda precisava ser investigada.

MIREN — Quero que comparemos novamente essas duas versões antes de atribuir qualquer significado à diferença.

ASTRA — Concordo. Também podemos solicitar uma revisão independente da leitura.

Miren assentiu.

Por um instante, seus olhos repousaram sobre outro conjunto de anotações.

O nome de Talis não estava ali.

Nenhuma notícia nova havia chegado sobre sua irmã.

A ausência continuava.

Miren não precisava transformar toda manhã em uma lembrança dolorosa para que aquilo permanecesse importante.

Ela fechou cuidadosamente o caderno.

MIREN — Vamos responder à Casa Cívica e continuar nosso trabalho.

Astra sorriu.

ASTRA — Nessa ordem?

Miren abriu um sorriso travesso.

MIREN — Melhor respondermos primeiro, antes que meu marido decida colocar uma estação de passageiros no meio dos nossos laboratórios.

Astra começou a rir.

13h41 · CASA CÍVICA — GRANDE SALÃO

A imagem de Miren apareceu sobre o terminal regional já existente na Casa Cívica.

A Costura de Dados funcionava ali como já funcionara em encontros anteriores entre os pontos autorizados.

Não havia rede continental.

Nem comunicação universal.

Aquela era uma ligação regional, solicitada e aceita.

Lucas virou-se imediatamente.

LUCAS — AMOOOOOR!

Miren sorriu na projeção.

MIREN — Bom dia outra vez, meu grande urbanista.

Brannik ergueu os olhos.

BRANNIK — MIREN! VOCÊ PRECISA VER ISSO!

Ela examinou o salão pela imagem.

A maquete aparecia ao fundo.

Miren abriu os olhos um pouco mais.

MIREN — ...Nossa.

Lucas colocou as mãos na cintura.

LUCAS — EU SEI!

Ela o observou.

Depois sorriu.

MIREN — Ficou linda.

Lucas apontou para Kael.

LUCAS — OUVIRAM?!

Kael soltou uma gargalhada.

Lysa balançou a cabeça.

MIREN — Mas tenho algumas observações.

Lucas deixou os braços caírem.

LUCAS — ...EU SABIA.

A sala inteira começou a rir.

Miren apresentou as preocupações de AERÚN.

Falou das conexões públicas.

Das áreas científicas protegidas.

Da necessidade de separar pesquisa confidencial de serviços urbanos.

E de como novos espaços de educação poderiam permitir que estudantes e professores se aproximassem da Cidadela sem comprometer os laboratórios.

Lucas ouviu atentamente.

Depois mostrou a versão atualizada da maquete.

Uma pequena alameda surgiu no modelo.

Árvores.

Pavilhões.

Uma biblioteca.

Passagens para pedestres.

E, ao final, uma praça pública voltada para a entrada civil de AERÚN.

Miren sorriu.

MIREN — Gostei dessa ligação.

LUCAS — Pensei em algo como uma Alameda do Saber.

Astra, que aparecia ao lado de Miren, inclinou a cabeça.

ASTRA — Um nome bonito.

Miren examinou a região.

MIREN — Podemos estudar como ela se conectaria aos futuros espaços de ensino.

Lucas abriu um sorriso.

LUCAS — E uma praça com uma fonte enorme!

Miren ergueu uma sobrancelha.

MIREN — Quantas fontes você pretende colocar nessa cidade?

Lucas abriu os braços.

LUCAS — SIM!

Houve silêncio.

Astra começou a rir.

Kael também.

Miren fechou os olhos.

MIREN — ...Essa não foi uma resposta numérica.

LUCAS — FOI UMA RESPOSTA ARTÍSTICA!

Antes de encerrar, Miren observou o rosto dele.

A empolgação era impossível de esconder.

Mas havia algo mais.

Uma satisfação que ela reconhecia.

A mesma que vira quando ARGOS pousara e Lucas encontrara seus companheiros comemorando.

Não era apenas a alegria de ter criado uma coisa extraordinária.

Era a alegria de ver outras pessoas tornando a ideia melhor.

MIREN — Lucas.

Ele ergueu os olhos.

LUCAS — Oi, amor.

MIREN — Estou orgulhosa de você.

O sorriso dele mudou.

Por um instante, o homem escandaloso desapareceu.

Restou apenas o marido.

LUCAS — ...Obrigado.

Miren sorriu.

MIREN — Mas não esqueça de almoçar.

Lucas arregalou os olhos.

LUCAS — AMOR!

MIREN — Você esqueceu, não esqueceu?

Silêncio.

Kael olhou para o relógio.

Lysa cruzou os braços.

Brannik ficou imóvel.

Então Lucas falou:

LUCAS — ...Tecnicamente...

Miren começou a rir.

MIREN — Eu sabia.

A ligação terminou depois de algumas combinações de trabalho.

Miren e Astra voltaram à pesquisa.

Lucas recebeu uma refeição enviada por um serviço próximo, depois de Lysa declarar que não aceitaria um inventor desmaiando de fome no meio do salão.

Ele comeu.

Reclamou teatralmente.

Comeu mais.

E, quando terminou, estava pronto para fazer uma pergunta muito importante.

V — A primeira pedra de uma cidade impossível

DIA 538 · 14h22 · CASA CÍVICA — GRANDE SALÃO

LUCAS — Então... podemos começar?

A pergunta pareceu simples.

Mas provocou um silêncio diferente.

Não aquele silêncio de espanto diante da maquete.

Era o silêncio de pessoas que compreendiam que a diferença entre uma ideia e uma transformação real podia estar numa única decisão.

Kael observou os representantes.

Depois o mapa.

KAEL — Podemos começar pelas áreas públicas identificadas, cujos usos e acessos conhecemos.

Lysa assentiu.

LYSA — E não vamos transformar isso num projeto que pertença apenas a esta sala.

Dália cruzou os braços.

DÁLIA — Há comerciantes que gostariam de opinar sobre as próprias ruas.

TÉRIA — E equipes que já possuem intervenções programadas.

Lucas sorriu.

LUCAS — Ótimo.

Kael o observou.

KAEL — Você está surpreendentemente tranquilo.

LUCAS — Porque eu tive uma ideia.

Lysa soltou um suspiro.

LYSA — Outra?

LUCAS — UMA MELHOR!

Ele apontou para a maquete.

LUCAS — Por que precisamos escolher entre a cidade participar e a obra acontecer depressa?

Téria ergueu os olhos.

Lucas continuou:

LUCAS — Podemos começar por lugares onde as intervenções já estão definidas e liberadas. As equipes vão para os bairros. Os responsáveis trabalham com os moradores. E eu manifesto o que for necessário.

Aída ficou pensativa.

AÍDA — Várias frentes de trabalho.

LUCAS — Exatamente.

AUREL — Com comunicação entre elas.

LUCAS — SIM!

Dorek apontou para a maquete.

DOREK — E os trechos não verificados permanecem identificados para avaliação.

Lucas sorriu.

LUCAS — PERFEITO!

Kael olhou para Lysa.

Ela assentiu lentamente.

LYSA — Podemos utilizar os procedimentos municipais já existentes, ampliar as equipes de consulta nas áreas afetadas e começar sem suspender o funcionamento normal da cidade.

Dália ergueu uma sobrancelha.

DÁLIA — E quem não gostar?

Lucas respondeu antes dos outros:

LUCAS — Fala.

Ela ficou olhando para ele.

LUCAS — E a gente escuta. Se alguém tiver uma ideia melhor, usamos a melhor.

Dália sorriu.

DÁLIA — Você vai receber muitas opiniões.

Lucas abriu um sorriso absolutamente gigantesco.

LUCAS — MARAVILHOSO!

Kael começou a rir.

KAEL — Você ainda não sabe o que está pedindo.

LUCAS — SEI SIM!

Uma pausa.

LUCAS — ...Acho.

Uma movimentação começou a tomar conta do salão.

Não uma mobilização militar.

Uma coisa muito mais estranha.

Os representantes passaram a conversar sobre lugares que conheciam.

Téria trouxe as frentes já liberadas pelos serviços urbanos.

Hedra examinou os percursos de acessibilidade.

Dália indicou as passagens comerciais em que havia consenso para intervenções.

Aída e os especialistas da Forja selecionaram sistemas que poderiam ser integrados às obras sem transformar todas as ruas em campos de ensaio.

Lysa organizou a participação municipal e os responsáveis pelas áreas públicas.

Kael coordenou os acessos e os avisos aos bairros.

E Lucas...

Lucas estava diante da maquete.

Com um sorriso tão grande que Brannik finalmente perguntou:

BRANNIK — VOCÊ ESTÁ FELIZ DEMAIS!

Lucas virou a cabeça.

LUCAS — BRANNIK!

BRANNIK — O QUÊ?!

LUCAS — VAMOS FAZER UMA CIDADE LINDA PRA CARAMBA!

O anão abriu os braços.

BRANNIK — FINALMENTE ALGUÉM FALOU A COISA MAIS IMPORTANTE!

Dorek fechou os olhos.

DOREK — ...Pelos deuses.

O encontro com Vértice

Às 14h49, Vértice chegou ao salão.

Não trouxe uma tropa de autômatos.

Veio acompanhado de uma responsável pelas operações municipais da Malha Aurora.

Sua presença fora solicitada para verificar quais equipes poderiam apoiar os trabalhos sem abandonar serviços já em andamento.

O coordenador examinou a maquete.

Permanecendo imóvel por alguns segundos.

VÉRTICE — Representação urbana identificada.

Lucas abriu um sorriso.

LUCAS — BONITA, NÉ?!

Vértice observou uma das regiões ampliadas.

VÉRTICE — Muito.

Lucas ficou imóvel.

Depois levou a mão ao peito.

LUCAS — ...VOCÊ ACABOU DE ME ELOGIAR?!

VÉRTICE — Sim.

Kael começou a rir.

Vértice prosseguiu:

VÉRTICE — A representação também permite identificar conflitos entre serviços e circulação, desde que as informações de origem sejam confiáveis.

Lysa assentiu.

LYSA — É por isso que precisamos da sua equipe.

O autômato virou-se para ela.

VÉRTICE — Quais atribuições serão necessárias?

Téria começou a explicar.

A Malha já possuía 3.600 unidades físicas estabelecidas, distribuídas por diferentes atividades e em diferentes estágios de qualificação profissional.

Algumas poderiam apoiar a movimentação de equipamentos e a preparação das áreas.

Outras continuariam em seus serviços habituais.

Vértice não precisaria inventar uma segunda rede.

Nem receber autoridade sobre a cidade.

A tarefa seria coordenar tecnicamente os meios que estivessem disponíveis sob os responsáveis civis.

Lucas observou o autômato.

LUCAS — Vértice.

VÉRTICE — Sim, Lucas.

LUCAS — Quero uma coisa.

VÉRTICE — Diga.

Lucas sorriu.

LUCAS — Nada de abandonar os serviços que já funcionam só porque eu tive uma ideia gigantesca.

VÉRTICE — Compreendido.

LUCAS — E, se precisarmos de mais equipamentos, mais unidades ou sistemas especializados, podemos criar.

Vértice inclinou a cabeça.

VÉRTICE — Isso amplia as possibilidades operacionais.

Lucas apontou para ele.

LUCAS — EXATAMENTE!

Uma pausa.

VÉRTICE — Posso fazer uma observação?

Lucas abriu os braços.

LUCAS — MANDA!

VÉRTICE — A nova maquete é suficientemente grande para permitir treinamentos práticos de planejamento urbano em escala reduzida.

O silêncio durou um instante.

Lucas olhou para Vértice.

Depois para a plataforma.

Seus olhos se iluminaram.

LUCAS — ...Você quer usar minha invenção para ensinar?

VÉRTICE — Considero uma utilização valiosa.

Lucas começou a sorrir lentamente.

LUCAS — ...Meu parceiro.

Aproximou-se.

Pousou uma mão sobre o ombro do coordenador.

LUCAS — Você acaba de melhorar minha ideia.

Brannik soltou um grito.

BRANNIK — EU QUERO DAR AULAS COM ISSO!

Dorek respondeu imediatamente:

DOREK — Primeiro vamos estabelecer quem poderá tocar nos controles.

BRANNIK — ISSO É DISCRIMINAÇÃO CONTRA INVENTORES!

A sala inteira gargalhou.

VI — A cidade abriu os olhos

DIA 538 · 15h37 · MERCADO DOS OFÍCIOS — PRAÇA DO ACESSO ANTIGO

O primeiro lugar escolhido não foi o maior.

Não foi o mais impressionante.

Nem o que oferecia a melhor vista.

Foi a passagem onde Salma havia ficado presa com seu carrinho de pão.

Quando Lucas chegou, a comerciante estava trabalhando.

A entrega da manhã já terminara.

Algumas pessoas haviam sido avisadas sobre a intervenção pública.

As bancas próximas permaneciam abertas, com rotas alternativas preparadas para os clientes.

Téria conversava com os profissionais responsáveis pela área.

Hedra acompanhava a adequação das passagens.

Dália estava ao lado dos comerciantes.

Kael observava a circulação.

Lysa permanecera na Casa Cívica por mais algum tempo para encaminhar os trabalhos e chegaria depois.

Lucas olhou para Salma.

Abriu um sorriso.

LUCAS — BOM DIA NOVAMENTE!

Salma virou a cabeça.

Depois olhou para as equipes.

Para os instrumentos.

Para os pequenos marcadores colocados sobre o chão.

E finalmente para Lucas.

SALMA — ...Você realmente voltou.

LUCAS — EU SOU UM HOMEM DE PALAVRA!

Ela cruzou os braços.

SALMA — Vai consertar a passagem?

Lucas sorriu.

LUCAS — Entre outras coisas.

Salma estreitou os olhos.

SALMA — Lucas.

LUCAS — Sim?

SALMA — O que significa "entre outras coisas"?

Ele abriu um sorriso absolutamente malicioso.

LUCAS — ...A senhora gosta de fontes?

Salma ficou imóvel.

Depois levou a mão à testa.

SALMA — Pelos deuses.

Os responsáveis confirmaram a área.

Não havia mercadorias sobre a faixa destinada à intervenção.

As entradas permaneceriam acessíveis.

Nenhuma propriedade privada seria alterada sem acordo.

Os serviços existentes haviam sido identificados no trecho.

E, onde as informações não eram suficientes, a intervenção física ficaria restrita à parte efetivamente conhecida.

Lucas examinou tudo.

Depois sorriu.

LUCAS — Certo.

Ajoelhou-se.

Tocou o pavimento.

A pedra estava fria.

Uma pequena irregularidade permanecia junto ao encaixe da passagem antiga.

Ele se lembrou do carrinho preso.

Do aprendiz tentando ajudar.

De Salma segurando as cestas.

E ergueu os olhos.

LUCAS — Vamos começar por aqui.

O primeiro sinal foi um fio dourado.

Muito fino.

Ele surgiu sob a mão de Lucas e percorreu a superfície delimitada.

Não quebrou a pedra.

Não lançou fragmentos pelos ares.

Simplesmente desenhou um caminho luminoso entre as estruturas existentes.

Depois outro.

E outro.

Os comerciantes recuaram para observar.

Uma criança soltou uma exclamação de surpresa.

CRIANÇA — Olha!

O chão começou a mudar.

As antigas pedras, na região liberada, ergueram-se alguns centímetros.

Permaneceram suspensas.

Não como escombros arrancados violentamente.

Como peças cuidadosamente retiradas de uma construção.

Abaixo delas, uma nova estrutura começou a surgir.

Camadas de sustentação.

Canaletas preparadas para drenagem.

Passagens técnicas independentes onde os registros permitiam.

Bases ajustadas às entradas existentes.

Depois a superfície voltou a se formar.

Mas não exatamente como antes.

As irregularidades desapareceram.

A passagem tornou-se contínua.

O acabamento acompanhava a arquitetura do mercado, com faixas de pedra clara e pequenos detalhes em tons azulados.

Os degraus inadequados da área pública deram lugar a uma transição mais suave.

Uma nova calçada surgiu ao lado, separada do percurso de cargas.

Os espaços de travessia se tornaram mais claros.

E, onde antes havia uma pequena área de acúmulo de água, apareceu um conjunto elegante de drenagem integrado ao desenho do piso.

Tudo isso aconteceu em instantes.

Não porque o poder precisasse aprender como realizar a tarefa.

Mas porque Lucas já sabia o que desejava manifestar.

O silêncio foi absoluto.

Uma fruta caiu de uma cesta.

Ninguém percebeu.

Salma olhava para o chão.

Depois para Lucas.

Depois novamente para o chão.

SALMA — ...Acabou?

Lucas abriu um sorriso.

LUCAS — A CRIAÇÃO, SIM!

Téria se aproximou.

Examinou o sistema.

Os técnicos começaram a verificar os elementos de drenagem e a continuidade dos percursos.

Hedra passou pela nova superfície.

Testou a transição.

Depois sorriu.

HEDRA — Muito melhor.

Lucas cruzou os braços.

LUCAS — EU SEI!

Ela apontou para outra parte.

HEDRA — Quero verificar aquela curva também.

Lucas abaixou os braços.

LUCAS — ...EU SABIA QUE VINHA UMA SEGUNDA FRASE!

Hedra começou a rir.

Salma aproximou seu carrinho.

Olhou para Lucas.

SALMA — Posso?

Ele apontou para Téria.

A responsável confirmou a liberação da superfície após as verificações imediatas.

Salma empurrou o carrinho.

As rodas avançaram suavemente.

Passaram pelo antigo ponto de encaixe.

Continuaram.

Ela parou.

Virou-se.

Olhou para Lucas.

SALMA — ...Não prendeu.

Lucas abriu um sorriso.

LUCAS — NÃO PRENDEU!

Salma voltou a empurrar.

Fez uma pequena curva.

Depois outra.

Retornou.

Parou diante dele.

Os olhos estavam brilhando.

SALMA — Você não imagina quantas vezes fiquei presa ali.

Lucas observou a mulher.

Seu sorriso tornou-se mais suave.

LUCAS — Imagino que tenham sido muitas.

Salma assentiu.

Depois começou a rir.

Uma risada pequena.

Surpresa.

Como se não conseguisse acreditar que um incômodo tão comum pudesse realmente ter desaparecido.

SALMA — ...Ficou excelente.

Lucas ergueu os braços.

LUCAS — AGORA SIM!

Uma voz surgiu atrás dele.

DÁLIA — E o mercado coberto?

Lucas virou lentamente a cabeça.

Dália estava sorrindo.

Kael cobriu o rosto com uma mão.

KAEL — ...Pronto.

Lucas apontou para a representante.

LUCAS — EU GOSTO DE PESSOAS AMBICIOSAS!

Dália cruzou os braços.

DÁLIA — Você disse que gostava das minhas ideias.

Lucas sorriu.

LUCAS — GOSTO!

DÁLIA — Então quero mostrar uma coisa.

Ela conduziu Lucas até a área onde a maquete projetara a grande cobertura do mercado.

Alguns comerciantes aproximaram-se.

Uma artesã de tecidos apontou para a própria fachada.

Um vendedor de alimentos pediu que a ventilação natural continuasse funcionando.

Outra mulher explicou onde os músicos costumavam tocar durante as feiras.

Um homem perguntou se os carrinhos poderiam continuar atravessando o local.

Lucas ouviu.

Aída examinou as possibilidades de materiais e encaixes.

Téria verificou o espaço público disponível.

Kael acompanhou a circulação.

E a cobertura foi tomando forma no projeto.

Não a primeira versão.

A versão que nascera da conversa.

Quando os responsáveis liberaram a estrutura naquela área, Lucas ergueu a mão outra vez.

GÊNESE.

Desta vez, a luz não percorreu o chão.

Subiu.

Primeiro como linhas douradas.

Depois como arcos.

Colunas de pedra clara surgiram em pontos preparados, com bases independentes das fachadas históricas.

As estruturas se encontraram acima do mercado.

Vigas delicadamente ornamentadas sustentaram uma cobertura translúcida, dividida em painéis que lembravam vitrais.

A luz do sol atravessou as superfícies.

Azul.

Dourado.

Âmbar.

Verde.

Os reflexos espalharam-se sobre bancas, tecidos e paredes.

A cobertura não ocultava as lojas.

Emoldurava-as.

Uma série de pequenas aberturas superiores permitia a circulação de ar.

As bordas protegiam os locais de venda da chuva.

E, no centro, a estrutura se erguia numa grande cúpula cuja geometria lembrava as pétalas de uma flor.

Os moradores ficaram imóveis.

Um menino apontou para cima.

MENINO — MÃE!

A mulher segurou sua mão.

Também estava olhando.

MENINO — Parece um palácio!

A mãe sorriu.

MÃE — Parece.

Lucas observou o resultado.

Depois virou-se para Dália.

LUCAS — E AÍ?!

Ela não respondeu imediatamente.

O olhar percorria os arcos.

Os vitrais.

As entradas preservadas.

As bancas.

Os rostos das pessoas.

Por fim, sorriu.

DÁLIA — ...Agora parece o nosso mercado.

Lucas ficou quieto por um instante.

Então abriu um sorriso enorme.

LUCAS — É PORQUE É!

O primeiro grande aplauso começou numa banca de frutas.

Depois veio outro.

E outro.

Mas o som não durou muito.

Porque os comerciantes precisavam continuar trabalhando.

Um vendedor já estava discutindo onde colocaria uma nova placa.

Uma mulher queria saber se poderia organizar uma exposição de tecidos sob a cúpula.

Dois músicos experimentavam a acústica.

E Salma havia decidido que aquela era uma excelente oportunidade para vender mais pão.

Lucas observou tudo.

Depois começou a rir.

LUCAS — ...Eu amo essa cidade.

NÓX respondeu discretamente:

NÓX — A reciprocidade parece promissora.

VII — Quando a própria cidade começou a florescer

DIA 538 · 16h48 · GRANDE AVENIDA DOS TRÊS HORIZONTES

A notícia se espalhou pelas ruas.

Não por magia capaz de alcançar o pensamento de todos.

Por pessoas.

Comerciantes contaram a outros comerciantes.

Crianças correram para mostrar aos amigos o novo mercado.

Mensageiros da Casa Cívica levaram avisos às áreas em que haveria intervenções.

Os pontos já conectados pela Costura de Dados receberam informações sobre os trechos em obras.

E moradores começaram a se aproximar dos espaços públicos preparados.

Alguns estavam curiosos.

Outros, desconfiados.

Havia quem acreditasse que Lucas construiria uma nova torre gigantesca.

E também quem estivesse interessado apenas em saber se a rua continuaria aberta para as entregas.

Lucas estava diante da Grande Avenida.

Ao lado dele, Kael observava uma das frentes preparadas.

Téria conversava com os profissionais de manutenção.

Aída havia retornado à Forja para buscar um conjunto de desenhos produzidos pelos artesãos.

Brannik permanecia nas proximidades.

O que preocupava profundamente algumas pessoas.

BRANNIK — LUCAS!

LUCAS — FALA!

BRANNIK — EU TENHO UMA IDEIA!

Lucas se virou.

Os olhos brilharam.

LUCAS — EU TAMBÉM!

Kael levantou a mão.

KAEL — Antes que os dois comecem a gritar ao mesmo tempo...

BRANNIK — MAS É UMA IDEIA EXCELENTE!

LUCAS — AS MINHAS TAMBÉM!

KAEL — ...É EXATAMENTE DISSO QUE ESTOU FALANDO!

Brannik mostrou um desenho.

Era um arco de pedra.

Mas possuía pequenos mecanismos de ressonância distribuídos pela estrutura.

BRANNIK — E SE AS FONTES PUDESSEM RESPONDER AOS SONS DA CIDADE?!

Lucas ficou imóvel.

Olhou para o desenho.

Depois para Brannik.

LUCAS — ...Meu amigo.

O anão abriu um sorriso gigantesco.

BRANNIK — SIM?!

LUCAS — Você acabou de propor uma coisa maravilhosamente desnecessária.

Brannik levou a mão ao peito.

BRANNIK — OBRIGADO!

Kael começou a rir.

Lucas levantou um dedo.

LUCAS — MAS!

Brannik congelou.

LUCAS — Vamos pensar num lugar onde isso seja bonito sem acordar todos os moradores durante a madrugada.

O anão ficou pensativo.

Depois assentiu.

BRANNIK — ...Isso é razoável.

Kael permaneceu olhando para ele.

KAEL — Você acabou de concordar com uma restrição?

BRANNIK — NÃO É UMA RESTRIÇÃO! É UM DESAFIO ACÚSTICO!

Lucas caiu na gargalhada.

Os desenhos dos artesãos chegaram pouco depois.

Não havia uma única estética.

Alguns preferiam colunas elaboradas.

Outros, arcos simples.

Havia propostas de mosaicos representando a história dos bairros, pequenas fontes inspiradas em motivos vegetais e bancos trabalhados em pedra e madeira.

Uma escultora sugerira uma galeria onde artistas pudessem produzir obras ao longo dos anos, em vez de receber um conjunto permanente de esculturas prontas.

Lucas gostou tanto que pediu para preservar a ideia.

LUCAS — Deixem espaço para o que ainda não foi criado.

Kael observou-o.

KAEL — Você está ficando cada vez mais perigoso como urbanista.

LUCAS — EU SOU UM PROFISSIONAL COMPLETO!

Então chegou o momento.

Kael afastou-se com Téria e os responsáveis pela frente.

As rotas alternativas estavam livres.

As áreas autorizadas, desocupadas.

Os sistemas que precisariam continuar operando haviam sido identificados.

As fachadas históricas permaneceriam intactas.

A intervenção seria uma ampliação, não a destruição do trabalho anterior.

Lucas caminhou até o centro da faixa pública.

Olhou para o céu.

As nuvens haviam se afastado.

A luz da tarde banhava a cidade com tons dourados.

O Criador respirou fundo.

NÓX percebeu sua concentração.

NÓX — Lucas.

LUCAS — Hum?

NÓX — Vai fazer algo grande.

Ele sorriu.

LUCAS — Vou.

O SISTEMA surgiu discretamente.

SISTEMA — Parâmetros de manifestação disponíveis. Nenhuma redução conhecida das capacidades de GÊNESE.

Lucas ergueu os olhos.

LUCAS — Eu sei, parceiro.

Uma pausa.

LUCAS — E hoje quero fazer algo bonito.

Ergueu a mão.

Não houve cântico.

Nenhum preço oculto.

Nenhuma resistência da realidade.

A autoridade do Criador simplesmente respondeu à sua vontade.

GÊNESE.

O primeiro arco de luz surgiu sobre a avenida.

Era enorme.

Não uma estrutura sólida que bloqueava a rua.

Uma manifestação luminosa que anunciava o início da transformação.

A luz dourada correu pela superfície.

Alcançou as áreas liberadas.

Dividiu-se em centenas de filamentos.

As pedras existentes se ergueram onde o projeto exigia ajustes.

Algumas foram preservadas e recolocadas em mosaicos.

Outras deram lugar a estruturas mais adequadas.

Abaixo da superfície, novos conduítes surgiram nos corredores previstos.

Redes de drenagem.

Galerias técnicas.

Passagens preparadas para receber futuros sistemas de comunicação e mobilidade.

A matéria tomou forma com precisão.

Lucas não precisava inventar uma dificuldade mágica para criar cada peça.

E não precisou transformar uma avenida inteira numa obra tradicional que duraria anos.

O que estava definido ganhou existência.

O que não estava esclarecido permaneceu acessível aos responsáveis para investigação posterior.

Então a beleza começou.

As calçadas se ampliaram nos espaços apropriados.

Árvores surgiram em novos canteiros, com sistemas de irrigação preparados, enquanto as antigas permaneceram onde suas raízes e a circulação permitiam.

Bancos de pedra clara e madeira trabalhada apareceram sob a sombra.

Pequenas fontes tomaram forma em praças previamente escolhidas.

Colunatas elegantes emolduraram alguns corredores comerciais.

As fachadas antigas continuaram visíveis.

Os cruzamentos ganharam travessias mais claras.

Passagens suaves substituíram degraus inadequados em locais já liberados.

E a luz percorreu uma sequência de estruturas ornamentais, transformando trechos da avenida numa composição extraordinária de arcos, jardins e espaços públicos.

Tudo parecia antigo e futurista ao mesmo tempo.

Como se arquitetos de uma cidade renascentista tivessem recebido instrumentos de uma civilização ainda não nascida.

As pessoas ficaram imóveis.

Uma mulher levou a mão à boca.

Um menino começou a pular.

Dois artesãos apontaram imediatamente para uma coluna, discutindo o acabamento.

Brannik estava de joelhos.

Não por reverência.

Havia simplesmente se abaixado para examinar um encaixe.

BRANNIK — ...ISSO É ABSURDO!

Lucas gargalhou.

LUCAS — EU SEI!

O anão levantou a cabeça.

Os olhos brilhavam.

BRANNIK — VOCÊ CONSEGUE FAZER OUTRA?!

Lucas abriu os braços.

LUCAS — POSSO FAZER QUANTAS QUISERMOS!

Brannik soltou um grito de vitória.

Kael começou a rir.

A transformação se estendeu pelas áreas que haviam sido preparadas, sem apagar o trabalho já realizado nos dias anteriores.

A Grande Avenida não foi reconstruída como se seus trechos recuperados jamais tivessem existido.

Eles foram preservados e integrados ao novo conjunto.

Outras frentes receberam estruturas de saneamento, melhorias de circulação e novos equipamentos públicos conforme os projetos aprovados.

Onde os técnicos identificaram incertezas, Lucas criou alternativas que podiam ser verificadas sem comprometer as redes existentes.

A matéria não o limitava.

Mas a cidade continuava sendo habitada.

E essa diferença orientava o desenho.

17h26 · PRAÇA DAS JANELAS ABERTAS

A senhora estava sentada no mesmo banco daquela manhã.

Não ouvira todos os detalhes das obras.

Apenas soubera que a passagem da praça receberia melhorias.

Quando Lucas apareceu, ela ergueu os olhos.

SENHORA — Ah, o corredor.

Lucas abriu um sorriso.

LUCAS — BOM DIA!

Ela olhou para o céu.

SENHORA — Já é quase noite.

Lucas pensou.

LUCAS — ...BOA TARDE!

A mulher começou a rir.

A fonte antiga permanecia exatamente onde sempre estivera.

Os bancos também.

Mas, ao lado da escadaria que levava ao bairro superior, havia uma área pública preparada para uma nova passagem.

Hedra e os responsáveis haviam examinado o percurso.

A solução não exigia destruir a fonte nem as casas vizinhas.

Lucas caminhou até a extremidade da praça.

Olhou para cima.

Depois para a senhora.

LUCAS — Posso mostrar uma coisa?

Ela assentiu.

SENHORA — Mostre.

Lucas ergueu a mão.

GÊNESE.

Uma linha dourada surgiu ao lado dos degraus.

Acompanhou a inclinação da encosta.

E começou a ganhar matéria.

Uma passagem ampla de pedra clara tomou forma, subindo em curvas suaves até o nível superior.

Havia pequenos patamares para descanso.

Corrimãos elegantes.

Jardins nos espaços disponíveis.

Iluminação discreta.

E uma fonte menor, de recirculação própria, que surgia ao lado de um dos patamares.

Tudo integrado à arquitetura da praça.

A escadaria histórica permaneceu.

A nova passagem oferecia outra maneira de alcançar o mesmo destino.

A senhora ficou olhando.

Por muito tempo.

Depois levantou-se.

Aproximou-se da entrada.

Tocou o corrimão.

Olhou para Lucas.

SENHORA — ...Posso subir?

Hedra, que acompanhava a verificação, confirmou que o percurso estava liberado para uso.

Lucas sorriu.

LUCAS — Claro.

A mulher começou a caminhar.

Devagar.

Não porque a passagem exigisse esforço extraordinário.

Mas porque ela desejava experimentar.

Parou no primeiro patamar.

Olhou para trás.

Continuou.

No segundo, soltou uma risada baixa.

E, quando chegou ao nível superior, virou-se para a praça.

Lá embaixo, Lucas levantou os braços.

LUCAS — E AÍ?!

A senhora ficou olhando.

Depois ergueu uma mão.

SENHORA — ...Eu tinha esquecido como era bonito daqui de cima.

Lucas abaixou lentamente os braços.

Seu sorriso permaneceu.

Mas os olhos mudaram.

A mulher observava a cidade.

A luz do fim da tarde atravessava os telhados.

A água da fonte brilhava entre as árvores.

E a praça parecia, de repente, maior.

Não porque tivesse crescido.

Mas porque voltara a pertencer também a alguém que havia perdido o hábito de atravessá-la por aquele caminho.

A menina do desenho apareceu ao lado de Lucas.

Segurava a folha que terminara de colorir.

Olhou para a nova passagem.

Depois para ele.

MENINA — Você fez!

Lucas se abaixou.

LUCAS — Fiz.

Ela mostrou seu desenho novamente.

A ponte elevada continuava ali.

Mas agora havia mais árvores.

E uma fonte azul.

MENINA — Falta minha ponte.

Lucas abriu um sorriso.

LUCAS — Falta.

A menina apontou para o horizonte.

MENINA — Ela precisa ficar de um jeito que a gente veja o sol.

Lucas observou a direção.

Depois o desenho.

LUCAS — Então vamos precisar descobrir o melhor lugar.

Ela assentiu solenemente.

MENINA — E pode ter bancos?

Lucas ficou imóvel.

Depois começou a rir.

LUCAS — MINHA JOVEM, VOCÊ ACABA DE MELHORAR O PROJETO!

A criança abriu um sorriso gigantesco.

As três arcadas de luz

DIA 538 · 18h11 · GRANDE AVENIDA — PRAÇAS CENTRAIS

Ao cair da tarde, a cidade já parecia diferente.

Não em todos os seus edifícios.

Nem em cada rua particular.

Mas nos lugares onde as pessoas haviam trabalhado naquele dia, a mudança era impossível de ignorar.

Uma praça antes pouco utilizada agora possuía passagens amplas e jardins.

O mercado tinha uma cobertura monumental.

Alguns corredores históricos receberam iluminação, drenagem e novos espaços de convivência.

Trechos de vias públicas foram integrados por superfícies acessíveis e estruturas técnicas preparadas para o crescimento futuro.

E a Grande Avenida, que já era uma conquista de Três Arcos, tornara-se ainda mais impressionante.

Lucas caminhou até uma das praças centrais.

Kael e Lysa estavam ali.

A responsável municipal da área acabara de confirmar a liberação de outro trecho.

Vértice permanecia com as equipes de manutenção, coordenando o atendimento às novas estruturas que haviam sido incorporadas aos serviços.

Aída examinava uma galeria.

Brannik discutia com Dorek sobre uma possível instalação de ressonância que ainda não seria construída.

Dália conversava com comerciantes.

E Varo havia chegado depois de terminar suas atividades com a Legião.

O comandante observava a avenida.

Não parecia particularmente impressionado com a escala da magia.

Já vira Lucas fazer coisas extraordinárias.

O que lhe interessava era o movimento das pessoas.

Famílias caminhando.

Crianças descobrindo novas praças.

Trabalhadores examinando os acessos.

Guardas reorganizando percursos.

VARO — Você conseguiu movimentar a cidade inteira.

Lucas sorriu.

LUCAS — Ainda não terminei.

Varo olhou para ele.

VARO — Imaginei.

O comandante apontou discretamente para uma das entradas.

VARO — A Legião precisará conhecer as novas rotas.

Lucas assentiu.

LUCAS — Claro.

VARO — Principalmente as passagens de emergência, os acessos às áreas públicas e os locais onde as pessoas poderão precisar de ajuda.

Lucas sorriu.

LUCAS — Quero que vocês tenham isso.

Varo permaneceu pensativo.

VARO — Vou conversar com os responsáveis pela guarda e com nossas equipes. Não quero que a cidade fique mais difícil de proteger apenas porque ficou mais bonita.

Lucas abriu um sorriso.

LUCAS — E eu não quero que você precise correr vinte quilômetros para chegar a uma praça.

Varo ergueu uma sobrancelha.

VARO — Você pretende construir vinte quilômetros de praça?

Lucas ficou imóvel.

Depois apontou para ele.

LUCAS — NÃO ME DÊ IDEIAS!

Varo começou a rir.

Pouco depois, Lysa aproximou-se.

LYSA — Lucas.

Ele se virou.

LUCAS — Sim?

Ela observou a cidade.

Depois olhou para o amigo.

LYSA — Hoje você conseguiu fazer algo importante.

Lucas sorriu.

LUCAS — Eu sei.

Ela ergueu uma sobrancelha.

LYSA — Não estou falando apenas das construções.

Lucas ficou quieto.

Lysa apontou para o mercado.

LYSA — Os comerciantes estão discutindo como usar os novos espaços. Os artesãos querem apresentar propostas. Os responsáveis urbanos já estão organizando as próximas frentes.

Kael se aproximou.

KAEL — E recebemos manifestações de moradores que desejam participar das decisões dos próximos bairros.

Lucas observou os dois.

Seu sorriso aumentou lentamente.

LUCAS — ...Isso é maravilhoso.

Lysa assentiu.

LYSA — É.

Depois sorriu.

LYSA — Mas amanhã você vai querer construir um distrito inteiro.

Lucas abriu os braços.

LUCAS — EXATAMENTE!

Kael fechou os olhos.

KAEL — Eu sabia que você não tinha esquecido.

Lucas olhou para as praças.

Depois para os amigos.

LUCAS — Antes de encerrarmos o primeiro dia, quero fazer uma coisa.

Lysa estreitou os olhos.

LYSA — Que coisa?

Ele apontou para a avenida.

LUCAS — Uma assinatura.

Kael ergueu uma sobrancelha.

KAEL — Sua?

Lucas abriu um sorriso.

LUCAS — Da cidade.

Ele caminhou até a área central da praça.

Afastou-se das pessoas.

Olhou para os três corredores públicos que se encontravam naquele setor urbano.

E ergueu a mão.

GÊNESE.

Três grandes arcos de luz surgiram sobre a avenida.

Não eram monumentos sólidos.

Eram uma manifestação luminosa temporária, suspensa acima dos corredores.

O primeiro brilhou em dourado.

O segundo, em azul profundo.

O terceiro, numa tonalidade prateada que parecia recolher o último reflexo do sol.

As três estruturas se ergueram lentamente.

Não bloquearam a passagem.

Não ocultaram as estrelas que começavam a aparecer.

Apenas iluminaram a cidade.

Sob elas, as fontes existentes refletiram a luz.

Os vitrais do mercado brilharam.

As árvores projetaram sombras delicadas sobre o pavimento.

E, por alguns instantes, Três Arcos pareceu ter recebido três novas auroras.

As pessoas pararam.

Uma criança aplaudiu.

Depois outra.

Um músico começou a tocar.

Alguém gritou de alegria.

Lucas observou a cidade.

E sorriu.

LUCAS — PRIMEIRO MARCO!

Brannik levantou os braços.

BRANNIK — A CIDADE QUE RENASCE!

Kael começou a rir.

Lysa sorriu.

Varo permaneceu observando os arcos.

Depois assentiu lentamente.

O primeiro dia não havia criado uma população nova.

Não havia terminado os estudos do Horizonte Aberto.

Não havia instalado toda a rede futura de transportes e comunicação.

Mas havia realizado obras monumentais e funcionais, transformado espaços concretos e demonstrado que a visão podia acontecer sem apagar a vida anterior.

A cidade histórica ganhara uma nova camada de beleza e possibilidades.

E os moradores já começavam a decidir o que fariam com ela.

VIII — A mulher que fez o Criador esquecer a própria cidade

DIA 538 · 19h36 · GRANDE AVENIDA — GALERIA DAS FONTES

Lucas estava sentado num banco novo.

Exatamente no banco que ajudara a criar horas antes.

Comia alguma coisa comprada no mercado.

Observava as luzes.

E parecia absolutamente satisfeito com a existência.

O SISTEMA apareceu.

SISTEMA — O usuário apresenta sinais de fadiga física moderada após um dia de atividade prolongada.

Lucas mastigou.

LUCAS — Hum.

SISTEMA — Recomendo descanso.

LUCAS — Estou descansando.

SISTEMA — Você permanece observando possibilidades de construção na avenida.

Lucas olhou para uma fonte.

Depois para uma pequena praça lateral.

Abriu um sorriso.

LUCAS — ...Ali caberia um teatro.

NÓX respondeu:

NÓX — Você acabou de confirmar o diagnóstico.

Lucas gargalhou.

A luz do entardecer havia desaparecido.

As novas luminárias arcanas lançavam reflexos suaves sobre a pedra clara.

Não havia um brilho excessivo.

A cidade conservava sua atmosfera noturna.

Mas as passagens estavam mais agradáveis, as fontes iluminavam as praças e os espaços públicos recebiam moradores curiosos.

Um casal caminhava de mãos dadas.

Três crianças disputavam uma corrida improvisada.

Uma senhora conversava com uma amiga sobre a nova passagem que Lucas ajudara a construir.

Perto do mercado, dois músicos experimentavam os efeitos da cobertura sobre os instrumentos.

E, numa esquina, o mesmo cachorro daquela manhã dormia pacificamente aos pés do legionário.

A luva havia sido recuperada.

A guerra terminara.

Lucas sorriu ao ver o animal.

Então ouviu uma voz atrás dele.

MIREN — ...Você realmente não sabe fazer nada pequeno.

Ele virou imediatamente a cabeça.

Miren estava ali.

Havia retornado de AERÚN pelo Eixo Aurora depois de encerrar suas atividades com Astra, utilizando os meios habituais de deslocamento.

Vestia uma roupa confortável e carregava uma pequena bolsa de pesquisa.

O cabelo estava preso de maneira simples.

E ela sorria.

Lucas se levantou tão depressa que quase deixou cair o que estava comendo.

LUCAS — AMOOOOOR!

Miren abriu os braços.

Ele a abraçou.

Com força.

Depois a beijou.

Não foi um cumprimento rápido.

Ela passou as mãos por seus cabelos e correspondeu ao beijo com uma intensidade que fez Lucas esquecer completamente a fonte atrás dele.

Quando se afastaram, Miren observou seu rosto.

MIREN — Sentiu minha falta?

Lucas levou a mão ao peito.

LUCAS — MINHA SENHORA, EU PASSEI HORAS SEM VOCÊ!

Ela gargalhou.

MIREN — Foi terrível?

LUCAS — UM SOFRIMENTO HISTÓRICO!

MIREN — Imagino.

Ele apontou para a cidade.

LUCAS — MAS EU FIZ ALGUMAS COISAS PARA ME DISTRAIR!

Miren olhou para a avenida.

Depois para as fontes.

Para os jardins.

Para os arcos iluminados.

Seu sorriso diminuiu lentamente.

Não desapareceu.

Apenas mudou.

Tornou-se um sorriso de encantamento.

MIREN — ...Lucas.

Ele a observou.

LUCAS — Gostou?

Miren deu alguns passos.

Tocou uma das colunas.

Examinou os detalhes do material.

Depois observou a rua.

MIREN — É extraordinário.

Lucas abriu um sorriso gigantesco.

LUCAS — EU SABIA!

Ela se virou.

MIREN — Mas quero ver tudo.

Ele abriu os braços.

LUCAS — ENTÃO VENHA, MINHA SENHORA!

Ofereceu o braço.

Miren o aceitou.

E começaram a caminhar.

Lucas mostrou o mercado coberto.

Contou como Dália havia impedido que sua primeira versão escondesse as lojas antigas.

Miren examinou a cobertura.

MIREN — Ela tinha razão.

LUCAS — TINHA!

Ele apontou para os vitrais.

LUCAS — E olha isso!

Miren observou.

A luz das luminárias se refletia nos painéis.

A estrutura parecia um jardim suspenso sobre as bancas.

MIREN — Você conseguiu fazer o mercado parecer uma construção histórica sem apagar o que já estava ali.

Lucas sorriu.

LUCAS — Era a ideia.

Miren ergueu uma sobrancelha.

MIREN — A ideia final.

Ele fechou os olhos.

LUCAS — ...SIM, AMOR.

Ela começou a rir.

Caminharam até a praça onde Salma havia testado o carrinho.

Lucas mostrou a nova passagem.

Miren se abaixou para examinar a transição do pavimento.

Depois ergueu os olhos.

MIREN — Ficou muito melhor.

LUCAS — E o carrinho dela passou sem prender.

A arqueóloga sorriu.

MIREN — Aposto que isso foi mais importante para ela do que todas as colunas.

Lucas ficou pensativo.

Depois assentiu.

LUCAS — Acho que sim.

Continuaram caminhando.

Quando alcançaram uma das fontes novas, Miren parou.

A água escorria por pequenas folhas metálicas, formando um movimento suave sobre um reservatório de pedra.

Ela se inclinou.

Observou o sistema.

Depois olhou para o marido.

MIREN — Você criou um circuito fechado?

Lucas assentiu.

LUCAS — Sim. Captação e reposição controladas. Téria foi bastante enfática sobre isso.

Miren sorriu.

MIREN — Estou começando a gostar muito de Téria.

LUCAS — TODO MUNDO ESTÁ SE UNINDO PARA ME IMPEDIR DE FAZER BESTEIRA!

Ela soltou uma gargalhada.

MIREN — É uma missão nobre.

Lucas apontou para ela.

LUCAS — EU SOU UM HOMEM INCOMPREENDIDO!

Miren segurou a mão dele.

MIREN — É. Muito incompreendido.

Depois o beijou.

Caminharam mais um pouco.

Lucas falou da maquete.

Das sugestões de Aída.

Das críticas de Dorek.

Da preocupação de Hedra.

De Vértice propondo utilizar a própria invenção para ensinar planejamento urbano.

Miren ouviu com interesse.

Em determinado momento, ela começou a rir.

MIREN — Espere.

Lucas virou a cabeça.

LUCAS — O quê?

MIREN — Brannik realmente pediu uma cópia da maquete?

Lucas abriu os braços.

LUCAS — IMEDIATAMENTE!

Ela começou a gargalhar.

MIREN — E você?

LUCAS — Disse que podemos fazer outra.

Miren parou de andar.

Olhou para ele.

MIREN — ...Lucas.

LUCAS — Hum?

MIREN — Você acabou de dar a Brannik a possibilidade de projetar qualquer coisa numa cidade em miniatura.

Lucas pensou.

Longamente.

Depois seus olhos se arregalaram.

LUCAS — ...Puta merda.

Miren começou a rir tanto que precisou se apoiar no braço dele.

MIREN — Agora você entendeu.

Lucas cobriu o rosto.

LUCAS — ELE VAI CONSTRUIR UM CANHÃO DE ENSAIO NO MEIO DA MAQUETE!

NÓX comentou:

NÓX — A possibilidade não é desprezível.

Os dois caíram na gargalhada.

Quando o riso diminuiu, Miren encostou a cabeça no ombro dele.

Continuaram caminhando.

O som da água acompanhava seus passos.

MIREN — Sabe de uma coisa?

LUCAS — O quê, amor?

Ela olhou para a cidade.

MIREN — Pela manhã, quando você começou a falar, tentei imaginar como tudo isso seria.

Lucas sorriu.

MIREN — Mas ver as pessoas caminhando por aqui é diferente.

Ela apontou para um grupo de moradores que conversava sob uma nova galeria.

MIREN — Isso não parece um monumento.

Lucas acompanhou seu olhar.

MIREN — Parece um lugar onde alguém vai viver.

O sorriso dele tornou-se suave.

LUCAS — É exatamente o que eu queria.

Miren apertou sua mão.

Perto de uma das praças, encontraram Kael e Lysa.

Os dois haviam terminado os compromissos mais urgentes.

Conversavam sobre o que ocorrera durante o dia.

Lysa observou o casal.

LYSA — Finalmente encontramos o responsável pelo caos arquitetônico.

Lucas ergueu os braços.

LUCAS — CAOS NÃO! EXCELÊNCIA URBANA!

Kael sorriu.

KAEL — A cidade parece concordar, pelo menos em boa parte.

Miren cumprimentou os dois.

MIREN — Vi algumas das mudanças.

Lysa sorriu.

LYSA — E gostou?

MIREN — Muito.

Kael apontou para Lucas.

KAEL — Infelizmente, ele agora está ainda mais convencido de que suas ideias são excelentes.

Miren inclinou a cabeça.

MIREN — Ele já acordou assim.

Lucas levou a mão ao peito.

LUCAS — MINHA PRÓPRIA ESPOSA?!

Os quatro começaram a rir.

A conversa continuou por algum tempo.

Não foi uma nova reunião.

Não havia necessidade de transformar cada encontro dos amigos numa discussão formal.

Kael contou que moradores de diferentes bairros já haviam começado a apresentar ideias para as próximas intervenções.

Lysa mencionou o interesse de comerciantes em utilizar a maquete para avaliar locais de trabalho.

Miren falou sobre a possibilidade de AERÚN contribuir com exposições e programas de ensino.

Lucas ouviu tudo com entusiasmo.

Mas então perguntou:

LUCAS — E amanhã?

Kael olhou para ele.

KAEL — O Horizonte Aberto.

Lysa assentiu.

LYSA — Amanhã teremos uma decisão importante sobre onde desenvolver o novo distrito e como conectá-lo à cidade.

Lucas sorriu.

LUCAS — Preparados?

Kael olhou para Lysa.

Ela observou o marido de Miren.

Depois soltou um suspiro teatral.

LYSA — Não.

Uma pausa.

Ela sorriu.

LYSA — Mas acho que vamos gostar de descobrir.

Lucas começou a rir.

LUCAS — ESSA É A RESPOSTA PERFEITA!

Kael apontou para a maquete distante, cuja iluminação ainda era visível pelas janelas da Casa Cívica.

KAEL — Amanhã quero envolver mais pessoas nas decisões sobre o distrito. Não apenas aquelas que já trabalham na administração.

Lucas assentiu.

LUCAS — Claro.

LYSA — E vamos preservar as propostas que surgiram hoje, inclusive aquelas que ainda não podem ser executadas.

LUCAS — Combinado.

Miren olhou para ele.

MIREN — Você também vai dormir esta noite, espero.

Lucas ergueu as mãos.

LUCAS — MINHA SENHORA! EU SOU UM HOMEM EQUILIBRADO!

Kael começou a rir imediatamente.

KAEL — Essa foi a mentira mais impressionante do dia.

Lucas apontou para ele.

LUCAS — EU VOU CONSTRUIR UMA ESTÁTUA SUA COM ESSA CARA!

KAEL — Não vai.

LUCAS — UMA ESTÁTUA MUITO BONITA!

LYSA — Ele vai colocar você na entrada do novo distrito.

KAEL — Lysa!

Miren caiu na gargalhada.

A conversa terminou quando a noite já estava completamente estabelecida.

Kael e Lysa seguiram para seus próprios compromissos e descanso.

Lucas permaneceu com Miren.

Os dois caminharam lentamente até a Casa do Jardim Branco.

Não precisaram de uma carruagem.

Não precisaram de uma manifestação extraordinária.

A cidade estava agradável.

E o casal queria caminhar.

IX — Um lugar para voltar

DIA 538 · 21h14 · CASA DO JARDIM BRANCO — VARANDA

A noite estava fresca.

Miren havia trocado de roupa.

Lucas preparara uma bebida quente.

Rumo apareceu por alguns instantes para cumprimentá-los.

Carregava uma pequena peça de madeira.

Lucas observou.

LUCAS — ...O que é isso?

Rumo examinou o objeto.

Era uma estrutura simples, feita com algumas das peças que estivera organizando pela manhã.

Possuía duas pequenas rodas.

Um suporte.

E uma superfície que poderia transportar objetos leves.

RUMO — Ainda não decidi o que será.

Lucas sorriu.

LUCAS — Mas tem rodas.

Rumo assentiu.

RUMO — Gosto da maneira como elas se movimentam.

Miren se aproximou.

Examinou a construção.

MIREN — Foi você quem fez?

RUMO — Sim.

Ela sorriu.

MIREN — Ficou bonita.

O autômato pareceu satisfeito.

Depois olhou para Lucas.

RUMO — Ouvi dizer que você construiu várias coisas hoje.

Lucas abriu os braços.

LUCAS — ALGUMAS!

Miren soltou uma risada.

Rumo observou a pequena peça.

RUMO — Eu construí uma.

Lucas ficou quieto.

Depois se aproximou.

Abaixou-se para examinar o objeto.

LUCAS — E sabe o que é mais importante?

Rumo inclinou a cabeça.

RUMO — O quê?

Lucas sorriu.

LUCAS — Que essa é sua.

Rumo permaneceu observando a peça.

Depois assentiu.

RUMO — Gosto disso.

E se despediu para continuar suas próprias atividades.

Miren observou o autômato partir.

Depois olhou para Lucas.

MIREN — Acho que hoje foi um bom dia para ele também.

Lucas assentiu.

LUCAS — Foi.

Sentaram-se na varanda.

O jardim estava iluminado discretamente.

A água do pequeno lago refletia a lua.

E, ao longe, alguns dos novos arcos e fontes de Três Arcos ainda brilhavam entre os telhados.

Miren apoiou a cabeça no ombro do marido.

MIREN — Três dias, então?

Lucas sorriu.

LUCAS — Três dias.

MIREN — Três marcos.

LUCAS — Três Arcos.

Ela soltou uma risada baixa.

MIREN — Você realmente gostou dessa frase.

Lucas abriu os braços.

LUCAS — É GENIAL!

Miren o beijou.

MIREN — É boa.

Ele arregalou os olhos.

LUCAS — SÓ BOA?!

Ela começou a rir.

MIREN — Excelente.

LUCAS — AGORA SIM!

O silêncio voltou.

Não era um silêncio vazio.

Era confortável.

Lucas observou a cidade.

Pensou no novo distrito.

Nos milhares de pessoas que talvez um dia decidissem viver ali.

Em AERÚN crescendo.

Na Forja inventando máquinas.

Em ARGOS atravessando os céus.

Nas crianças que poderiam brincar sob pontes que ainda não existiam.

Mas não permaneceu preso ao futuro.

Virou-se para a esposa.

Beijou sua testa.

LUCAS — Obrigado por hoje.

Miren ergueu os olhos.

MIREN — Pelo quê?

LUCAS — Por me ajudar a imaginar uma coisa melhor.

Ela sorriu.

MIREN — Você já tinha uma ideia maravilhosa.

Lucas assentiu.

LUCAS — Mas ficou melhor quando conversamos.

Miren passou a mão pelo rosto dele.

MIREN — Então continue conversando comigo.

Lucas sorriu.

LUCAS — Sempre.

Ela se aproximou.

Beijou-o lentamente.

Depois encostou a testa na dele.

MIREN — Amanhã você vai tentar construir uma cidade inteira.

Lucas abriu um sorriso absolutamente descarado.

LUCAS — UM DISTRITO INTEIRO, AMOR. EXISTE UMA DIFERENÇA TÉCNICA IMPORTANTÍSSIMA!

Miren começou a rir.

MIREN — É claro que existe.

LUCAS — E depois de amanhã...

Ela ergueu uma sobrancelha.

MIREN — A cidade que conversa com o futuro.

Lucas assentiu.

LUCAS — Isso.

Miren olhou para as luzes distantes.

Depois para ele.

MIREN — Então tenho uma pergunta.

LUCAS — Qual?

Ela sorriu.

MIREN — Depois desses três dias... você vai descansar?

Lucas ficou imóvel.

Pensou.

Olhou para o teto.

Depois para o jardim.

E finalmente para Miren.

LUCAS — ...Amor.

MIREN — Sim?

LUCAS — Eu prefiro não fazer promessas que não posso cumprir.

Miren caiu na gargalhada.

Lucas a abraçou.

E os dois permaneceram juntos enquanto a noite avançava.

Três Arcos continuou funcionando.

Os comerciantes fecharam suas bancas.

As equipes de manutenção concluíram verificações dos novos equipamentos.

A Malha Aurora permaneceu em seus serviços habituais e nas atribuições adicionais distribuídas pelos responsáveis.

Na Forja, Brannik ainda discutia uma ideia de ressonância que Dorek considerava perigosamente próxima de transformar uma fonte numa máquina musical.

Em AERÚN, os instrumentos continuavam registrando fenômenos que Miren e Astra ainda precisavam compreender.

No Campo Aurora, ARGOS permanecia em terra depois de seu quinto voo.

E, na Casa Cívica, uma maquete gigantesca guardava a representação de uma cidade que começara a se transformar.

A noite não trouxe uma revelação sobre as Nove Coroas.

Nenhum imperador recebeu uma mensagem instantânea.

Nenhuma frota atravessou o oceano por conveniência.

Mas a Cidade Livre havia dado um passo real.

E o mundo, mesmo sem saber disso ainda, começava a ganhar uma possibilidade nova.

X — Muito além das fontes, o ferro também conhecia a dor

DIA 538 · ANOITECER · UMA PASSAGEM NAS TERRAS MONTANHOSAS DISTANTES

A ponte estava cedendo.

Não por idade.

Alguém havia cortado seus apoios.

E, do outro lado da garganta, três figuras armadas impediam a passagem de uma pequena caravana.

Um dos viajantes estava ferido.

Outra pessoa carregava uma criança.

O vento atravessava as rochas com um assobio profundo, levando consigo o cheiro de neve antiga e metal aquecido.

THARVEK — ...FILHOS DE UMA FORJA MAL APAGADA!

O anão que pronunciara a frase era largo de ombros, de corpo compacto e vigoroso, com uma barba castanho-acinzentada dividida em duas tranças presas por peças de metal escurecido.

Uma delas possuía um pequeno sino.

Sua armadura rúnica mostrava marcas de combate e reparos cuidadosos.

Nenhuma peça parecia existir apenas para ornamentá-lo.

Na mão direita carregava um martelo de guerra.

Na esquerda, um escudo marcado por inscrições antigas.

Seus olhos cor de âmbar examinavam a ponte.

Depois os inimigos.

Depois os feridos.

Nessa ordem.

FENNA — Alteza, os apoios não vão resistir!

Tharvek virou a cabeça.

THARVEK — EU ESTOU VENDO!

A mulher anã, ajoelhada junto ao viajante ferido, ergueu os olhos.

FENNA — Então pare de gritar e decida!

Tharvek ficou imóvel.

Depois apontou para ela.

THARVEK — VOCÊ TEM UMA CORAGEM INSUPORTÁVEL!

FENNA — Aprendi com o senhor!

Ele soltou um rosnado.

Mas já estava se movimentando.

Um dos agressores ergueu uma arma semelhante a uma lança curta.

Três ganchos de luz azulada surgiram ao redor da ponta.

Não eram projéteis comuns.

Pareciam fios arcanos preparados para agarrar as traves da ponte e arrancá-las de suas posições.

AGRESSOR — Entreguem o que carregam!

Tharvek não respondeu.

Aproximou-se da primeira sustentação.

Abaixou o martelo.

Tocou o metal antigo.

E fechou os olhos.

As runas de seu escudo começaram a brilhar.

Não criaram uma muralha indestrutível.

A magia percorreu os encaixes preparados pela tradição de sua forja, reforçando as peças capazes de recebê-la.

O anão sentiu a vibração atravessar seu braço.

Reconheceu uma fissura.

Depois outra.

A ponte não estava inteiramente perdida.

Ainda.

THARVEK — FENNA!

FENNA — SIM?!

THARVEK — LEVE OS FERIDOS!

Ela levantou-se.

FENNA — E O SENHOR?!

Tharvek ergueu o martelo.

Abriu um sorriso feroz.

THARVEK — VOU ENSINAR GEOMETRIA A TRÊS IDIOTAS!

O primeiro gancho arcano atingiu a ponte.

Uma viga se retorceu.

Tharvek bateu o martelo contra a estrutura.

As runas responderam.

O impacto percorreu o metal como uma onda de calor vermelho.

A viga resistiu.

O segundo gancho veio em direção ao peito do príncipe.

Ele ergueu o escudo.

O golpe explodiu numa chuva de centelhas azuis.

Sua bota deslizou sobre a pedra.

A força o empurrou alguns passos.

Mas não o derrubou.

O terceiro agressor avançou pela entrada da passagem, tentando alcançar o último dos viajantes.

Tharvek viu.

A expressão mudou.

A fúria permaneceu.

Mas o grito desapareceu.

O príncipe lançou o escudo.

A peça girou no ar, atingiu a arma do agressor e a arrancou de sua mão.

Antes que o homem recuperasse o equilíbrio, Tharvek atravessou a distância.

O martelo encontrou o chão.

Uma linha de runas se abriu sob as botas do inimigo.

A pedra se ergueu numa saliência abrupta.

O homem caiu.

Tharvek encostou o martelo próximo ao seu pescoço.

THARVEK — FIQUE.

O agressor ficou.

Atrás dele, Fenna conduzia os últimos viajantes para fora da ponte.

A criança chorava.

Uma das mulheres carregava um pequeno embrulho apertado contra o peito.

O outro agressor percebeu que perderia a oportunidade de alcançá-los.

Tentou romper o apoio principal.

Tharvek virou a cabeça.

Viu o brilho arcano.

E sorriu.

Não de alegria.

De compreensão.

THARVEK — ...Ah.

Abaixou o martelo.

Apoiou-o sobre a pedra.

E ativou a inscrição central de sua armadura.

O pequeno sino preso à barba produziu uma única nota.

Grave.

Curta.

O brilho percorreu os encaixes que ele havia preparado.

O golpe inimigo atingiu o apoio.

A ponte gemeu.

Mas, em vez de se partir imediatamente, parte da força foi conduzida para os elementos reforçados.

A estrutura permaneceu de pé tempo suficiente para que o último viajante alcançasse a margem segura.

Tharvek não esperou outro ataque.

Avançou.

O martelo descreveu um arco violento.

A arma do agressor se despedaçou contra a rocha.

O homem tentou recuar.

Escorregou.

E perdeu a consciência depois de atingir a própria cabeça no chão.

O terceiro fugiu pela encosta, abandonando os companheiros.

Tharvek observou-o.

Poderia persegui-lo.

Talvez o alcançasse.

Mas a ponte ainda estava ameaçada.

E Fenna precisava de ajuda com os feridos.

O príncipe tomou sua decisão.

Virou as costas para o fugitivo.

E correu para a caravana.

FENNA — Está sangrando!

THARVEK — NÃO É MEU!

Fenna apontou para o braço dele.

Havia um corte longo sob a placa da armadura.

Tharvek olhou.

Depois franziu a testa.

THARVEK — ...Ah.

Ela fechou os olhos.

FENNA — Alteza.

THARVEK — O QUÊ?!

FENNA — Sente-se.

THARVEK — EU SOU UM PRÍNCIPE!

FENNA — E EU SOU A PESSOA QUE VAI IMPEDIR SUA FERIDA DE INFECCIONAR!

Houve silêncio.

Tharvek sentou-se.

De mau humor.

Enquanto Fenna cuidava dele, uma das viajantes se aproximou.

Carregava um embrulho envolto em tecido.

VIAJANTE — Obrigada.

Tharvek ergueu os olhos.

A mulher apontou para a passagem.

VIAJANTE — Eles queriam isto.

O príncipe examinou o embrulho.

Não o tomou imediatamente.

THARVEK — O que é?

A mulher hesitou.

Depois respondeu:

VIAJANTE — Uma peça retirada de uma antiga oficina da passagem. Meu irmão a encontrou entre materiais recuperados. Achamos que fosse apenas metal trabalhado.

Tharvek observou o tecido.

THARVEK — E por que três homens armados tentariam matar vocês por causa disso?

A mulher balançou a cabeça.

VIAJANTE — Não sabemos.

O príncipe permaneceu quieto.

Não atribuiu a perseguição a um império distante.

Não inventou uma certeza sobre a origem da peça.

Tampouco fingiu que um ataque organizado era algo sem importância.

THARVEK — Então precisamos descobrir.

Fenna terminou o curativo.

FENNA — E precisamos levar os feridos para um lugar seguro.

Tharvek assentiu.

Levantou-se.

Observou a ponte danificada.

Depois as montanhas.

O vento atravessou sua barba.

O pequeno sino tocou suavemente.

THARVEK — Primeiro os vivos.

Uma pausa.

Seus olhos endureceram.

THARVEK — Depois as respostas.

Naquela noite, o príncipe guerreiro Tharvek Ormvall ainda não sabia que, muito longe de suas montanhas, um homem vindo de outro mundo havia transformado parte de uma cidade com um gesto.

Lucas, por sua vez, não conhecia o nome de Tharvek.

Nenhum dos dois tinha motivos para imaginar que seus caminhos poderiam um dia se encontrar.

Por enquanto, cada um cuidava das pessoas que estavam ao seu alcance.

E isso bastava para aquela noite.

ENCERRAMENTO DA PARTE II · DIA 538

O PRIMEIRO MARCO FOI ERGUIDO

Três Arcos adormeceu com novas luzes. Em outro lugar, um príncipe guardou uma peça de metal e uma pergunta. O mundo ainda não havia aproximado aquelas histórias.

WORLDROOT · CHECKPOINT NARRATIVO

Continuidade

D538 · 21h14

Capítulo

1 · Parte II de V

Primeiro marco

A cidade que renasce

Próxima data

D539 · M06 · D24

Realizações narradas neste rascunho

A maquete monumental da cidade foi manifestada na Casa Cívica; moradores e especialistas alteraram o projeto. O mercado recebeu uma cobertura nova, a passagem de Salma foi corrigida e intervenções monumentais começaram a renovar áreas públicas verificadas da cidade histórica. As três arcadas luminosas marcaram o primeiro dia.

Três marcos propostos por Lucas

D538 — A cidade que renasce: primeiro marco materializado; melhorias já utilizáveis e expansão das intervenções ainda possível.

D539 — O Horizonte Aberto: futuro distrito com capacidade proposta de 100 mil residentes; terreno e desenho definitivo ainda não estabelecidos.

D540 — A cidade que conversa com o futuro: transporte, comunicações e integração arcanotécnica ainda por construir.

O mundo além de Três Arcos: Tharvek Ormvall defendeu viajantes numa passagem montanhosa, preservou uma peça desconhecida e iniciou uma investigação própria. Lucas ainda não sabe que ele existe.

Persistência: esta Parte II está disponível como rascunho na conversa, mas não foi arquivada nem validada por hash no GitHub; o HEAD consultado continua no último episódio aprovado do Livro V. Nenhuma atualização do Drive foi realizada.

Escolha a continuação

LIVRO VI · CAPÍTULO 1 · PARTE III DE V

O Dia 539 se aproxima, trazendo o segundo marco: O Horizonte Aberto. A iniciativa está escolhida, mas a forma de executá-la e as descobertas que surgirão permanecem abertas.

1 — A primeira pedra do Horizonte Aberto

Lucas reúne Kael, Lysa, especialistas e representantes para conhecer pessoalmente os terrenos candidatos. A maquete evolui, e a primeira grande manifestação do novo distrito poderá começar diante de todos.

[Escolher 1]

2 — Uma cidade para todos os povos

O Horizonte Aberto será desenvolvido ouvindo artesãos, viajantes, famílias, comerciantes e pessoas de diferentes culturas. Lucas poderá criar espaços e instituições surpreendentes, enquanto a própria cidade começa a imaginar como receber o mundo.

[Escolher 2]

3 — AERÚN e o nascimento de uma nova era

Lucas e Miren aprofundam a ligação entre o futuro distrito, as instituições de ensino e as pesquisas de AERÚN. Astra e os especialistas terão suas próprias descobertas e decisões, sem antecipar os segredos dos Arquitetos.

[Escolher 3]

4 — ESPECIAL: O horizonte não tem dono

Lucas leva o segundo marco à escala de sua imaginação: um distrito renascentista de alta fantasia, com parques imensos, fontes, bairros, palácios cívicos, ciência, mercados e espaço para cem mil futuros moradores.

Kael, Lysa, Miren, a Forja e os moradores surpreendem o Criador com suas próprias iniciativas. Enquanto Três Arcos cresce, as histórias distantes de Tharvek, Elyrien e das primeiras ameaças começam a ganhar peso por caminhos causais.

[Escolher especial 4]

5 — AÇÃO LIVRE

Diga exatamente o que Lucas fará na manhã seguinte ou como deseja combinar e alterar as possibilidades.

[Texto de orientação da área de texto: Descreva a ação de Lucas...] (Valor atual indisponível.)

[Confirmar ação livre]

“O primeiro dia mostrou o que um Criador podia construir. O segundo começaria a mostrar o que um mundo inteiro poderia escolher fazer com isso.”


<!-- WORLDROOT LIVRO-VI-C01 PARTE III / LVI-C01-PIII-D539-AUTHOR-SOURCE -->

CRÔNICAS DE UM NOVO MUNDO · WORLDROOT · HISTÓRIA VIVA

A ERA DAS NOVE COROAS

LIVRO VI — AS COROAS PARTIDAS

CAPÍTULO 1 — O CRIADOR E A CIDADE DAS MIL FONTES

PARTE III DE V · ESCOLHA 4 — ESPECIAL

O FUNDADOR, A CASA DOS TRÊS PODERES E O HORIZONTE ABERTO

“Uma coroa pode governar um território. Mas uma cidade verdadeiramente livre precisa aprender a continuar quando seu fundador não estiver na sala.”

CALENDÁRIO DO HORIZONTE

Dia acumulado

539

Calendário

Ano II · Mês 06 · Dia 24

Local inicial

Casa do Jardim Branco

Primeira cena

06h34

Segundo marco dos três dias: O Horizonte Aberto.

Dia 538: melhorias da cidade histórica e maquete monumental. Dia 539: instituições, a Grande Casa dos Três Poderes e a expansão urbana para capacidade futura de 100 mil residentes.

I — O homem que queria construir uma cidade e acordou pensando em uma nação

DIA 539 · 06h34 · CASA DO JARDIM BRANCO — QUARTO

Lucas acordou com uma mão sobre seu peito.

Não era NÓX.

Não era o SISTEMA.

Era Miren.

Ela estava deitada ao seu lado, observando-o com aquele sorriso que geralmente significava uma de duas coisas:

Ou estava apaixonada.

Ou estava prestes a dizer algo profundamente constrangedor.

Às vezes, ambas.

MIREN — Bom dia, fundador.

Lucas abriu um olho.

Depois o outro.

LUCAS — ...Fundador?

MIREN — Sim.

Ele ficou desconfiado.

LUCAS — O que eu fiz?

Miren sorriu.

MIREN — Nada ainda.

Uma pausa.

MIREN — Hoje.

Lucas levou a mão ao peito.

LUCAS — NOSSA! QUE ATAQUE GRATUITO LOGO CEDO!

Ela começou a rir.

Ele a puxou para perto e beijou sua testa.

LUCAS — Bom dia, meu amor.

MIREN — Dormiu bem?

LUCAS — Maravilhosamente.

Miren ergueu uma sobrancelha.

MIREN — Mesmo depois de transformar parte da cidade ontem?

LUCAS — Principalmente por isso.

Ele sorriu.

LUCAS — Sonhei com fontes.

Ela fechou os olhos.

MIREN — Claro que sonhou.

LUCAS — Fontes gigantescas.

MIREN — Naturalmente.

LUCAS — E uma praça tão linda que as pessoas choravam quando olhavam para ela.

Miren abriu os olhos.

MIREN — E tinha alguma coisa útil nessa praça?

Lucas ficou imóvel.

O sorriso desapareceu.

LUCAS — ...Bancos?

Miren explodiu numa gargalhada.

LUCAS — BANCOS SÃO EXTREMAMENTE ÚTEIS!

SISTEMA — Confirmo. A população costuma utilizá-los para sentar.

LUCAS — VOCÊ NÃO AJUDOU!

A luz da manhã atravessava as cortinas.

Do lado de fora, o jardim estava tranquilo.

Uma ave de penas azuladas pousou sobre o parapeito.

Lucas a observou.

Depois olhou para Miren.

LUCAS — Amor.

Ela reconheceu imediatamente a mudança de expressão.

MIREN — Lá vem.

LUCAS — Eu estava pensando.

MIREN — Isso me preocupa mais do que as fontes.

Ele gargalhou.

Mas então se apoiou num cotovelo.

LUCAS — Ontem construímos coisas maravilhosas. Hoje vamos começar o Horizonte Aberto. Mas tem uma coisa que não sai da minha cabeça.

Miren acariciou seu rosto.

MIREN — O quê?

LUCAS — Estamos construindo uma cidade capaz de receber cem mil pessoas num distrito novo.

Ela assentiu.

LUCAS — E, se tudo continuar crescendo, um dia podemos chegar a um milhão de habitantes na região.

Miren ficou pensativa.

Não pareceu assustada com o número.

Pareceu interessada nas consequências.

MIREN — Isso mudaria completamente Três Arcos.

LUCAS — Sim.

Ele olhou para a janela.

LUCAS — E não podemos continuar pensando apenas em ruas, prédios e máquinas.

Miren inclinou a cabeça.

MIREN — Você está pensando nas instituições.

Lucas abriu um sorriso.

LUCAS — Eu casei com a pessoa mais inteligente deste mundo.

MIREN — Isso não respondeu.

LUCAS — RESPONDEU SIM! COM ELOGIOS!

Ela começou a rir.

Lucas se sentou.

A expressão ficou séria.

LUCAS — Na Terra, havia países que organizavam o poder em três grandes partes. Executivo, Legislativo e Judiciário.

Miren ouviu.

LUCAS — Quem administra não deve ser a única pessoa que escreve as regras. E quem escreve as regras não deve ser a única pessoa que decide se alguém as violou.

Ela assentiu lentamente.

MIREN — Para que nenhum deles concentre tudo.

LUCAS — Exatamente.

Ele olhou para ela.

LUCAS — Três Arcos já tem sua Cidade Livre, seu conselho, seus responsáveis, suas instituições. Não vamos fingir que começamos do zero.

MIREN — Mas você quer organizar melhor o que já existe para o tamanho que pretende alcançar.

Lucas abriu um sorriso.

LUCAS — ISSO!

Ele ergueu três dedos.

LUCAS — Três poderes.

Miren olhou para a mão dele.

Depois para seu rosto.

MIREN — ...Três Arcos.

Lucas ficou imóvel.

Os olhos se arregalaram.

Então ele abriu um sorriso tão grande que parecia fisicamente impossível.

LUCAS — AMOOOOOR!

Miren começou a rir.

LUCAS — VOCÊ ENTENDEU ANTES DE EU FAZER A PIADA!

MIREN — Infelizmente, conviver com você está alterando meu senso de humor.

NÓX — Evidência observacional consistente.

LUCAS — NÓX, VOCÊ ESTÁ ESTRAGANDO UM MOMENTO MATRIMONIAL!

Miren se aproximou.

Beijou o marido.

Depois se afastou apenas o suficiente para observá-lo.

MIREN — E quem conduziria essas instituições?

Lucas sorriu.

LUCAS — Tenho algumas pessoas em mente.

Ela ergueu uma sobrancelha.

MIREN — Você conversou com elas?

Lucas parou.

O sorriso diminuiu.

LUCAS — ...Ainda não.

MIREN — Então terá uma manhã interessante.

Ele soltou uma gargalhada.

LUCAS — VOCÊ É TERRÍVEL!

MIREN — Sou uma excelente esposa.

LUCAS — A MELHOR!

Miren apoiou a cabeça no ombro dele.

Por alguns instantes, permaneceram em silêncio.

Então ela perguntou:

MIREN — E você?

Lucas olhou para ela.

LUCAS — Eu?

MIREN — Onde entra o Criador nessa organização?

Ele pensou.

Não precisou pensar muito.

LUCAS — Como fundador.

Miren esperou.

Lucas continuou:

LUCAS — Não quero um trono. Não quero mandar em cada decisão. Não quero que as pessoas precisem da minha aprovação para viver.

Olhou para a janela.

LUCAS — Mas também não quero fingir que sou apenas um visitante. Eu amo essa cidade. Ajudei a fundá-la. Quero continuar construindo o futuro dela.

Miren sorriu.

MIREN — Então seu lugar será especial, mas não acima das leis.

Lucas assentiu.

LUCAS — Isso.

Uma pausa.

Seu sorriso voltou.

LUCAS — E, se algum dia me oferecerem uma coroa...

Miren ergueu uma sobrancelha.

LUCAS — ...vou pedir que transformem o ouro numa fonte pública.

Ela caiu na gargalhada.

II — O segundo dia começou com uma ameaça à tranquilidade administrativa

DIA 539 · 08h17 · CASA CÍVICA — GRANDE SALÃO DA MAQUETE

Kael chegou com uma xícara de bebida quente.

Lysa já estava examinando algumas atualizações da maquete.

Dália conversava com uma representante dos bairros históricos.

A plataforma criada no dia anterior permanecia no centro do salão, com a cidade antiga, suas novas intervenções e a projeção translúcida do Horizonte Aberto.

Kael parou diante da construção.

Observou a avenida em miniatura.

Os novos mercados.

As passagens.

As fontes.

Depois sorriu.

KAEL — Ainda não acredito que temos isso aqui.

Lysa ergueu os olhos.

LYSA — Os artesãos querem utilizá-la para apresentar propostas.

KAEL — Já começaram?

LYSA — Antes do amanhecer.

Kael soltou uma risada.

KAEL — Lucas vai adorar.

Foi nesse instante que a porta se abriu.

LUCAS — BOM DIA, FUTUROS CONSTRUTORES DA MAIOR CIDADE DESTE MUNDO!

Kael fechou os olhos.

KAEL — ...Chegou.

Lysa sorriu.

LYSA — Bom dia, Lucas.

Ele entrou acompanhado de Miren, que havia decidido participar do início da conversa antes de seguir para AERÚN.

Lucas carregava um pequeno caderno.

Não parecia haver perigo imediato.

Até que ele anunciou:

LUCAS — EU TIVE UMA IDEIA INSTITUCIONAL!

Kael parou de beber.

Lysa ergueu lentamente a cabeça.

Dália ficou imóvel.

Miren começou a sorrir.

KAEL — ...Institucional?

LUCAS — SIM!

LYSA — Uma ideia sua sobre organização política?

LUCAS — UMA EXCELENTE IDEIA!

Kael olhou para a xícara.

Depois para Lysa.

KAEL — Eu deveria ter tomado café em casa.

Lucas foi até a maquete.

Ampliou a região central.

A Casa Cívica apareceu.

A construção era importante.

Familiar.

Havia recebido inúmeras decisões e conversas que ajudaram a consolidar a Cidade Livre.

Lucas a observou com carinho.

Então apontou para ela.

LUCAS — Quero transformar isto.

Kael ergueu uma sobrancelha.

KAEL — A Casa Cívica?

LUCAS — Sim.

Lysa inclinou a cabeça.

LYSA — Em quê?

Lucas abriu os braços.

LUCAS — NA GRANDE CASA DOS TRÊS PODERES DE TRÊS ARCOS!

Silêncio.

Dália piscou.

Kael observou Lucas.

Lysa permaneceu quieta.

Então Miren sorriu.

MIREN — Ele ensaiou o nome.

Lucas levou a mão ao peito.

LUCAS — AMOR!

Kael começou a rir.

Lucas fez um gesto.

A representação da Casa Cívica se iluminou.

Ao redor dela, surgiu uma nova projeção.

Não era uma simples ampliação.

Era um projeto monumental.

O edifício histórico permaneceu no centro.

Suas pedras e seus arcos originais continuavam reconhecíveis.

Mas, ao redor dele, três grandes alas começaram a tomar forma.

Fachadas de pedra branca.

Colunas imensas.

Escadarias cerimoniais acompanhadas de acessos amplos e suaves.

Jardins simétricos.

Fontes ornamentais.

Pátios internos.

Galerias abertas.

Cúpulas com vitrais.

Uma grande praça cívica.

E três conjuntos arquitetônicos distintos, ligados pelo corpo central.

O edifício parecia pertencer a uma civilização capaz de reunir a elegância das grandes casas de governo da Terra com a magia, a arte e a história de Três Arcos.

Lucas sorriu.

LUCAS — Na Terra havia um edifício famoso chamado Casa Branca.

Kael olhou para a projeção.

KAEL — Era assim?

LUCAS — Tinha outra organização e outra história. Não quero copiar tudo.

Ele apontou para o projeto.

LUCAS — Quero essa sensação de grandeza. De dignidade. De que as decisões importantes de um povo acontecem num lugar que represente sua história.

Dália observou os jardins.

DÁLIA — É muito bonito.

Lucas ergueu um dedo.

LUCAS — E não será residência de nenhum governante.

Kael sorriu.

LUCAS — Será a casa das instituições.

Lysa aproximou-se.

Examinou as três alas.

LYSA — Explique.

Lucas colocou as mãos nas costas.

Tentou assumir uma postura solenemente acadêmica.

Durou aproximadamente dois segundos.

LUCAS — TRÊS PODERES!

Apontou para a primeira ala.

LUCAS — Executivo.

Para a segunda.

LUCAS — Legislativo.

Para a terceira.

LUCAS — Judiciário.

Kael ficou atento.

Lucas continuou:

LUCAS — Na Terra, muitos governos organizavam as responsabilidades dessa forma para evitar que uma pessoa concentrasse todo o poder.

Lysa cruzou os braços.

LYSA — Quem governa, quem faz as leis e quem julga as disputas.

LUCAS — Exatamente!

Ele apontou para os três edifícios.

LUCAS — Separados. Independentes em suas funções. Capazes de fiscalizar uns aos outros.

Miren acrescentou:

MIREN — Sem que isso impeça a cooperação.

Lucas abriu um sorriso.

LUCAS — PERFEITO!

Kael permaneceu em silêncio.

Depois perguntou:

KAEL — E quem você imagina conduzindo cada um deles?

Lucas olhou para o amigo.

Sorriu.

E respondeu:

LUCAS — Eu tenho uma proposta que vai tornar sua manhã extremamente interessante.

Kael fechou os olhos.

KAEL — ...Claro que tem.

III — Uma cidade sem rei precisa de algo muito mais difícil do que um trono

DIA 539 · 08h49 · CASA CÍVICA — GRANDE SALÃO

Lucas aproximou três pequenas figuras da maquete.

Não eram representações de governantes específicos.

Eram lugares vazios.

Kael percebeu.

KAEL — Por que não colocou ninguém nelas?

Lucas sorriu.

LUCAS — Porque uma instituição não deveria deixar de existir quando alguém sai da sala.

Lysa ergueu os olhos.

Pela primeira vez naquela manhã, não fez nenhuma provocação.

Lucas indicou a primeira ala.

LUCAS — O Executivo será conduzido pelos representantes civis da Cidade Livre. Eles administrarão os serviços, executarão as decisões públicas, cuidarão das relações externas e responderão pela gestão da cidade.

Dália assentiu lentamente.

DÁLIA — Representantes escolhidos pela população?

LUCAS — Essa é a ideia. Com mandato definido, regras públicas e possibilidade real de substituição.

Ele apontou para a segunda ala.

LUCAS — O Legislativo será presidido por Kael.

O estrategista parou de respirar por um instante.

KAEL — ...Por mim?

Lucas abriu um sorriso.

LUCAS — SIM, MEU QUERIDO!

KAEL — Lucas...

LUCAS — Presidente da Câmara Legislativa de Três Arcos!

Kael olhou para Lysa.

Ela estava sorrindo de maneira absolutamente insuportável.

LYSA — Parabéns.

KAEL — Não me dê parabéns. Ele ainda nem explicou como funcionaria.

Lucas ergueu um dedo.

LUCAS — O povo escolhe seus representantes. Eles discutem as leis, aprovam regras, fiscalizam as decisões e podem discordar do Executivo. Você conduz os trabalhos legislativos, mas não vira dono das votações.

Kael ficou pensativo.

KAEL — Isso significa que eu poderia perder uma votação.

Lucas abriu os braços.

LUCAS — CLARO!

KAEL — Mesmo se eu acreditar que estou certo?

LUCAS — PRINCIPALMENTE SE VOCÊ ACREDITAR QUE ESTÁ CERTO!

Kael começou a rir.

Mas havia respeito em seu olhar.

KAEL — ...Gostei.

Lucas apontou para a terceira ala.

A expressão mudou.

Ficou mais séria.

LUCAS — E o Judiciário...

Fez uma pausa.

LUCAS — ...Quero convidar Varo para ajudar a fundar e presidir esse poder.

Kael ergueu a cabeça.

Lysa descruzou os braços.

Miren observou o marido.

Foi Dália quem falou primeiro.

DÁLIA — Varo? O comandante da Legião?

Lucas assentiu.

LUCAS — Ele.

Dália pareceu surpresa.

DÁLIA — Mas não seria estranho o homem que comanda soldados também presidir os julgamentos?

Silêncio.

Lucas olhou para ela.

Depois para a maquete.

A pergunta era boa.

Muito boa.

LUCAS — Seria.

Kael assentiu lentamente.

Lucas continuou:

LUCAS — Se Varo aceitar, terá de separar essas funções. Não quero que alguém comande uma prisão, investigue, acuse e depois decida a sentença sozinho.

Lysa observou-o com interesse.

LYSA — Nem que o Legislativo interfira em um julgamento.

LUCAS — Exatamente.

Miren acrescentou:

MIREN — E nem que você possa encerrar uma disputa apenas porque foi quem fundou a cidade.

Lucas olhou para a esposa.

Abriu um sorriso.

LUCAS — Minha senhora, isso foi cruelmente preciso.

Ela sorriu de volta.

MIREN — Obrigada.

Lucas tocou a terceira ala.

Ela se abriu numa representação de um grande salão.

Não havia tronos.

Havia um espaço para audiências.

Mesas de trabalho.

Galerias destinadas ao público.

Salas de defesa.

Arquivos.

E lugares para magistrados que ainda precisariam ser selecionados e preparados.

LUCAS — Eu confio em Varo. Mas isso não transforma automaticamente meu amigo num especialista em todas as leis.

Kael assentiu.

LUCAS — Quero oferecer a presidência institucional a ele, com juristas, mediadores, pessoas de diferentes povos e regras de independência.

Miren observou a projeção.

MIREN — E direito de defesa.

LUCAS — Sempre.

Dália cruzou os braços.

DÁLIA — Então ninguém será culpado apenas porque alguém importante o acusou?

Lucas virou-se para ela.

Seu sorriso desapareceu por um instante.

LUCAS — Não.

A resposta saiu firme.

LUCAS — Não quero construir uma cidade onde as pessoas precisem conhecer alguém poderoso para serem tratadas com justiça.

O silêncio voltou.

Lucas olhou para os três edifícios.

E acrescentou:

LUCAS — Se um dia eu fizer merda, também quero que exista alguém capaz de olhar para mim e dizer: "Você está errado."

Kael ergueu uma sobrancelha.

KAEL — Você já tem várias pessoas que fazem isso.

Lucas abriu os braços.

LUCAS — EU QUERO INSTITUCIONALIZAR A EXPERIÊNCIA!

A gargalhada foi geral.

Lysa se aproximou da maquete.

LYSA — E como ficam os serviços econômicos?

Lucas virou-se para ela.

Seu sorriso se tornou absolutamente diabólico.

LUCAS — AHÁ!

Ela fechou os olhos.

LYSA — ...Eu sabia.

LUCAS — MINHA QUERIDA LYSA!

LYSA — Não.

LUCAS — FUTURA MINISTRA DA ECONOMIA E DA CASA DA MOEDA DE TRÊS ARCOS!

Kael soltou uma gargalhada tão alta que precisou se apoiar na mesa.

Lysa permaneceu imóvel.

Depois abriu lentamente os olhos.

LYSA — ...Lucas.

LUCAS — SIM?!

LYSA — Você acabou de oferecer a uma pessoa que passa boa parte do dia impedindo suas ideias de arruinarem as contas públicas um cargo no qual ela precisará fazer exatamente isso em escala ainda maior.

Lucas abriu um sorriso glorioso.

LUCAS — POR ISSO VOCÊ É PERFEITA!

Miren começou a rir.

Lysa aproximou-se.

Apontou para a nova estrutura da Casa da Moeda que Lucas desenhara ao lado do conjunto cívico.

LYSA — Quero uma coisa bem estabelecida.

LUCAS — Manda.

LYSA — Não vamos resolver a economia apenas manifestando montanhas de dinheiro.

Lucas assentiu imediatamente.

LUCAS — Concordo.

LYSA — Moeda é confiança. É contabilidade. É comércio. É produção. É a capacidade das pessoas de saberem quanto vale o próprio trabalho e de realizarem trocas sem depender de favores.

Lucas sorriu.

LUCAS — Exatamente por isso quero você.

Ela apontou para o desenho.

LYSA — A Casa da Moeda terá registros públicos, controle de emissão, auditoria independente e proteção contra falsificação. Mas precisamos definir como ela vai se relacionar com as moedas e sistemas econômicos que já utilizamos.

LUCAS — Sim.

LYSA — E não quero assumir esse cargo para descobrir depois que você prometeu ouro gratuito para todas as pessoas que passarem pelo portão.

Lucas levou a mão ao peito.

LUCAS — MINHA SENHORA! EU TENHO RESPONSABILIDADE ECONÔMICA!

Kael soltou uma gargalhada.

KAEL — Você tentou comprar ingredientes suficientes para alimentar um batalhão por causa de uma receita.

LUCAS — ISSO FOI INVESTIMENTO GASTRONÔMICO!

Lysa começou a rir.

Depois ficou séria.

LYSA — Se a função vier com independência técnica, transparência e capacidade de contrariá-lo, aceito ajudar a estabelecer o Ministério da Economia e a Casa da Moeda.

Lucas abriu os braços.

LUCAS — ACEITO TODAS AS CONDIÇÕES!

Lysa ergueu uma sobrancelha.

LYSA — Ainda não ouviu todas.

Lucas ficou imóvel.

LUCAS — ...Puta merda.

A ministra que não aceitaria hospitais vazios

Miren observou as três alas.

Depois virou-se para Lucas.

MIREN — E a saúde?

O sorriso dele mudou.

LUCAS — Maelis.

Kael ergueu os olhos.

KAEL — Você quer convidá-la?

Lucas assentiu.

LUCAS — Quero que ela seja ministra da Saúde.

Miren sorriu.

MIREN — Acho que ela terá muito a dizer.

LUCAS — Eu também.

Não demorou para que Maelis chegasse à Casa Cívica.

Ela havia sido procurada com um convite, não convocada como subordinada.

E veio com a expressão de quem sabia que Lucas era capaz de produzir maravilhas, mas também conhecia o perigo de alguém confundir uma construção imponente com um serviço pronto.

Ao entrar, examinou a maquete.

Depois olhou para Lucas.

MAELIS — Disseram que você está construindo uma cidade.

LUCAS — UM DISTRITO, TECNICAMENTE!

Maelis cruzou os braços.

MAELIS — Isso muda bastante a minha preocupação.

Lucas abriu um sorriso.

LUCAS — Maelis, minha querida...

Ela ergueu um dedo.

MAELIS — Antes de você falar, uma pergunta.

Lucas fechou a boca.

MAELIS — Quantos hospitais?

Ele começou a responder.

Ela ergueu outro dedo.

MAELIS — Quantas pessoas para trabalhar neles?

Lucas parou.

Maelis sorriu.

MAELIS — Agora podemos conversar.

Lucas mostrou o projeto do novo distrito.

Um grande hospital.

Clínicas distribuídas pelos bairros.

Centros de primeiros cuidados.

Rotas de emergência.

Estruturas de apoio.

Maelis examinou tudo.

O rosto se tornou sério.

MAELIS — Posso trabalhar com isso.

Lucas abriu um sorriso.

LUCAS — Sério?

MAELIS — Sim. Mas quero montar uma rede de saúde de verdade.

Ela apontou para a cidade antiga.

MAELIS — Não começaremos esquecendo as pessoas que já vivem aqui.

Lucas assentiu.

MAELIS — Precisamos de atendimento próximo dos bairros, transporte para emergências, profissionais preparados, formação, medicamentos, saneamento e prevenção.

Miren sorriu.

MIREN — AERÚN pode colaborar com pesquisa, ensino e instrumentos. Mas os serviços de saúde precisam de uma organização própria.

Maelis assentiu.

MAELIS — Exatamente.

Depois olhou para Lucas.

MAELIS — Você pode criar um hospital maravilhoso. Eu vou fazer questão de que ele tenha gente capaz de cuidar de quem entrar pela porta.

Lucas ficou quieto.

Então sorriu.

LUCAS — ...Essa é a resposta que eu queria ouvir.

Maelis inclinou a cabeça.

MAELIS — Você está me convidando para assumir o Ministério da Saúde?

Lucas assentiu.

LUCAS — Estou.

Ela observou a cidade em miniatura.

Depois a esposa do Criador.

E finalmente Lucas.

MAELIS — Aceito organizar essa função, com equipes próprias, responsabilidade profissional e liberdade para dizer que uma unidade não pode abrir antes de estar pronta.

Lucas abriu um sorriso.

LUCAS — COMBINADO!

Maelis ergueu uma sobrancelha.

MAELIS — E quero que você compareça às reuniões sobre os equipamentos de emergência.

Lucas levou a mão ao peito.

LUCAS — EU ACABEI DE SER RECRUTADO PELO MEU PRÓPRIO MINISTÉRIO?!

Miren caiu na gargalhada.

O ministro mais barulhento da história

Brannik chegou minutos depois.

Trazia uma peça de metal numa mão.

E um pão na outra.

BRANNIK — ME CHAMARAM?!

Lucas se virou.

Sorriu.

LUCAS — MEU QUERIDO!

Brannik examinou a maquete.

Depois os presentes.

BRANNIK — O QUE EXPLODIU?!

DOREK — Nada.

O anão pareceu desapontado.

BRANNIK — Então por que tanta gente?

Lucas aproximou-se.

Pousou uma mão no ombro dele.

LUCAS — Brannik.

BRANNIK — O QUÊ?!

LUCAS — Você gostaria de assumir o Ministério da Inovação e Tecnologia de Três Arcos?

Silêncio.

O pão caiu.

Brannik ficou imóvel.

Por três segundos inteiros.

Lucas olhou para Dorek.

LUCAS — ...Eu quebrei ele?

Dorek cruzou os braços.

DOREK — Estou apreciando o silêncio.

Então Brannik abriu a boca.

BRANNIK — MINISTÉRIO?!

Lucas arregalou os olhos.

LUCAS — SIM!

BRANNIK — DE INOVAÇÃO?!

LUCAS — SIM!

BRANNIK — E TECNOLOGIA?!

LUCAS — MEU AMIGO, ESTOU COMEÇANDO A ME ARREPENDER DA PARTE ACÚSTICA!

BRANNIK — AAAAAAAAAAH!

O grito ecoou pelo salão.

Kael cobriu o rosto.

Lysa começou a rir.

Miren precisou se apoiar numa cadeira.

Quando recuperou a capacidade de falar sem gritar, Brannik examinou a nova ala projetada para oficinas, laboratórios e centros de invenção.

Mas não se limitou a comemorar.

BRANNIK — A Forja continua sendo a Forja?

Lucas assentiu.

LUCAS — Claro.

BRANNIK — Naira continua mandando nos voos de ARGOS?

LUCAS — Claro.

BRANNIK — Aurel, Alíria, Dorek e os outros continuam podendo me dizer que uma ideia minha é uma porcaria?

Dorek respondeu antes de Lucas:

DOREK — Isso é indispensável.

Lucas soltou uma gargalhada.

LUCAS — ABSOLUTAMENTE!

Brannik ficou pensativo.

Depois olhou para a maquete.

BRANNIK — Então quero um lugar onde as pessoas possam aprender a inventar.

Lucas sorriu.

BRANNIK — Não apenas receber coisas prontas de você. Quero oficinas. Professores. Aprendizes. Testes. Pessoas de diferentes povos discutindo como fazer algo melhor.

Ele ergueu o martelo pequeno que carregava.

BRANNIK — E quero que os erros possam ser estudados sem que todo fracasso seja tratado como vergonha.

Lucas ficou olhando para o amigo.

O sorriso cresceu.

LUCAS — ...Brannik.

O anão ergueu os olhos.

LUCAS — Essa talvez seja a coisa mais bonita que você já disse.

Brannik ficou imóvel.

Depois apontou para Dorek.

BRANNIK — OUVIU?!

DOREK — Ouvi.

BRANNIK — SOU UM HOMEM DE VISÃO!

DOREK — Agora precisamos providenciar um regulamento de segurança.

BRANNIK — ...VOCÊ NÃO CONSEGUE APRECIAR UM MOMENTO?!

Brannik aceitou.

Não para se tornar um administrador distante das próprias máquinas.

Mas para conduzir a criação de uma instituição de inovação com a Forja Aurora, a ciência, os ofícios e o ensino como parceiros.

Lucas deu-lhe um abraço.

O anão retribuiu com tanta força que até NÓX comentou:

NÓX — A manifestação de entusiasmo apresenta intensidade considerável.

LUCAS — EU ESTOU SENDO ESMAGADO PELO MINISTRO!

A resposta de Kael

Quando a agitação diminuiu, Kael permaneceu junto à maquete.

Lucas aproximou-se.

LUCAS — E você?

Kael olhou para a ala legislativa.

Depois para a cidade existente.

KAEL — Você está pedindo uma mudança importante.

Lucas assentiu.

LUCAS — Eu sei.

KAEL — Hoje participo de decisões civis, articulação e administração. Se assumir a presidência do Legislativo, precisaremos separar algumas atribuições.

LUCAS — Concordo.

Kael observou-o.

KAEL — Não quero que você me entregue um cargo como se fosse um presente pessoal.

Lucas sorriu.

LUCAS — Não é.

KAEL — Então quero que os representantes da futura Câmara confirmem a presidência. Podemos estabelecer uma transição e realizar a primeira escolha institucional em sessão pública.

Lucas assentiu.

LUCAS — É exatamente o que eu quero.

Kael respirou fundo.

Depois sorriu.

KAEL — Nesse caso, aceito apresentar minha candidatura e ajudar a construir a Câmara Legislativa.

Lucas abriu os braços.

LUCAS — MEU QUERIDO PRESIDENTE!

Kael começou a rir.

KAEL — Ainda não.

LUCAS — MEU QUERIDO CANDIDATO!

KAEL — Melhor.

Lucas virou-se para a maquete.

Três alas.

Três responsabilidades.

E várias pessoas com capacidade de discordar dele.

Seu sorriso ficou mais tranquilo.

LUCAS — Agora falta Varo.

A expressão de Kael mudou.

KAEL — Essa será uma conversa interessante.

Miren sorriu.

MIREN — Muito.

IV — O comandante que precisou escolher entre a espada e a justiça

DIA 539 · 10h41 · PÁTIO DA LEGÍÃO — TRÊS ARCOS

Varo estava corrigindo a posição de um legionário quando Caedren apareceu.

O comandante ergueu os olhos.

VARO — Alguma coisa?

Caedren respondeu com a tranquilidade de quem trazia uma notícia particularmente desagradável.

CAEDREN — Lucas está vindo.

Varo assentiu.

VARO — Certo.

CAEDREN — Com Kael.

O comandante parou.

VARO — ...Certo.

CAEDREN — E disseram que ele quer falar sobre o governo da cidade.

Varo permaneceu imóvel.

Depois suspirou.

VARO — ...O que ele inventou desta vez?

Lucas apareceu pouco depois.

LUCAS — VAROOOO!

Caedren cruzou os braços.

Varo fechou os olhos.

VARO — Lucas.

LUCAS — MEU AMIGO! MEU IRMÃO! MEU EXCELENTÍSSIMO...

Varo ergueu a mão.

VARO — Pare.

Lucas parou.

VARO — Qual é o problema?

LUCAS — NENHUM!

VARO — Então por que você começou com três elogios?

Caedren soltou uma gargalhada.

Kael cobriu o rosto.

Lucas abriu os braços.

LUCAS — EU NÃO POSSO ELOGIAR MEUS AMIGOS?!

Varo olhou para Kael.

VARO — O que aconteceu?

Kael respirou fundo.

KAEL — Ele está propondo reorganizar as instituições de Três Arcos.

Varo ficou pensativo.

VARO — Certo.

Kael continuou:

KAEL — Executivo, Legislativo e Judiciário.

VARO — Entendi.

Lucas abriu um sorriso.

LUCAS — E EU QUERO VOCÊ PRESIDINDO O JUDICIÁRIO!

Varo permaneceu imóvel.

Caedren abriu a boca.

Fechou.

Depois olhou para Kael.

CAEDREN — ...O quê?

Varo examinou Lucas.

Depois Kael.

Depois novamente Lucas.

VARO — Você quer que eu deixe a Legião para presidir julgamentos?

Lucas percebeu o peso da pergunta.

Não respondeu com uma piada.

LUCAS — Quero oferecer a você a liderança da nova instituição de justiça. Mas não quero que você deixe de ser quem é.

Varo permaneceu quieto.

LUCAS — Você conhece a guerra. Conhece responsabilidade. Conhece o que acontece quando alguém poderoso decide que pode fazer qualquer coisa.

O comandante abaixou lentamente os olhos.

Lucas continuou:

LUCAS — E eu confio na sua capacidade de ouvir uma pessoa antes de decidir o destino dela.

Varo observou o pátio.

Alguns legionários continuavam treinando.

Não estavam prestando atenção à conversa.

Tinham suas próprias tarefas.

O comandante respirou fundo.

VARO — Lucas, eu sei comandar soldados. Sei proteger pessoas. Sei reconhecer quando uma decisão pode custar vidas.

Uma pausa.

VARO — Mas não sou um jurista.

LUCAS — Eu sei.

VARO — E não quero fingir que minha palavra é justiça apenas porque você confia em mim.

Lucas sorriu.

LUCAS — É exatamente por isso que estou te convidando.

Varo ergueu uma sobrancelha.

VARO — Essa frase não faz o menor sentido.

LUCAS — FAZ SIM!

Kael soltou uma risada.

Lucas prosseguiu, mais sério:

LUCAS — Quero alguém que saiba que precisa aprender. Alguém que respeite pessoas capazes de discordar. Você não terá de julgar tudo sozinho. Haverá magistrados, juristas, defensores e regras públicas.

Varo permaneceu pensativo.

VARO — E a Legião?

Caedren ergueu os olhos.

Lucas voltou-se para ele.

Depois para Varo.

LUCAS — A Legião continuará tendo sua própria liderança. Você e os legionários decidirão como organizar a transição. Não quero simplesmente apontar para Caedren e anunciar que ele herdou seu posto.

Caedren assentiu.

CAEDREN — Ainda bem.

Lucas sorriu.

LUCAS — MAS EU ACHO QUE VOCÊ SERIA UM EXCELENTE COMANDANTE!

Caedren ficou imóvel.

CAEDREN — ...Você acabou de fazer exatamente isso.

LUCAS — EU DISSE ACHO!

Varo começou a rir.

O comandante caminhou alguns passos.

Parou diante de uma das bandeiras da Legião.

Observou o tecido.

O lema permanecia o mesmo.

Nenhum fica para trás.

Ele já o conhecia profundamente.

Não precisava redescobri-lo.

Mas, naquele momento, a frase pareceu ganhar outra aplicação.

VARO — Se eu aceitar, haverá uma condição.

Lucas assentiu.

LUCAS — Fala.

VARO — Não vou presidir o Judiciário e continuar comandando operações militares.

Kael assentiu imediatamente.

Varo prosseguiu:

VARO — Podemos estabelecer a transição. Vou ajudar a Legião a escolher sua nova direção operacional, com Caedren e os demais comandantes participando. Mas, quando assumir a presidência judicial, não poderei dar ordens militares.

Lucas sorriu.

LUCAS — Perfeito.

VARO — E quero que a justiça tenha autoridade para investigar até pessoas próximas de você.

Lucas abriu os braços.

LUCAS — INCLUSIVE VOCÊ!

Varo ergueu uma sobrancelha.

VARO — Inclusive eu.

LUCAS — E inclusive eu.

O comandante permaneceu olhando para o amigo.

Depois estendeu a mão.

VARO — Então aceito ajudar a fundar o Judiciário. Aceito presidi-lo quando a instituição for constituída e a transição da Legião estiver concluída.

Lucas apertou sua mão.

Mas não soltou imediatamente.

O sorriso ficou mais suave.

LUCAS — Obrigado, irmão.

Varo assentiu.

VARO — Só não me peça para usar uma peruca ridícula.

Lucas congelou.

Kael olhou para ele.

Caedren também.

Varo estreitou os olhos.

VARO — ...Lucas.

O Criador começou a sorrir.

LUCAS — EU NÃO TINHA PENSADO NISSO!

Varo levou a mão ao rosto.

VARO — ...Pelos deuses.

V — A Casa Branca de Três Arcos

DIA 539 · 12h08 · PRAÇA CÍVICA — CENTRO HISTÓRICO

O sol iluminava a antiga Casa Cívica.

A construção possuía história.

Havia acolhido reuniões importantes.

Decisões difíceis.

Acordos.

Discussões.

Reencontros.

A transformação proposta por Lucas não apagaria aquilo.

A nova Grande Casa dos Três Poderes precisaria nascer da instituição que já existia.

Kael reunira representantes civis para uma sessão pública especial.

Não para aprovar, às pressas, uma constituição completa.

Mas para estabelecer as responsabilidades iniciais da transição e autorizar a renovação do conjunto cívico nos espaços públicos disponíveis.

A proposta de separação dos poderes foi apresentada.

Debatida.

Questionada.

Uma representante perguntou como os futuros magistrados seriam escolhidos.

Outra quis saber como impedir que os responsáveis econômicos favorecessem comerciantes amigos.

Um homem perguntou se os representantes do Executivo poderiam ser substituídos.

Lucas ouviu.

Kael também.

Lysa fez anotações.

Varo explicou que não aceitaria presidir julgamentos sem regras claras de defesa e independência.

Maelis falou sobre a obrigação de garantir acesso a serviços essenciais.

Brannik tentou explicar por que o futuro Ministério da Inovação precisaria de um laboratório de testes separado das áreas residenciais.

A explicação foi interrompida quando ele começou a descrever uma máquina experimental com entusiasmo excessivo.

DOREK — Não vamos construir isso ao lado de uma escola.

BRANNIK — EU NÃO DISSE QUE SERIA AO LADO DE UMA ESCOLA!

DOREK — Você apontou para a escola no mapa.

BRANNIK — PORQUE HAVIA ESPAÇO!

Lucas caiu na gargalhada.

A sessão não transformou todos os cargos em mandatos permanentes por aclamação.

Mas aprovou a abertura formal da transição institucional.

O Executivo continuaria responsável pela administração pública por meio de representantes civis.

A Câmara Legislativa seria organizada com representantes escolhidos conforme regras públicas, tendo Kael como candidato à presidência.

Varo conduziria a estruturação do Judiciário independente, com sua transferência da liderança militar antes da posse judicial.

Lysa, Maelis e Brannik receberam a confiança dos representantes para iniciar seus respectivos ministérios, com responsabilidades definidas e acompanhamento público.

A Casa da Moeda seria constituída como instituição econômica, não como uma máquina de produzir riqueza fictícia.

E Lucas...

Lucas recebeu a palavra.

Ele caminhou até a frente.

Não utilizou a maquete.

Não manifestou luzes.

Não tentou impressionar ninguém com magia.

Apenas observou as pessoas reunidas.

LUCAS — Eu não vou fazer um discurso de três horas.

Kael ergueu uma sobrancelha.

KAEL — Agradecemos.

Lucas apontou para ele.

LUCAS — POR ENQUANTO!

A praça começou a rir.

Lucas esperou o riso diminuir.

Depois continuou:

LUCAS — Eu vim de um mundo que conseguiu construir coisas extraordinárias. Aviões, cidades imensas, sistemas de comunicação, ciência capaz de transformar vidas.

Olhou para os representantes.

LUCAS — Mas esse mundo também cometeu erros gigantescos quando pessoas demais passaram a depender da vontade de poucos.

O silêncio cresceu.

LUCAS — Eu tenho GÊNESE.

Ergueu uma mão.

Uma pequena esfera de luz dourada surgiu sobre seus dedos.

LUCAS — Posso criar edifícios. Posso criar máquinas. Posso transformar uma rua em minutos.

Fechou a mão.

A luz desapareceu.

LUCAS — Mas não quero criar uma cidade onde a justiça dependa de alguém gostar de mim.

Varo permaneceu imóvel.

Lucas olhou para Lysa.

LUCAS — Não quero uma economia que dependa do humor do Criador.

Lysa sorriu.

LUCAS — Nem leis que só funcionem enquanto Kael estiver de bom humor.

Kael soltou uma risada.

KAEL — Então teremos problemas raramente.

Lucas abriu um sorriso.

LUCAS — VOCÊ É INSUPORTÁVEL!

O riso diminuiu.

Lucas voltou a ficar sério.

LUCAS — Eu quero uma cidade que possa crescer. Cem mil novos lugares para viver. Um dia, talvez um milhão de habitantes em Três Arcos e sua região.

Algumas pessoas trocaram olhares.

O número era extraordinário.

Lucas não tentou suavizá-lo.

LUCAS — E, quando isso acontecer, quero que alguém possa entrar nesta Casa e ser ouvido mesmo que não tenha riqueza, título, espada ou meu sobrenome.

Uma pausa.

Ele abriu um sorriso.

LUCAS — Na Terra, muita gente gostava de perguntar quem mandava em tudo.

Ergueu o queixo.

LUCAS — Aqui, eu prefiro uma pergunta melhor.

Olhou para a praça.

LUCAS — Quem é capaz de construir algo que continue funcionando quando o homem mais poderoso do mundo estiver ocupado tomando café com a esposa?

Miren, que acompanhava a sessão, começou a rir.

A praça também.

Lucas apontou para ela.

LUCAS — E EU GARANTO QUE MINHA ESPOSA CONSIDERA O CAFÉ UMA PRIORIDADE NACIONAL!

Miren cobriu o rosto.

MIREN — Lucas!

Quando o riso diminuiu, ele prosseguiu:

LUCAS — Um conquistador precisa que as pessoas se curvem para reconhecer seu poder.

Olhou para as bandeiras da Cidade Livre.

LUCAS — Eu prefiro que levantem a cabeça para enxergar o que podemos construir.

Uma pausa.

LUCAS — Não sou rei.

Outra.

LUCAS — Não sou conquistador.

Seu sorriso tornou-se firme.

LUCAS — Sou o fundador. E, enquanto eu estiver aqui, o futuro vai ter de se acostumar a chegar mais cedo.

O silêncio durou um instante.

Então começaram os aplausos.

Não foram universais.

Algumas pessoas ainda tinham perguntas.

Outras estavam preocupadas com as mudanças.

Mas os representantes haviam ouvido uma proposta que não exigia entregar a cidade a uma única vontade.

E isso importava.

O grande ato de criação

DIA 539 · 13h16 · PRAÇA CÍVICA

Lucas estava diante da Casa Cívica.

Kael e Lysa permaneceram próximos.

Varo observava ao lado dos representantes.

Brannik já se encontrava emocionalmente comprometido com a ideia de uma construção monumental.

Miren permanecia a poucos passos de Lucas.

Ele segurou sua mão.

LUCAS — Pronta?

Ela sorriu.

MIREN — Você perguntou isso como se eu fosse construir.

Lucas abriu um sorriso.

LUCAS — Vai ter muita gente dizendo o que acha depois.

Miren riu.

MIREN — Então sim. Estou pronta.

Lucas ergueu os olhos.

A construção antiga permanecia diante dele.

Seu olhar percorreu os arcos.

As janelas.

As pedras.

Os detalhes que conhecia.

Depois observou os espaços públicos preparados para a ampliação.

As estruturas históricas seriam preservadas.

As novas alas surgiriam sobre áreas liberadas e bases independentes, sem deslocar moradores nem apagar edifícios vizinhos.

A maquete já havia sido ajustada conforme os levantamentos e a sessão pública.

Lucas sorriu.

LUCAS — ...Vamos fazer uma coisa inesquecível.

Ergueu a mão.

GÊNESE.

A luz surgiu primeiro sob a construção antiga.

Não a envolveu para destruí-la.

Desenhou suas fundações preservadas.

Reconheceu o que permaneceria.

E começou a manifestar, ao redor, uma nova arquitetura.

A primeira ala surgiu à esquerda.

Colunas brancas se ergueram como se fossem esculpidas diretamente da luz.

Uma ampla fachada tomou forma.

Janelas altas.

Varandas.

Galerias.

Um grande salão destinado às sessões legislativas.

Acima dele, uma cúpula translúcida recebeu detalhes em ouro pálido e azul profundo.

O segundo conjunto apareceu à direita.

Mais sóbrio.

Com arcadas largas.

Pátios silenciosos.

Salas de audiência.

Bibliotecas jurídicas.

Espaços para defesa e atendimento ao público.

Sua arquitetura transmitia firmeza sem parecer uma fortaleza.

E, ao centro, atrás da construção histórica preservada, ergueu-se a ala executiva.

Magnífica.

Com um grande pórtico de colunas brancas.

Janelas altas e simétricas.

Galerias ornamentadas.

Jardins internos.

Salas de administração.

Espaços de atendimento.

E uma ampla escadaria cerimonial acompanhada de acessos universais integrados à própria arquitetura.

A criação continuou.

Não era apenas um edifício.

Era um conjunto.

Uma grande praça surgiu diante da Casa.

O pavimento ganhou mosaicos inspirados nos símbolos de Três Arcos.

Fontes apareceram em bacias de pedra.

Jardins se organizaram ao longo das galerias.

Árvores lançaram sombra sobre os caminhos.

As novas alas se conectaram à construção antiga por passagens que pareciam ter existido ali desde sempre.

Mas a Casa Cívica original continuou reconhecível.

Suas paredes haviam sido restauradas, não substituídas por uma imitação.

Os arcos históricos permaneciam no coração do conjunto.

A instituição nascera pequena.

A arquitetura preservava essa memória.

As pessoas observavam em silêncio.

Algumas choravam.

Outras apontavam para as novas estruturas.

Uma criança começou a contar as colunas.

Desistiu quando chegou a um número que ainda não dominava.

Brannik estava absolutamente imóvel.

Lucas percebeu.

Sorriu.

LUCAS — ...Brannik?

O anão não respondeu.

LUCAS — Está tudo bem?

Brannik ergueu lentamente a cabeça.

BRANNIK — ...VOCÊ CONSTRUIU UM PALÁCIO PARA A CIDADE.

Lucas sorriu.

LUCAS — Uma casa.

Brannik olhou novamente.

BRANNIK — UMA CASA DESSE TAMANHO?!

Lucas abriu os braços.

LUCAS — UMA CASA PARA UM POVO INTEIRO TER VOZ!

A Grande Casa dos Três Poderes de Três Arcos estava de pé.

Não como uma nova monarquia.

Nem como residência do Criador.

Mas como sede monumental das instituições civis que a Cidade Livre escolhera desenvolver.

Na ala central, o Executivo teria seus espaços.

Na ala legislativa, Kael e os futuros representantes encontrariam uma Câmara preparada para debates públicos.

Na ala judicial, Varo e os profissionais que participassem da instituição teriam condições de organizar uma justiça independente.

Em edifícios anexos, nasceram espaços para os ministérios da Economia, Saúde e Inovação.

A Casa da Moeda ganhou uma sede própria, com instalações de registro, segurança e auditoria, ainda sem declarar uma nova moeda em circulação.

As estruturas físicas existiam.

As equipes, as leis e os procedimentos continuariam sendo desenvolvidos pelas pessoas.

Lucas observou o conjunto.

E sorriu.

LUCAS — ...Caramba.

Miren se aproximou.

MIREN — Gostou?

Ele olhou para ela.

LUCAS — Eu estava preparado para uma coisa bonita.

Voltou a observar o edifício.

LUCAS — Mas ficou maravilhosa.

Kael aproximou-se.

Permaneceu em silêncio durante alguns segundos.

Depois disse:

KAEL — Nunca imaginei que a Casa Cívica pudesse se tornar algo assim.

Lucas sorriu.

LUCAS — E eu nunca imaginei que aquele cachorro fosse roubar uma luva ontem.

Kael virou a cabeça.

KAEL — ...O quê?

Lucas abriu os braços.

LUCAS — O MUNDO É CHEIO DE SURPRESAS!

Miren começou a rir.

Lysa caminhou até a entrada.

Observou o enorme salão de recepção.

As fontes.

As colunas.

Depois voltou para Lucas.

LYSA — É linda.

Ele sorriu.

LUCAS — Obrigado.

Ela ergueu um dedo.

LYSA — Mas quero que algumas salas tenham móveis confortáveis e não apenas cadeiras ornamentais.

Lucas levou as mãos à cabeça.

LUCAS — EU ACABEI DE MANIFESTAR UM PALÁCIO CÍVICO E VOCÊ ESTÁ RECLAMANDO DAS CADEIRAS?!

Lysa abriu um sorriso.

LYSA — Sou ministra da Economia. Preciso começar pelos problemas importantes.

A praça explodiu em gargalhadas.

VI — O segundo horizonte não cabia em nenhum mapa

DIA 539 · 14h37 · EIXO AURORA — SAÍDA DE TRÊS ARCOS

A carruagem seguia pela estrada.

Não era uma comitiva de guerra.

Nem uma viagem diplomática.

Era um grupo de pessoas que desejava examinar o futuro da própria cidade.

Lucas estava junto à janela.

Miren sentava-se ao seu lado.

Kael e Lysa ocupavam os assentos dianteiros.

Dália, Hedra, Téria e alguns especialistas acompanhavam em veículos separados.

Brannik insistira em ir também.

O que fez Dorek decidir acompanhá-lo.

Uma decisão que provavelmente evitou várias discussões posteriores.

A paisagem mudou lentamente.

As construções mais densas de Três Arcos ficaram para trás.

Surgiram áreas de cultivo, pequenas propriedades e terrenos abertos.

Ao longe, o corredor do Eixo Aurora seguia em direção ao Campo onde ARGOS permanecia em inspeção.

AERÚN aparecia numa direção diferente, protegida por seus acessos e por sua própria organização.

Lucas observou a paisagem.

Depois abriu o caderno.

LUCAS — Aqui.

Kael se inclinou.

KAEL — O quê?

LUCAS — Quero que o Horizonte Aberto seja uma extensão natural de Três Arcos. Não uma segunda cidade isolada.

Lysa assentiu.

LYSA — Precisaremos manter ligação com o centro histórico, os mercados, AERÚN e o corredor do Campo Aurora.

Miren apontou para um trecho do mapa.

MIREN — Sem atravessar nossas áreas protegidas.

Lucas sorriu.

LUCAS — Eu lembro, amor.

MIREN — Estou reforçando.

Ele beijou sua mão.

LUCAS — E EU REFORÇO QUE CASEI COM A MELHOR PESQUISADORA DO MUNDO!

Lysa começou a rir.

Kael balançou a cabeça.

A primeira área examinada não serviu.

Havia uma pequena comunidade agrícola utilizando parte das terras.

A ocupação era legítima.

Lucas conversou com os moradores.

Ouviu sobre os canais de irrigação.

Sobre as plantações.

Sobre um antigo pomar que uma família cuidava havia gerações.

O projeto foi deslocado.

Não porque GÊNESE fosse incapaz de construir em outro lugar.

Mas porque Lucas não tinha o menor interesse em transformar uma ambição urbana numa ordem de expulsão.

A segunda área apresentava dificuldades de acesso e interferia num corredor que os responsáveis do Campo Aurora pretendiam preservar.

Foi descartada.

A terceira possibilidade surgiu quando Kael apresentou um conjunto de registros territoriais mais antigos, complementados pelos levantamentos municipais recentes.

Havia uma região de domínio público, extensa, pouco ocupada e conectada por terrenos adicionais também disponíveis ao planejamento urbano.

Não era perfeitamente plana.

Tinha elevações.

Pequenos cursos d'água.

Vegetação.

Algumas formações rochosas.

E uma paisagem extraordinária.

DIA 539 · 15h46 · TERRENOS PÚBLICOS A LESTE DO CORREDOR URBANO

Lucas desceu da carruagem.

O vento atravessava uma área ampla de campos e árvores dispersas.

A paisagem se estendia entre colinas suaves.

Um pequeno rio corria mais adiante.

Ao longe, era possível ver o relevo que marcava a transição para outras regiões.

Kael abriu um mapa.

Lysa aproximou-se.

Téria apontou para as áreas conhecidas.

As equipes compararam os limites administrativos documentados com os levantamentos produzidos em campo.

Lucas criou instrumentos de medição e sondagem capazes de examinar o terreno, sem transformar projeções antigas em dados automaticamente verdadeiros.

A informação recolhida foi incorporada à maquete por uma conexão de registro local.

O desenho do distrito começou a mudar.

O retângulo perfeito do estudo inicial desapareceu.

Surgiu uma forma mais orgânica.

Adaptada ao relevo.

Preservando o curso d'água.

Contornando uma área de vegetação que os responsáveis preferiram manter intacta.

E integrando os corredores públicos já existentes.

O projeto deixou de ser uma figura bonita.

Começou a corresponder ao terreno real que estavam examinando.

TÉRIA — Temos uma região aproveitável considerável.

Lucas assentiu.

LUCAS — E o que ainda precisamos verificar?

Ela indicou dois setores.

TÉRIA — Esses limites foram registrados, mas queremos manter uma faixa de segurança junto ao rio. E esta área possui uma passagem antiga utilizada por algumas caravanas.

Kael observou.

KAEL — Vamos preservá-la e integrá-la.

Lysa apontou para outro trecho.

LYSA — E manter os corredores comerciais independentes das futuras ruas residenciais.

Lucas sorriu.

LUCAS — Perfeito.

Uma pequena construção surgiu na borda da área examinada.

Não era uma residência nova.

Já existia.

Um abrigo utilizado por viajantes que passavam pelo corredor.

Lucas se aproximou.

Uma mulher saiu para recebê-los.

Trazia um cesto de alimentos.

MULHER — Posso ajudá-los?

Kael explicou a visita.

Falou da proposta de expansão.

A mulher ouviu.

Depois olhou para o campo.

MULHER — Estão pensando em construir casas aqui?

Lucas assentiu.

LUCAS — Sim. Muitas.

Ela pareceu surpresa.

MULHER — E a passagem?

Lucas apontou para o caminho antigo.

LUCAS — Queremos mantê-la.

MULHER — Meu pai utiliza essa estrada para levar mercadorias há muitos anos.

Lucas sorriu.

LUCAS — Então vamos fazer questão de que continue existindo.

A mulher observou o grupo.

Depois apontou para a colina.

MULHER — Lá em cima tem uma vista muito bonita.

Lucas ergueu os olhos.

LUCAS — Sério?

MULHER — No fim da tarde.

Ele abriu um sorriso.

LUCAS — ...Podemos ir?

Ela assentiu.

MULHER — Claro.

Subiram a colina.

Quando chegaram ao topo, o vento estava mais forte.

A paisagem se abriu.

O pequeno rio refletia a luz.

As árvores formavam manchas verdes sobre o campo.

E, ao longe, Três Arcos parecia uma joia construída entre caminhos antigos e novos.

Lucas ficou imóvel.

Miren aproximou-se.

Segurou sua mão.

MIREN — ...É lindo.

Ele assentiu.

LUCAS — É.

Brannik chegou atrás deles.

Respirando pesadamente.

BRANNIK — POR QUE TODAS AS BOAS IDEIAS PRECISAM FICAR NO ALTO DE UMA COLINA?!

Lucas soltou uma gargalhada.

LUCAS — PORQUE A VISTA COMPENSA!

O anão olhou.

Ficou quieto.

Depois assentiu.

BRANNIK — ...Está bem. Compensa.

Lucas observou o terreno.

A maquete técnica flutuava diante dos responsáveis como uma projeção temporária.

Os limites aproveitáveis estavam definidos para o projeto autorizado.

As áreas de proteção permaneceriam fora das construções.

O traçado futuro seria adaptado às características reais.

Não era necessário afirmar que cada centímetro de toda a região havia sido conhecido desde o início.

Eles tinham feito o trabalho necessário para decidir onde a primeira grande expansão poderia nascer.

Lucas olhou para Kael.

Depois Lysa.

LUCAS — Então?

Kael respirou fundo.

KAEL — A área que examinamos permite a implantação da primeira fase, preservando os corredores que identificamos e os usos existentes.

Lysa assentiu.

LYSA — Com o traçado ajustado, podemos trabalhar com a capacidade proposta de cem mil residentes futuros.

Miren observou o horizonte.

MIREN — E ainda mantemos boas conexões com AERÚN e o centro histórico, sem atravessar nossas zonas protegidas.

Brannik ergueu os braços.

BRANNIK — ENTÃO VAMOS CONSTRUIR?!

Lucas abriu um sorriso.

LUCAS — ...Vamos.

A expressão mudou.

O entusiasmo permaneceu.

Mas uma concentração profunda tomou conta de seu rosto.

O Criador caminhou até a borda da colina.

Observou o campo.

Depois o céu.

E então se virou para seus companheiros.

LUCAS — Hoje vamos preparar espaço para cem mil pessoas.

Lysa assentiu.

LUCAS — Mas quero deixar uma coisa clara.

Ele apontou para Três Arcos ao longe.

LUCAS — Cem mil não é o fim.

O vento atravessou a colina.

Lucas sorriu.

LUCAS — É o começo.

Kael ergueu os olhos.

Lucas continuou:

LUCAS — Um dia, podemos chegar a um milhão de habitantes.

Brannik abriu a boca.

Dorek também pareceu surpreso.

Lucas abriu os braços.

LUCAS — UM MILHÃO!

Lysa soltou uma risada incrédula.

LYSA — Você está falando de uma região metropolitana inteira.

LUCAS — EXATAMENTE!

Kael começou a sorrir.

Miren observou o marido com carinho.

Lucas apontou para o horizonte.

LUCAS — Mas não vamos construir um milhão de casas vazias hoje.

Ele sorriu.

LUCAS — Hoje nós começamos com cem mil lugares para pessoas que ainda nem conhecemos.

Uma pausa.

LUCAS — E vamos construir algo tão extraordinário que, quando conhecerem, talvez queiram vir.

VII — O Horizonte Aberto

DIA 539 · 16h28 · LOCAL DO NOVO DISTRITO

Lucas ergueu as duas mãos.

A luz dourada apareceu.

Mas não imediatamente sobre todo o terreno.

Primeiro se espalhou pelos limites definidos na maquete.

As zonas de preservação permaneceram intocadas.

Os cursos d'água foram mantidos.

As passagens antigas continuaram reconhecíveis.

O desenho escolhido pelas pessoas presentes se tornou uma estrutura tridimensional de luz sobre a paisagem.

Era tão imenso que parecia um segundo horizonte.

LUCAS — GÊNESE.

O campo respondeu.

Não com destruição.

Com criação.

Milhares de linhas douradas se espalharam pela terra.

A primeira grande avenida surgiu numa faixa preparada.

Pedra clara.

Mosaicos.

Canteiros.

Árvores.

Pistas reservadas para os futuros sistemas coletivos.

Passagens acessíveis.

Galerias técnicas subterrâneas.

A via se estendeu pela paisagem, acompanhando o relevo.

Não era uma estrada improvisada.

Era uma avenida monumental, capaz de servir a uma cidade que ainda estava por nascer.

Depois surgiram as pontes.

Uma atravessou o rio com arcos de pedra branca.

Outra conectou duas elevações.

Uma terceira recebeu passagens para pedestres e um jardim superior.

Lucas sorriu ao observar aquela última.

Pensou na menina que queria uma ponte para ver o pôr do sol.

A estrutura não era exatamente o desenho dela.

Mas a lembrança estava ali.

Então vieram os bairros.

Não todos iguais.

Alguns possuíam edifícios de quatro pavimentos, com jardins internos e pequenos pátios.

Outros tinham construções maiores, de oito ou dez pavimentos, organizadas ao redor de praças.

Algumas residências foram projetadas para famílias grandes.

Outras, para pessoas que desejassem viver sozinhas.

Havia espaços adaptáveis a diferentes necessidades físicas e culturais.

As fachadas variavam.

Pedra clara.

Madeira trabalhada.

Vitrais.

Varandas.

Arcadas.

Telhados inclinados.

Cúpulas.

Jardins suspensos.

O conjunto não parecia uma cidade produzida por uma única oficina.

Parecia uma cidade destinada a receber povos diferentes.

Miren permanecia imóvel.

Uma das mãos cobria parcialmente sua boca.

MIREN — ...Lucas.

Ele sorriu.

LUCAS — Gostou?

Ela não respondeu de imediato.

A paisagem diante deles continuava mudando.

Novas ruas surgiam.

Pequenas praças.

Lagos.

Pontes.

Uma sequência de jardins se estendeu entre os bairros.

Miren olhou para o marido.

Os olhos brilhavam.

MIREN — É magnífico.

Lucas sorriu.

Mas ela acrescentou:

MIREN — E quero ver os espaços de estudo.

Ele abriu os braços.

LUCAS — COM MUITO PRAZER!

Uma nova área começou a surgir.

A Alameda do Saber.

Edifícios de pesquisa e ensino tomaram forma ao longo de um corredor arborizado.

Bibliotecas.

Pavilhões de exposições.

Salas destinadas a oficinas.

Anfiteatros.

Jardins botânicos.

Um grande edifício recebeu uma fachada ornamentada por formas que lembravam livros abertos, folhas e constelações.

Miren acompanhou cada detalhe.

Astra não estava fisicamente na colina, mas receberia os registros e poderia participar da organização científica quando o distrito começasse a abrir seus equipamentos.

AERÚN continuaria independente, com suas áreas protegidas.

A Alameda do Saber seria uma ligação pública com o conhecimento, não uma entrada irrestrita para laboratórios.

Brannik começou a rir.

Primeiro baixo.

Depois mais alto.

BRANNIK — HAHAHAHAHA!

Lucas virou a cabeça.

LUCAS — O QUÊ?!

O anão apontava para uma sequência de edifícios próximos à área destinada aos ofícios.

BRANNIK — VOCÊ CRIOU AS OFICINAS!

Lucas sorriu.

LUCAS — CRIEI!

BRANNIK — E AQUELE É O CENTRO DE INVENÇÕES?!

LUCAS — É!

Brannik ergueu os braços.

BRANNIK — EU VOU PRECISAR DE MAIS APRENDIZES!

Dorek observou as estruturas.

DOREK — E de mais instrumentos de medição.

Brannik virou-se.

BRANNIK — VOCÊ CONSEGUE DESTRUIR QUALQUER MOMENTO DE ALEGRIA!

DOREK — Não destruí. Ampliei o projeto.

Lucas começou a gargalhar.

LUCAS — ELE ESTÁ APRENDENDO COM VOCÊ!

O parque que fez Lysa esquecer as contas por um instante

DIA 539 · 17h11 · PARQUE CENTRAL DO HORIZONTE ABERTO

O grande parque começou a tomar forma diante deles.

Não era um jardim ornamental isolado.

Era uma paisagem inteira.

Colinas suaves.

Lagos de retenção integrados aos jardins.

Canais de água limpa.

Árvores.

Pradarias.

Pontes.

Pequenos pavilhões.

Áreas para apresentações.

Caminhos entre bosques.

Espaços abertos para crianças.

Praças de descanso.

A vegetação original preservada fazia parte do desenho.

As novas árvores se integravam à paisagem sem substituir indiscriminadamente os ecossistemas existentes.

A água seguia circuitos preparados para tratamento e manutenção, sem transformar fontes ornamentais em consumo irresponsável.

Lysa observou o parque.

Sua expressão mudou.

Por alguns instantes, esqueceu os números.

Os custos.

As projeções.

As regras de comércio.

E simplesmente olhou.

LYSA — ...Pelos deuses.

Lucas sorriu.

LUCAS — Bonito, não é?

Ela assentiu lentamente.

LYSA — Muito.

Uma pequena ponte apareceu sobre um dos canais.

Tinha arcos delicados.

Bancos.

E uma vista aberta para o horizonte.

Lysa observou.

Depois olhou para Lucas.

LYSA — Você realmente fez isso.

Ele abriu um sorriso.

LUCAS — Fizemos.

Kael se aproximou.

O estrategista observava o parque como alguém que tentava memorizar cada detalhe.

KAEL — Imagine quando as famílias começarem a viver aqui.

Lucas sorriu.

LUCAS — É nisso que estou pensando.

Mas a criação continuou.

Surgiram centros de saúde.

Escolas.

Bibliotecas.

Mercados.

Espaços culturais.

Áreas comerciais.

Galpões de produção limpa.

Centros de manutenção.

Estruturas de proteção civil.

E um grande hospital equipado com instalações físicas destinadas a receber profissionais e pacientes no futuro.

Maelis já havia deixado claro que o edifício, por si só, não constituía atendimento médico.

Lucas respeitou isso.

Os espaços estavam prontos.

Mas as equipes reais ainda precisariam ser organizadas.

As galerias subterrâneas foram manifestadas com redes de água, drenagem e saneamento.

Reservatórios.

Unidades de tratamento.

Setores energéticos.

Estruturas redundantes.

A infraestrutura física surgiu inteira nas áreas definidas.

Lucas poderia criar mais se fosse necessário.

Não havia uma limitação artificial de GÊNESE.

O que ainda precisava acontecer era a operação segura.

A verificação das redes.

A organização das pessoas responsáveis.

A integração com a cidade antiga.

A abertura dos serviços.

Essas coisas não eram matéria.

E, por isso, continuavam pertencendo às pessoas.

DIA 539 · 18h02 · MIRANTE DO HORIZONTE ABERTO

O sol começava a descer.

Lucas permaneceu de pé sobre a colina.

A paisagem diante dele já não era um campo vazio.

Era uma cidade inteira.

Uma cidade renascentista de alta fantasia.

Com avenidas monumentais.

Pontes.

Fontes.

Jardins.

Mercados.

Bairros.

Escolas.

Bibliotecas.

Hospital.

Pavilhões de ciência.

Grandes parques.

E dezenas de milhares de moradias, organizadas para uma capacidade projetada de cem mil futuros residentes.

Não havia cem mil pessoas ali.

Ainda.

Mas havia espaço para recebê-las.

Uma brisa atravessou a colina.

Miren aproximou-se.

Segurou a mão de Lucas.

Kael e Lysa permaneceram alguns passos atrás.

Brannik estava sentado numa pedra.

Completamente exausto de gritar.

Dorek parecia satisfeito com o silêncio.

Lucas observou o horizonte.

Depois sorriu.

LUCAS — ...Caramba.

Miren encostou a cabeça em seu ombro.

MIREN — Sim.

Ele permaneceu quieto.

A luz dourada da tarde iluminava os telhados.

As novas avenidas pareciam rios de pedra clara.

O parque central brilhava entre jardins e lagos.

E, ao longe, Três Arcos histórica permanecia visível, ligada ao novo distrito por caminhos que logo receberiam sistemas de transporte e comunicação mais avançados.

Lucas apertou a mão da esposa.

LUCAS — Um dia vai ter gente demais para contar caminhando nessas ruas.

Miren sorriu.

MIREN — Talvez.

Ele olhou para ela.

LUCAS — Talvez?

MIREN — Precisamos fazer com que desejem ficar.

Lucas sorriu.

LUCAS — Então vamos dar bons motivos.

Kael se aproximou.

KAEL — Os acessos principais estão preparados. As equipes começarão a verificar os setores liberados e organizar a manutenção.

Lucas assentiu.

Lysa acrescentou:

LYSA — E amanhã teremos muito trabalho com transporte, comunicações, economia e serviços.

Lucas abriu um sorriso gigantesco.

LUCAS — TERCEIRO MARCO!

Kael começou a rir.

KAEL — A cidade que conversa com o futuro.

LUCAS — EXATAMENTE!

Brannik ergueu a cabeça.

BRANNIK — E AS MÁQUINAS?!

Lucas abriu os braços.

LUCAS — AMANHÃ, MEU AMIGO!

O anão ficou imóvel.

Depois sorriu.

BRANNIK — ...Eu não vou conseguir dormir.

Dorek respondeu imediatamente:

DOREK — Isso não é novidade.

Lucas olhou novamente para o distrito.

Depois para Três Arcos histórica.

Duas paisagens.

Um único futuro.

A Cidade Livre possuía uma nova Casa dos Três Poderes.

Novas instituições começavam a assumir forma.

Um distrito inteiro havia nascido.

E a ambição de um milhão de habitantes deixara de parecer apenas uma frase absurda.

Ainda estava muito distante.

Mas agora existia um primeiro passo material.

Lucas abriu um sorriso.

LUCAS — ...Eu tenho uma frase.

Kael fechou os olhos.

Lysa suspirou.

Miren começou a rir.

MIREN — Claro que tem.

Lucas apontou para o horizonte.

LUCAS — Um rei olha para o mapa e pergunta quanto pode conquistar.

Uma pausa.

LUCAS — Eu olho para o mapa e pergunto quanto espaço ainda podemos abrir para os outros.

O silêncio durou alguns segundos.

Kael sorriu.

Lysa também.

Miren apertou sua mão.

Então Lucas acrescentou:

LUCAS — ...E, de preferência, com fontes bonitas pra caralho.

Brannik explodiu numa gargalhada.

VIII — A cidade construída, a cidade que ainda precisava viver

DIA 539 · 19h07 · HORIZONTE ABERTO — PRAÇA DA CONVERGÊNCIA

A primeira visita ao distrito não foi feita por uma multidão.

Foi feita por um pequeno grupo de pessoas que já trabalhava para Três Arcos.

Lysa examinava as projeções de capacidade.

Téria acompanhava a equipe de verificação das redes.

Vértice coordenava a distribuição das unidades da Malha Aurora que haviam sido liberadas para participar das novas atividades de manutenção.

Ninguém retirara indiscriminadamente os 3.600 autômatos de seus serviços anteriores.

As novas estruturas precisariam ser conservadas.

Mas a cidade antiga não deixaria de funcionar para isso.

A praça central parecia extraordinária.

Grandes arcos de pedra clara cercavam um espaço amplo.

Fontes lançavam filetes de água sobre bacias esculpidas.

A iluminação suave começava a despertar.

Ao redor, edifícios cívicos e comerciais formavam um conjunto elegante.

Não havia estátuas obrigatórias do Criador.

Nos espaços reservados a esculturas, alguns pedestais permaneciam vazios.

A arte ainda seria feita por artistas.

A história ainda seria escrita por moradores.

Lysa aproximou-se de Lucas.

LYSA — Temos uma primeira verificação da implantação.

Ele virou a cabeça.

LUCAS — E aí?

Ela sorriu.

LYSA — O conjunto habitacional corresponde à proposta física de quarenta mil moradias, com diferentes tamanhos e configurações.

Lucas abriu um sorriso.

LUCAS — MARAVILHOSO!

Lysa ergueu um dedo.

LYSA — Capacidade de projeto para cem mil residentes. Não população residente.

LUCAS — EU SEI!

LYSA — Algumas estruturas de serviço já podem entrar em verificação operacional. Outras terão de aguardar equipes e os sistemas de mobilidade que trabalharemos amanhã.

Lucas assentiu.

LUCAS — Perfeito.

Ela observou o distrito.

LYSA — Nunca pensei que diria isso sobre uma cidade inteira que surgiu hoje.

Lucas cruzou os braços.

LUCAS — A GÊNESE É UM EXCELENTE MÉTODO DE CONSTRUÇÃO CIVIL!

LYSA — É.

Ela sorriu.

LYSA — Mas a economia daqui será construída por gente.

Lucas olhou para ela.

LUCAS — É o que eu quero.

Uma pequena equipe começou a caminhar pelos edifícios próximos.

Não eram novos moradores.

Eram profissionais que estavam conhecendo as estruturas para organizar serviços futuros.

Vértice aproximou-se.

VÉRTICE — Lucas.

LUCAS — Meu querido coordenador!

VÉRTICE — As edificações e redes dos setores examinados correspondem às configurações manifestadas. Os testes de funcionamento estão sendo organizados pelos responsáveis técnicos.

Lucas assentiu.

LUCAS — E a cidade histórica?

VÉRTICE — Os serviços permanecem em operação. A manutenção das novas estruturas está sendo distribuída conforme disponibilidade e qualificação das unidades.

Lucas sorriu.

LUCAS — Excelente.

Vértice examinou as fontes.

Depois os jardins.

VÉRTICE — Há uma quantidade considerável de novos elementos a conservar.

Lucas abriu os braços.

LUCAS — VOCÊ ESTÁ FELIZ?!

O autômato permaneceu quieto.

Depois respondeu:

VÉRTICE — Considero o desafio interessante.

Lucas soltou uma gargalhada.

LUCAS — ISSO É O MÁXIMO DE ENTUSIASMO QUE EU PODERIA PEDIR!

Miren permaneceu junto a uma das fontes.

Observava as pessoas caminhando.

O distrito parecia pronto para uma vida que ainda não havia chegado.

Havia luz.

Água.

Árvores.

Bancos.

Edifícios.

Mas quase não havia vozes.

Ela se virou quando Lucas se aproximou.

MIREN — É uma sensação curiosa.

LUCAS — O quê?

Ela olhou ao redor.

MIREN — Estamos numa cidade enorme, mas ainda ouvimos os nossos próprios passos.

Lucas acompanhou seu olhar.

Sorriu lentamente.

LUCAS — É verdade.

Miren segurou sua mão.

MIREN — Um dia isso vai mudar.

Lucas assentiu.

LUCAS — Vai.

Uma pausa.

Ela acrescentou:

MIREN — E então você provavelmente vai reclamar que há gente demais fazendo barulho.

Lucas ficou indignado.

LUCAS — EU?!

Miren começou a rir.

LUCAS — MINHA SENHORA, EU SOU UM HOMEM EXTREMAMENTE SOCIÁVEL!

MIREN — Você discutiu com uma folha ontem.

Lucas levou a mão ao peito.

LUCAS — AQUELA FOLHA TINHA INTENÇÕES HOSTIS!

Miren caiu na gargalhada.

Quando o riso diminuiu, Lucas observou a grande praça.

Depois olhou para as mãos.

GÊNESE permanecia plena.

Nenhuma das criações daquela tarde havia exigido que ele descobrisse um poder novo ou pagasse um preço inesperado.

O extraordinário estava em outra coisa.

Ele havia construído quarenta mil moradias.

Mas não conhecia quem dormiria nelas.

Manifestara pavilhões de ensino.

Mas não sabia quais crianças fariam perguntas aos professores.

Criara uma praça monumental.

Mas não poderia prever quem daria seu primeiro beijo sob uma das fontes.

Sorriu.

E percebeu que gostava disso.

Não precisava escolher a vida das pessoas.

Só precisava ajudá-las a ter mais lugares onde vivê-la.

IX — A guardiã que escutava o vento errado

DIA 539 · FIM DA TARDE · FLORESTA DISTANTE, ALÉM DAS ROTAS CONHECIDAS DE TRÊS ARCOS

Elyrien Vaelthara perdera sua xícara.

Mais uma vez.

O problema era particularmente irritante porque havia preparado um chá excelente.

E agora não conseguia lembrar onde o colocara.

A elfa permaneceu imóvel diante de uma mesa coberta de folhas, desenhos e pequenos instrumentos de pesquisa.

Seus longos cabelos prateados estavam parcialmente presos por laços delicados.

Os olhos verde-azulados examinavam a sala.

Sua beleza era extraordinária.

Não apenas pela harmonia do rosto ou pela elegância natural.

Havia nela uma presença magnética, como se a própria luz da floresta encontrasse maneiras diferentes de repousar sobre sua pele.

Mas, naquele momento, a guardiã parecia completamente derrotada por um utensílio doméstico.

ELYRIEN — ...Isso está ficando ofensivo.

Uma jovem pesquisadora, chamada Neris, ergueu a cabeça.

NERIS — O quê?

Elyrien suspirou.

ELYRIEN — Meu chá.

Neris olhou para a mesa.

Depois para uma pequena prateleira.

Depois para a janela.

NERIS — A senhora deixou a xícara no jardim.

Elyrien ficou imóvel.

ELYRIEN — ...Novamente?

Neris assentiu.

A guardiã fechou os olhos.

ELYRIEN — Extraordinário.

Foi então que o vento mudou.

Não muito.

Apenas o suficiente.

Uma das folhas próximas à janela começou a vibrar.

Depois outra.

E outra.

Elyrien abriu os olhos.

Toda a distração desapareceu.

A expressão tornou-se absolutamente concentrada.

ELYRIEN — Neris.

A jovem ergueu a cabeça.

NERIS — Sim?

ELYRIEN — Afaste-se da janela.

O tom foi tão diferente que Neris obedeceu sem perguntar.

Um instante depois, uma flecha atravessou a abertura.

Não atingiu ninguém.

Elyrien já havia erguido a mão.

Uma linha de luz verde percorreu os galhos da árvore mais próxima.

A madeira respondeu.

Um ramo se curvou.

Interceptou o projétil.

E o prendeu antes que alcançasse os registros sobre a mesa.

Neris recuou.

NERIS — Um ataque?!

Elyrien examinou a flecha.

Não parecia pertencer a uma patrulha local.

O metal da ponta possuía um acabamento estranho.

Mas isso não bastava para identificar quem a disparara.

ELYRIEN — Fique atrás de mim.

Sua voz era baixa.

Calma.

Mortalmente séria.

Duas figuras surgiram entre as árvores.

Uma portava um arco.

A outra carregava uma lâmina curva.

Nenhuma anunciou uma bandeira.

Nenhuma apresentou mandato.

O arqueiro preparou outro disparo.

Elyrien ergueu os olhos.

ELYRIEN — Vocês estão atacando uma casa de pesquisa.

O homem não respondeu.

A lâmina curva brilhou.

A segunda figura avançou.

Elyrien moveu a mão.

O Cântico das Estações começou como um som quase inaudível.

As folhas do jardim se ergueram.

Não todas as árvores da floresta.

Não uma tempestade onipotente.

Apenas a vegetação próxima, cujos padrões ela conhecia e conseguia conduzir naquele terreno.

Os galhos se dobraram para proteger as janelas.

O chão coberto de raízes respondeu ao ritmo do canto.

O agressor avançou.

Sua lâmina cortou uma das formações vegetais.

Conseguiu abrir passagem.

Era competente.

Mas a guardiã também.

Elyrien já havia se deslocado.

Apareceu ao lado dele, com uma lâmina curta na mão.

O homem tentou girar.

Ela atingiu sua arma.

Desviou o golpe.

E o derrubou contra o chão com uma sequência de movimentos tão rápidos que Neris mal conseguiu acompanhá-los.

O arqueiro disparou.

Elyrien ergueu o braço.

A flecha encontrou uma barreira de folhas endurecidas pela ressonância.

Fragmentou-se.

O atacante tentou recuar.

A guardiã não o perseguiu para dentro da floresta.

Sua prioridade era proteger a pesquisadora e os registros.

ELYRIEN — Neris! Para a galeria interna!

A jovem correu.

O agressor caído tentou se levantar.

Elyrien apontou a lâmina para ele.

ELYRIEN — Não.

O homem parou.

A guardiã observou o rosto dele.

Depois a arma.

ELYRIEN — Quem enviou vocês?

O agressor permaneceu em silêncio.

Elyrien não inventou uma resposta.

Não declarou conhecer um inimigo que ainda não havia identificado.

Apenas fez a pergunta novamente.

Mais baixa.

ELYRIEN — Quem?

O homem tentou alcançar uma pequena peça presa ao cinto.

Elyrien viu o movimento.

Afastou o objeto com a ponta da lâmina.

A peça caiu.

Rolou entre as folhas.

Era um pequeno cilindro de metal.

Lacrado.

Não era prova suficiente de uma origem imperial.

Mas era uma evidência.

Uma evidência que poderia ser examinada.

A guardiã observou o cilindro.

Depois o agressor.

Seu rosto permaneceu calmo.

ELYRIEN — ...Entendi.

Uma pausa.

ELYRIEN — Vocês não vieram roubar chá.

Neris, que observava de um corredor protegido, soltou uma risada nervosa.

Elyrien ergueu os olhos.

ELYRIEN — Embora isso também esteja se tornando um problema.

Naquela noite, Elyrien teria um prisioneiro, uma peça lacrada e uma pergunta sobre quem desejava interromper a pesquisa de sua comunidade.

Ainda não possuía uma resposta.

Nem conhecia Lucas.

Nem sabia que Três Arcos havia construído um novo distrito naquela tarde.

A distância entre aquelas histórias continuava real.

Mas, pela primeira vez, o mundo distante começava a apresentar sinais de uma movimentação que não poderia ser ignorada para sempre.

X — O fundador que não precisava de uma coroa

DIA 539 · 21h08 · CASA DO JARDIM BRANCO — VARANDA

Lucas estava sentado com Miren.

A cidade brilhava ao longe.

Não apenas Três Arcos histórica.

Agora havia luzes em outra direção.

O Horizonte Aberto.

Um distrito inteiro nascido naquela tarde.

Ainda silencioso.

Ainda esperando moradores.

Mas existente.

Miren encostou a cabeça no ombro do marido.

MIREN — Você conseguiu fazer muita coisa hoje.

Lucas sorriu.

LUCAS — Nós conseguimos.

Ela ergueu os olhos.

MIREN — Está feliz?

Ele observou o horizonte.

Depois a esposa.

LUCAS — Muito.

Miren sorriu.

MIREN — Mesmo com tantas responsabilidades novas?

Lucas pensou.

Depois abriu um sorriso descarado.

LUCAS — AMOR, EU ACABEI DE CRIAR UM GOVERNO QUE TEM AUTORIDADE PARA ME DIZER NÃO!

Miren começou a rir.

LUCAS — ISSO É UM AVANÇO CIVILIZACIONAL!

Ela o beijou.

O silêncio voltou.

Lucas observou as luzes.

Pensou em Kael.

Em Lysa.

Em Varo.

Em Maelis.

Em Brannik.

Nas pessoas que haviam aceitado responsabilidades que não seriam fáceis.

Naqueles que ainda poderiam discordar das novas instituições.

Na cidade que crescia.

E nas ruas vazias do Horizonte Aberto, esperando por histórias que ainda não existiam.

Miren segurou sua mão.

MIREN — Amanhã é o terceiro dia.

Lucas assentiu.

LUCAS — A cidade que conversa com o futuro.

Ela sorriu.

MIREN — Transporte e comunicação?

LUCAS — Transporte, comunicação, energia integrada, serviços, novas máquinas...

Miren ergueu uma sobrancelha.

MIREN — Lucas.

Ele parou.

LUCAS — Hm?

MIREN — Primeiro durma.

Lucas levou a mão ao peito.

LUCAS — MINHA SENHORA, VOCÊ ESTÁ ME IMPEDINDO DE REVOLUCIONAR O MUNDO!

Ela se aproximou.

Beijou-o demoradamente.

Quando se afastou, sorriu.

MIREN — O mundo continuará aqui amanhã.

Lucas observou o rosto dela.

Depois sorriu.

LUCAS — ...É.

Abraçou-a.

LUCAS — Mas vai estar muito mais bonito.

Miren riu baixinho.

Naquela noite, a Grande Casa dos Três Poderes brilhou sobre a praça cívica.

O Executivo começava a ganhar nova organização.

Kael preparava a constituição da Câmara Legislativa.

Varo iniciava a transição necessária para presidir o futuro Judiciário independente.

Lysa já discutia os princípios econômicos da Casa da Moeda.

Maelis começava a organizar a expansão da rede de saúde.

Brannik estava provavelmente acordado, desenhando alguma coisa que Dorek consideraria perigosíssima.

E Lucas...

Lucas estava com sua esposa.

O Criador possuía poder suficiente para erguer cidades.

Mas não precisava ocupar nenhum dos três poderes para continuar fazendo isso.

Seu lugar era outro.

Era o lugar de quem abria possibilidades.

De quem podia imaginar um mundo diferente.

E de quem desejava que as pessoas fossem livres para decidir o que fazer com ele.

FIM DA PARTE III DE V · CAPÍTULO 1

O SEGUNDO MARCO FOI ERGUIDO

Três Arcos agora tinha uma casa para seus poderes e um horizonte para os que ainda chegariam. O terceiro dia pertenceria às máquinas, às vozes e às estradas de um mundo que começava a mudar.

WORLDROOT · CHECKPOINT NARRATIVO Rascunho · Pendente de consolidação

Última cena

D539 · 21h08

Local

Casa do Jardim Branco

Marco concluído

2 de 3 · Horizonte Aberto

Próxima parte

Cap. 1 · Parte IV de V

Transformações realizadas nesta parte

Grande Casa dos Três Poderes fisicamente manifestada, preservando a Casa Cívica histórica.

Estrutura institucional de Executivo, Legislativo e Judiciário aprovada para implantação, com autonomia e controles recíprocos.

Kael aceita concorrer à presidência legislativa; Varo aceita presidir a futura estrutura judicial após a transição do comando militar. Lysa, Maelis e Brannik assumem a organização de suas áreas ministeriais.

Horizonte Aberto fisicamente construído, com 40 mil moradias e capacidade projetada para 100 mil futuros residentes, além de parques, escolas, edifícios de saúde, comércio e infraestrutura. Testes operacionais e ocupação ainda pendentes.

Meta de um milhão de habitantes mantida como ambição futura, não população presente.

Elyrien enfrentou agressores e obteve uma evidência ainda não identificada.

Terceiro marco pendente: mobilidade, Costura de Dados ampliada, serviços públicos integrados, funcionamento e manutenção da cidade antiga e do novo distrito.

Persistência externa: a Parte III está narrada nesta conversa, mas não foi gravada no GitHub ou no Drive nem promovida ao HEAD canônico. A escolha seguinte determinará sua continuidade.

As cinco portas do terceiro dia

LIVRO VI · CAPÍTULO 1 · PARTE IV DE V · DIA 540

1 — As máquinas que fizeram a cidade andar

Lucas e Brannik começam pelos veículos de transporte público, grandes composições arcanas, estações e rotas entre a cidade histórica, o Horizonte Aberto, AERÚN e os acessos ao Campo Aurora. O primeiro passeio público poderá ser um espetáculo.

[Escolher 1]

2 — A primeira voz do Horizonte Aberto

A Costura de Dados evolui numa rede arcana urbana. Chamadas por imagem, avisos cívicos e comunicação entre famílias, trabalhadores e pesquisadores começam a mudar o cotidiano de Três Arcos.

[Escolher 2]

3 — O primeiro dia das novas instituições

Lucas visita a Grande Casa dos Três Poderes e acompanha como Kael, Varo, Lysa, Maelis e Brannik começam a transformar uma arquitetura monumental em instituições que trabalham para pessoas reais, enquanto o terceiro marco tecnológico avança.

[Escolher 3]

4 — ESPECIAL: A cidade que fez o futuro chegar cedo

Lucas reúne toda sua genialidade inventiva com os talentos da Forja, AERÚN e da Malha Aurora. Transportes fantásticos, comunicação arcana, infraestrutura integrada, autômatos e as novas instituições começam a funcionar numa revolução sem precedentes.

Haverá humor, grandes criações com GÊNESE, vida com Miren, descobertas científicas e um mundo externo avançando por seus próprios caminhos. Nada de limitar arbitrariamente os poderes de Lucas.

[Escolher especial 4]

5 — AÇÃO LIVRE

Você determina exatamente como Lucas realizará o terceiro marco ou como deseja alterar a direção da história.

[Texto de orientação da área de texto: Escreva a próxima decisão de Lucas...] (Valor atual indisponível.)

[Confirmar ação livre]

“O primeiro dia mudou as ruas. O segundo construiu o horizonte e as instituições. No terceiro, a cidade descobriria que o futuro não precisava mais ser uma distância.”


<!-- WORLDROOT LIVRO-VI-C01 PARTE IV / LVI-C01-PIV-D540-AUTHOR-SOURCE -->

{@body const [acaoLivre540,setAcaoLivre540] = DIL.useState("");}
<box align="center" gap={1}>
  <text color="secondary" size="xs" weight="medium">CRÔNICAS DE UM NOVO MUNDO · WORLDROOT · HISTÓRIA VIVA</text>
  <title size="md" textAlign="center">A ERA DAS NOVE COROAS</title>
  <title size="xl" textAlign="center">LIVRO VI — AS COROAS PARTIDAS</title>
  <title size="lg" textAlign="center">CAPÍTULO 1 — O CRIADOR E A CIDADE DAS MIL FONTES</title>
  <title size="md" textAlign="center">PARTE IV DE V · ESPECIAL</title>
  <title size="lg" textAlign="center">A CIDADE QUE FEZ O FUTURO CHEGAR CEDO</title>
  <text color="secondary" size="sm" italic textAlign="center">“Há homens que esperam o futuro chegar. Outros constroem uma estação e ainda reclamam que ele está atrasado.”</text>
</box>

<box border radius="lg" padding={3} gap={2}>
  <text size="xs" color="secondary" weight="medium">CALENDÁRIO DO HORIZONTE</text>
  <grid columns={2} gap={3}>
    <grid-item>
      <text color="secondary" size="xs">Dia acumulado</text>
      **540**
    </grid-item>
    <grid-item>
      <text color="secondary" size="xs">Calendário</text>
      **Ano II · Mês 06 · Dia 25**
    </grid-item>
    <grid-item>
      <text color="secondary" size="xs">Primeira cena</text>
      **06h14 · Casa do Jardim Branco**
    </grid-item>
    <grid-item>
      <text color="secondary" size="xs">Marco</text>
      **3 de 3 · A cidade que conversa com o futuro**
    </grid-item>
  </grid>
  <text color="secondary" size="xs">Continuidade: Dia 539, 21h08. A Grande Casa dos Três Poderes e o Horizonte Aberto já existem; suas instituições e serviços ainda estão em implantação.</text>
</box>

## I — O homem que queria inventar a manhã

**DIA 540 · 06h14 — CASA DO JARDIM BRANCO**

Miren abriu os olhos porque alguém estava discutindo com o teto.

Não era uma metáfora.

**LUCAS —** Você está me dizendo que eu posso criar uma cidade em uma tarde, mas não consegue providenciar uma agenda com cinquenta horas no mesmo dia?

*O SISTEMA permaneceu em silêncio por dois segundos inteiros.*

*【SISTEMA — A duração convencional de um dia permanece inalterada.】*

**LUCAS —** Péssima administração do universo.

*【NÓX — Sugestão: reclamar com o responsável pela criação do universo. Talvez vocês tenham assuntos em comum.】*

Lucas apontou para o vazio.

**LUCAS —** Eu sabia que você estava acordado!

**MIREN —** O jardim inteiro sabia.

Ela se ergueu sobre um cotovelo. Seus cabelos caíram sobre o ombro, e o sorriso que lhe apareceu no rosto tinha o perigo particular de quem conhecia todos os pontos fracos do marido.

**MIREN —** Bom dia, fundador.

**LUCAS —** Bom dia, senhora que atrasa o progresso da civilização exigindo que o fundador durma.

**MIREN —** Dormiu quatro horas.

**LUCAS —** Quatro horas extraordinárias.

**MIREN —** Você roncou.

**LUCAS —** Era um mecanismo de ressonância. Estou desenvolvendo energia sonora.

Miren atirou-lhe o travesseiro.

Lucas o agarrou com uma dignidade tão exagerada que ambos acabaram rindo. Depois ele a puxou para perto, beijou-lhe a testa e ficou alguns instantes quieto. A luminosidade azulada da manhã atravessava as cortinas. Em algum lugar do jardim, um pássaro anunciava sua opinião sobre o mundo com mais convicção do que talento musical.

**MIREN —** Está pensando em quê, de verdade?

Lucas levou os olhos até a janela.

Dali se avistavam os telhados conhecidos de Três Arcos. Mais além, numa direção que dois dias antes abrigava apenas caminhos, vegetação e o terreno público levantado pela equipe, erguiam-se os domos claros e as torres do Horizonte Aberto.

**LUCAS —** Ontem criamos espaço para pessoas que ainda nem chegaram. Hoje quero que ninguém precise ser rico, poderoso ou amigo do fundador para ir de uma ponta à outra da cidade. Quero que alguém possa pedir ajuda sem percorrer três bairros. Quero que um estudante fale com o mestre. Que uma mãe encontre uma clínica. Que uma criança atravesse a praça sem arriscar a vida entre carruagens.

Miren o observou em silêncio.

**LUCAS —** E quero construir uma coisa absurdamente bonita. Porque sou um homem de princípios.

**MIREN —** O princípio de não fazer nada discreto?

**LUCAS —** Exatamente. Finalmente alguém reconhece meu pensamento político.

Ela lhe deu um beijo lento. Quando se afastou, havia carinho nos olhos, mas também a firmeza que o acompanhava desde que se conheceram.

**MIREN —** Vou à AERÚN. Astra e eu temos medições para revisar. Ajudo na Costura de Dados, desde que as portas dos laboratórios continuem sendo nossas portas, não as da prefeitura.

**LUCAS —** Privacidade por projeto. Você me ensinou.

**MIREN —** Você ouviu. Ainda estamos verificando se aprendeu.

**LUCAS —** Crueldade. Vinda da própria esposa.

Ela riu e saiu para se preparar. Lucas ficou na cama por mais alguns instantes, olhando o céu.

*【SISTEMA — Terceiro marco iniciado.】*

**LUCAS —** Não. O terceiro marco começa quando eu disser alguma coisa extraordinária.

*【NÓX — Então começará antes do café. E a cidade pagará por isso.】*

Lucas se levantou.

**LUCAS —** Anote, NÓX: hoje o impossível vai aprender a respeitar os horários do transporte público.

---

## II — Antes do milagre, a rua

**DIA 540 · 07h36 — GRANDE AVENIDA, TRÊS ARCOS**

Kael encontrou Lucas agachado diante de uma sarjeta.

O fundador da Cidade Livre estava usando uma pequena haste para retirar três folhas, um pedaço de corda e um brinquedo de madeira que bloqueavam uma passagem de água.

**KAEL —** Devo perguntar?

**LUCAS —** Não. Você vai estragar minha reputação.

**KAEL —** Qual delas?

**LUCAS —** A de gênio inatingível. Estou prestes a ser flagrado fazendo manutenção de rua.

Kael cruzou os braços. Ao lado dele, Lysa segurava uma pasta com anotações; Hedra, envolvida havia dias nos estudos de acessibilidade, examinava a inclinação de uma passagem.

A Grande Avenida estava bonita. Vitrais, pedras claras, árvores e pequenas fontes haviam renovado sua presença sem apagar o comércio antigo. Mas a cidade não tinha se transformado num cenário vazio. Havia gente trabalhando. Um padeiro discutia o preço da farinha. Duas crianças corriam atrás de uma fita vermelha. Uma carroça insistia em ocupar justamente o lugar que ninguém deveria ocupar.

**HEDRA —** A rua melhora quando chove pouco. Hoje, com mais água, este trecho ainda precisa de escoamento. Uma obra bela continua sendo uma obra incompleta se a senhora Salma não conseguir passar com o carrinho.

**LUCAS —** Então vamos impedir que a água faça turismo onde não foi convidada.

Lysa olhou a sarjeta desobstruída.

**LYSA —** Você veio sozinho e começou a consertar uma rua?

**LUCAS —** Eu posso criar rios, Lysa. Mas aparentemente ainda tenho de negociar com três folhas.

**LYSA —** Ótimo. Começa entendendo o problema antes de construir uma solução para dez mil problemas diferentes.

Ela abriu seus registros.

O encontro daquela manhã não aconteceria atrás das portas de um salão. Lucas insistira em caminhar com os responsáveis pelos serviços e alguns moradores. Primeiro, a cidade existente. Depois, o distrito novo. Não haveria inauguração que tratasse os velhos bairros como se tivessem se tornado menos importantes.

A velha Dália surgiu da entrada do mercado coberto, trazendo um embrulho de pão.

**DÁLIA —** Comam. A política fica insuportável de estômago vazio.

**KAEL —** Concordo com a senhora.

**LUCAS —** Traição institucional. Ainda nem instalamos o Legislativo.

Dália entregou pão a todos, inclusive a Hedra.

**DÁLIA —** Se vai criar transporte, ponha uma parada perto do mercado. Mas não em cima da entrada, e não quero que um veículo mágico leve embora nossos clientes antes que descubram o preço da mercadoria.

**LYSA —** Uma parada bem colocada pode trazer clientes.

**DÁLIA —** Então coloque duas.

**LUCAS —** Essa mulher deveria ministrar um curso de negociação.

Um homem que descarregava caixas levantou a mão. Queria saber se os novos veículos cobrariam tarifas. Outro perguntou quem consertaria as máquinas quando Lucas estivesse longe. Uma jovem aprendiz disse que as placas deveriam ser compreensíveis a quem ainda não lia a língua de Três Arcos.

Lucas não interrompeu nenhum deles.

Em vez disso, materializou no ar um desenho translúcido, pequeno o bastante para não bloquear a rua. Cinco caminhos de conexão se acenderam: centro histórico, mercado e ofícios, acesso público à AERÚN, estrada regional e a ligação externa ao Campo Aurora.

**LUCAS —** Isto é uma proposta. A rua real é a que está sob nossos pés.

Hedra tocou a imagem da primeira estação.

**HEDRA —** Aqui. Se a plataforma for mais alta, alguns usuários não conseguem embarcar. Se for mais baixa, há um vão perigoso. Não é questão de aparência.

A forma se alterou imediatamente.

**LUCAS —** Mostre a altura certa. Não vamos construir um veículo que alguém tenha de pedir desculpas para utilizar.

Kael observou Lucas.

**KAEL —** Você parece satisfeito demais por alguém ter encontrado defeitos.

**LUCAS —** Kael, um defeito descoberto antes de a criança cair não é uma derrota. É um elogio à inteligência de quem apontou.

Lysa fechou sua pasta.

**LYSA —** E as decisões sobre tarifas, operação e prioridades serão públicas. Você constrói a maravilha. Nós teremos de responder por ela.

Lucas abriu um sorriso enorme.

**LUCAS —** É por isso que contratei pessoas capazes de dizer não.

**LYSA —** Você não me contratou.

**LUCAS —** E esse é o maior defeito do meu sistema de poder.

---

## III — Uma forja, um louco e a palavra “freio”

**DIA 540 · 09h08 — FORJA AURORA, ANEL DOS OFÍCIOS**

A primeira coisa que Lucas ouviu foi uma explosão.

A segunda foi Brannik gritando:

**BRANNIK —** ESTÁ TUDO SOB CONTROLE!

A terceira foi Dorek:

**DOREK —** NÃO ESTAVA!

Lucas atravessou as portas da oficina e encontrou uma nuvem de vapor saindo de um protótipo de aquecimento. Nenhuma pessoa estava ferida. Dorek desligara a válvula de alimentação, enquanto Brannik contemplava a máquina como um pai orgulhoso de um filho profundamente problemático.

**LUCAS —** Bom dia, meus gênios. Quantas construções públicas vocês derrubaram desde ontem?

**DOREK —** Nenhuma. Foi por muito pouco.

**BRANNIK —** A CIÊNCIA NÃO AVANÇA SEM BARULHO!

**DOREK —** Avança muito bem com um dispositivo de segurança.

**LUCAS —** Quero os dois no Ministério da Inovação. Um inventa o futuro, o outro impede que o futuro exploda a cozinha.

Brannik abriu um pergaminho gigantesco. Não era uma lista de compras: era o esboço de uma composição de transporte arcano, com arcos de sustentação e rodas quase ocultas sob o assoalho.

**BRANNIK —** O carro pode atravessar a cidade sem cavalos. Uma malha de fluxo distribui energia para a tração, e os freios não dependem da vontade de um único condutor.

**DOREK —** Este último detalhe foi minha ideia.

**LUCAS —** Sábio. Revolucionário. Extremamente pouco empolgante.

**DOREK —** Você vai agradecer.

Perto de uma janela, Rumo estava estudando uma pequena peça de vidro.

**LUCAS —** Rumo! Você veio ajudar?

**RUMO —** Vim olhar. Talvez ajude. Ainda não decidi.

**LUCAS —** Maravilhoso. O único sujeito nesta oficina que sabe negociar antes de aceitar um cargo.

**RUMO —** Ontem fiz algo que não serve para consertar nada.

Ele estendeu a peça. Dentro do vidro, uma minúscula estrela mecânica girava sem se repetir exatamente. Era bonita. Inútil em termos práticos. Deliberadamente sua.

Lucas examinou-a com a atenção que reservaria a uma descoberta de outro mundo.

**LUCAS —** Eu daria uma fortuna por isso.

**RUMO —** Não está à venda.

**LUCAS —** Melhor ainda. É uma obra de arte de verdade.

Rumo recolheu o objeto com um cuidado quase tímido.

A imagem de Naira surgiu no terminal autorizado da Costura de Dados. Ao fundo, apareciam estruturas do Campo Aurora e uma parte do hangar de ARGOS.

**NAIRA —** Antes que alguém pergunte: não, o avião não fará um voo comemorativo.

**BRANNIK —** NINGUÉM PERGUNTOU!

**NAIRA —** Foi por isso que me antecipei.

Ela exibiu a planta do perímetro externo. A aproximação dos transportes públicos poderia terminar num terminal afastado das zonas operacionais de voo. Nenhum trilho atravessaria a rota reservada à aeronave, e o acesso à área protegida continuaria dependendo de autorização.

**LUCAS —** Excelente. O avião é seu território. O transporte termina onde você disser que é seguro.

Naira ergueu uma sobrancelha.

**NAIRA —** Registre isso. Um dia alguém vai duvidar que você concordou tão depressa.

Dorek trouxe o desenho dos travamentos. Hedra enviara as dimensões acessíveis das plataformas. Kael já obtivera autorização para intervenções nas passagens públicas e preservação das entradas existentes. E Brannik, naturalmente, pedira mais espaço para as curvas.

Lucas contemplou todos aqueles esforços reunidos.

**LUCAS —** Então estamos prontos.

**DOREK —** Para um protótipo.

**LUCAS —** Dorek, meu amigo, nunca confunda protótipo com limite de imaginação.

**DOREK —** E você nunca confunda imaginação com certificação de passageiros.

Lucas o abraçou pelos ombros.

**LUCAS —** Por isso trabalhamos juntos.

---

## IV — Quando a cidade ouviu o ferro cantar

**DIA 540 · 10h42 — CORREDOR ENTRE A GRANDE AVENIDA E O HORIZONTE ABERTO**

O vento parou por um instante.

As pessoas da praça sentiram primeiro a mudança na luz. Não um apagão. O contrário: o ar pareceu adquirir uma profundidade desconhecida, como se fosse possível enxergar a forma futura das coisas antes de elas existirem.

Lucas estava no centro de um terreno público reservado ao corredor de transporte. De um lado havia a cidade antiga, com suas torres desiguais e telhados vivos. Do outro, as cúpulas do Horizonte Aberto ainda aguardavam suas primeiras histórias.

**LUCAS —** Vocês pediram uma cidade que funcionasse.

Ele abriu os braços.

**LUCAS —** Eu trouxe a parte em que ela fica bonita pra caramba.

*【SISTEMA — Autoridade de GÊNESE reconhecida.】*

Não houve contagem regressiva.

**LUCAS —** **GÊNESE.**

O chão não explodiu. Ele floresceu.

Faixas de pedra se abriram como fitas de mármore desenhadas por mãos invisíveis. Sobre elas surgiram trilhos de liga clara, assentados com precisão. Os encaixes não arrancaram paredes, não invadiram casas; seguiam as rotas conferidas pelos moradores, e onde as ruas antigas eram estreitas a via se tornava elevada ou contornava os quarteirões.

Arcos de sustentação surgiram entre árvores preservadas. Pontes elegantes atravessaram cursos d'água sem bloquear a correnteza. Pequenos pavilhões de embarque ganharam colunas delicadas, teto de vidro colorido e bancos à sombra. Cada parada combinava com o bairro em que nascia, como se tivesse sido imaginada por alguém que amava aquela rua havia gerações.

Então vieram os veículos.

No pátio de montagem do novo distrito, vinte e quatro composições de transporte leve surgiram em sequência, uma após a outra, não como soldados alinhados para desfile, mas como criaturas elegantes que acabassem de descobrir o movimento. Tinham painéis de madeira polida, metal prateado, grandes janelas e inscrições luminosas de orientação. O piso era contínuo, o acesso sem degraus.

Mais além, noventa e seis veículos coletivos menores tomaram forma: alguns largos para as avenidas, outros compactos para as ruas antigas, todos com sistemas de frenagem independentes, visibilidade para os passageiros e espaço para quem viajasse com carrinhos, mercadorias leves ou equipamentos de mobilidade.

A multidão ficou muda.

Por exatos três segundos.

**BRANNIK —** AAAAAAAAAAH!

**DOREK —** É uma exclamação de satisfação ou de perigo?

**BRANNIK —** DE AMBAS AS COISAS!

Uma criança apontou para a primeira composição.

**CRIANÇA —** É um dragão?

Lucas agachou-se para ficar à sua altura.

**LUCAS —** Não. Um dragão cobra para te levar?

**CRIANÇA —** Acho que sim.

**LUCAS —** Então é melhor. Esse aqui ainda vai ter uma política de tarifas discutida por adultos muito sérios.

Os olhos do menino se arregalaram.

**CRIANÇA —** Prefiro o dragão.

Kael soltou uma gargalhada antes de conseguir se controlar.

Lucas ergueu a mão novamente. Um grande painel público mostrou as duas linhas principais e os caminhos de ligação. Dezoito estações haviam sido criadas no novo distrito, com conexões aos pontos da cidade antiga, ao mercado, ao acesso público de AERÚN e ao terminal externo do Campo Aurora. Os depósitos de reserva não estavam escondidos atrás de portões ornamentais: possuíam oficinas, pátios de manutenção e acessos para trabalhadores reais.

**LUCAS —** Vinte composições preparadas para entrar em operação por etapas. Quatro ficam de reserva. E os veículos menores servirão tanto à cidade antiga quanto ao Horizonte. Nada de criar um bairro maravilhoso e mandar todo mundo caminhar até ele.

Hedra se aproximou da estação mais próxima. Examinou a plataforma, pediu a uma usuária que experimentasse o embarque e mediu um pequeno vão.

**HEDRA —** Corrija aqui.

Lucas corrigiu.

**HEDRA —** E aqui.

Ele corrigiu outra vez.

**LUCAS —** Vai me pedir para refazer o universo inteiro?

**HEDRA —** Só as partes que não permitem embarcar.

**LUCAS —** Justo.

Dorek iniciou ensaios de frenagem numa faixa segregada. Um dos veículos parou onde deveria. Outro parou alguns passos antes. A diferença não era defeito da GÊNESE: era uma escolha de configuração de serviço, inadequada à distância prevista para passageiros em pé.

Dorek marcou o problema. Lucas ajustou a matriz de controle. A prova seguinte foi precisa.

Não houve enfraquecimento do Criador. Houve gente competente usando a capacidade dele para construir algo que pudesse ser compartilhado.

Lysa observava a reação dos comerciantes.

**LYSA —** E não vamos anunciar toda a frota como serviço público liberado só porque ela existe.

**LUCAS —** Eu sei. Ensaios, operação setorizada, equipes responsáveis.

**LYSA —** Está aprendendo.

**LUCAS —** Eu sempre aprendo. Só reclamo do currículo.

Quando a primeira composição acendeu sua placa — **LINHA DAS TRÊS FONTES** — a praça inteira aplaudiu.

Lucas não pediu aplausos.

Mas, quando Brannik começou a chorar de felicidade enquanto Dorek fingia procurar um defeito na manga, o Criador precisou olhar para o céu para não rir alto demais.

---

## V — O primeiro bilhete não tinha dono

**DIA 540 · 12h06 — ESTAÇÃO DO MERCADO, TRÊS ARCOS**

A primeira viagem não foi reservada a nobres.

Também não foi reservada a Lucas.

Foi Salma quem subiu primeiro, empurrando o carrinho pelo mesmo caminho em que, dois dias antes, as rodas costumavam prender nas pedras. Atrás dela vinham Dália, dois trabalhadores das oficinas, uma senhora com uma bengala e o menino que preferia dragões.

Uma funcionária de transporte, escolhida pela equipe local para acompanhar os ensaios, anunciou a rota. Havia um responsável humano presente, os dispositivos de emergência tinham sido testados e ninguém estava sendo usado como cobaia sem saber.

**SALMA —** Vai mesmo andar sozinho?

**BRANNIK —** PELOS CÉUS, SIM!

**DOREK —** Sob supervisão.

**SALMA —** Prefiro a segunda resposta.

O carro deslizou.

Sem solavanco.

Sem o cheiro de animais cansados. Sem rodas esmagando a lama. As janelas mostravam Três Arcos avançar lentamente, em todo o esplendor imperfeito de suas ruas: o vendedor de flores, as cortinas abertas, o rapaz que correu atrás do transporte com um pão na mão e descobriu que não era uma boa ideia tentar alcançá-lo.

Lucas tinha decidido ficar em pé, observando os rostos.

**KAEL —** Você poderia sentar.

**LUCAS —** Estou trabalhando.

**KAEL —** Está sorrindo para uma janela.

**LUCAS —** Trabalho de fundador. Exige postura.

Quando a composição atravessou a primeira ponte, o Horizonte Aberto surgiu do outro lado do rio: praças verdes, torres, mercados cobertos, telhados de cores diversas. A cidade nova parecia um convite. Não uma vitrine onde os moradores antigos fossem proibidos de tocar.

Salma segurou a lateral do carrinho.

**SALMA —** Antes eu levava metade da manhã para chegar ao outro lado, quando o caminho estava ruim.

Ela ficou em silêncio, acompanhando a passagem da paisagem.

**SALMA —** Agora talvez eu consiga visitar minha irmã depois do trabalho.

Lucas não respondeu de imediato.

A mulher não estava falando de uma conquista tecnológica. Falava de uma pessoa de quem sentia falta.

**LUCAS —** Então a primeira viagem já valeu a construção.

Dália pigarreou.

**DÁLIA —** E os preços?

Lysa apareceu com uma folha de anotações.

**LYSA —** Hoje é ensaio gratuito. O serviço regular e suas condições ainda serão deliberados com participação pública. Sem tarifa inventada no meio da inauguração.

**LUCAS —** Viu? Existe uma mulher que consegue impedir que eu dê transporte gratuito para o continente inteiro por impulso.

**LYSA —** Ainda bem que não temos serviço continental.

A senhora da bengala levantou a mão.

**SENHORA —** E de noite? Eu volto tarde da casa do meu filho.

**KAEL —** A proposta é serviço dia e noite, com reforço nos horários de maior movimento. A equipe vai publicar rotas reais e horários testados, não promessas impossíveis.

**LUCAS —** E a primeira vez que alguém ficar sem resposta, quero saber onde falhamos.

A criança encostou a testa na janela.

**CRIANÇA —** Ainda prefiro um dragão.

Lucas se inclinou.

**LUCAS —** Está bem. Mas quando um dragão começar a parar em todas as estações, me avise. Vou querer conhecer o engenheiro dele.

Desta vez, até Dorek riu.

---

## VI — Uma voz atravessa a cidade, não o mundo

**DIA 540 · 13h43 — AERÚN, ENTRADA PÚBLICA DO INSTITUTO**

Miren recebeu Lucas diante de um pórtico que ele conhecia bem.

As portas que levavam aos espaços públicos de ensino estavam abertas. Os corredores internos de pesquisa permaneciam sujeitos às regras de AERÚN. Nada da construção feita na cidade havia atravessado as proteções do setor S−4.

**MIREN —** Soube que você construiu um transporte bonito.

**LUCAS —** Um? Amor, você fere minha reputação estatística.

**ASTRA —** É verdade que o primeiro passageiro perguntou se a máquina era um dragão?

**LUCAS —** A crítica popular tem sido implacável.

Astra abriu uma série de registros sobre uma mesa. A Costura de Dados já permitia chamadas regionais autorizadas desde o Dia 533. Agora o objetivo era outro: tornar a comunicação municipal acessível sem transformar todos os lares em salas de vigilância.

Lucas manifestou a primeira estrutura de ligação sobre o pátio exterior. Não era uma torre hostil, revestida de metal escuro. Era um pequeno domo cristalino, com seis aros que pareciam florescer à luz do sol.

Ao longe, outros pontos responderam.

Seis núcleos municipais surgiram nos locais acordados; vinte e quatro repetidores acompanharam os corredores públicos; sessenta quiosques de informação ganharam forma junto a mercados, bibliotecas, praças e serviços, sem substituir recados em papel nem obrigar ninguém a possuir um aparelho.

A cidade não ganhou olhos para espiar cidadãos.

Ganhou meios para fazer perguntas e receber respostas.

**ASTRA —** A rede encaminha uma mensagem apenas para o destino autorizado. O sistema técnico pode indicar que uma ligação falhou. Não pode concluir por isso o que duas pessoas estavam conversando.

**LUCAS —** Excelente. Até minhas ideias ruins merecem intimidade.

**MIREN —** Especialmente elas.

A primeira ligação pública foi feita entre uma estação do mercado e a entrada de AERÚN. Na imagem, Dália apareceu segurando pão e gesticulando diante do cristal.

**DÁLIA —** Se estão me vendo, respondam: por que aqui parece que minha cabeça ficou enorme?

**ASTRA —** É o enquadramento.

**DÁLIA —** Não gosto do enquadramento.

Lucas aproximou o rosto do terminal.

**LUCAS —** Dália, você está maravilhosa!

**DÁLIA —** Mentiroso. Mas continue.

A ligação foi encerrada entre risadas.

Um instante depois, o sorriso de Miren desapareceu. Não por alarme, mas por concentração. Ela tocou dois registros da pesquisa que Astra trouxera. Um conjunto de leituras do Coração de Convergência mostrava pequenas oscilações, observadas em ensaios separados. Não eram mensagens. Não constituíam evidência de que Talis estivesse próxima. Havia hipóteses demais e dados de menos.

**MIREN —** Isto ocorreu antes da expansão municipal. Não podemos atribuir a mudança às torres que você acabou de criar.

**ASTRA —** Nem podemos dizer que não há relação com a Rede antiga. Precisamos repetir o ensaio mantendo o mesmo instrumento e as mesmas condições.

Lucas ficou quieto. O nome de Talis não fora pronunciado, mas sua ausência habitava certas pausas entre marido e mulher.

**LUCAS —** Quer que eu examine alguma coisa?

**MIREN —** Quero que deixe a equipe trabalhar. E, quando tivermos uma pergunta que sua GÊNESE possa responder, eu mesma vou chamá-lo.

Lucas tomou a mão dela.

**LUCAS —** Combinado. Só não espere que eu finja não estar preocupado.

Miren apertou-lhe os dedos.

**MIREN —** Não esperaria isso de você. Seria uma descoberta mais improvável que as nossas.

Ao sair, Lucas viu dois aprendizes fazendo uma chamada para familiares em outra parte da cidade. Riam porque um dos pequenos irmãos insistia em aparecer de cabeça para baixo na imagem.

Ele compreendeu, outra vez, que o futuro tinha mania de se esconder em acontecimentos minúsculos.

---

## VII — A cidade não pertence às máquinas

**DIA 540 · 15h25 — CENTRO DE SERVIÇOS DO HORIZONTE ABERTO**

Vértice recebeu os visitantes junto a um mapa técnico das duas áreas urbanas.

Os três mil e seiscentos autômatos funcionais da Malha Aurora já existiam havia dias. Alguns cuidavam dos jardins, outros atuavam nos serviços autorizados, nas oficinas e em manutenção. Vértice os coordenava tecnicamente. Não governava cidadãos.

**VÉRTICE —** A malha existente não pode abandonar a cidade histórica para atender integralmente o distrito novo. Proponho expansão de equipes de manutenção, setores de água e resíduos e reserva de resposta.

**LUCAS —** É uma proposta muito educada para dizer que eu construí trabalho demais.

**VÉRTICE —** Correto.

**LUCAS —** Gosto quando as máquinas desenvolvem a habilidade de me humilhar com precisão.

A criação seguinte foi silenciosa e grandiosa ao mesmo tempo.

No pátio técnico surgiram mil e quinhentas unidades funcionais adicionais de manutenção e proteção civil. Não eram vidas conscientes como Rumo. Eram autômatos operacionais, com atribuições limitadas e registros claros de uso: água, energia, saneamento, resíduos, parques, logística, apoio não violento a resgates e equipes de reserva.

A contagem não incluiu Vértice. Tampouco incluiu Rumo. Nem se misturou aos cento e vinte veículos novos de transporte.

Lucas percorreu a fileira, que se dividiu sem cerimônia em equipes de serviço.

**LUCAS —** Vértice, nenhuma dessas unidades vai transformar a praça numa prisão muito organizada. Segurança técnica, manutenção, ajuda em emergências. Pessoas continuam sendo pessoas.

**VÉRTICE —** Entendido. Autoridade judicial e política não atribuídas.

Maelis chegou acompanhada de dois profissionais de saúde e de uma representante dos trabalhadores da cidade antiga.

**MAELIS —** Ouvi dizer que agora temos um hospital de quatrocentos leitos.

**LUCAS —** Temos o edifício. Equipamentos também.

**MAELIS —** Ótimo. Então já posso anunciar que temos um belo edifício com equipamentos. Ainda precisamos das equipes, dos protocolos, dos medicamentos devidamente organizados e das pessoas que vão cuidar de outras pessoas.

**LUCAS —** Eu poderia criar mais utensílios.

**MAELIS —** E eu adoraria que criasse. Mas um leito vazio não consola uma criança com febre.

Lucas olhou a mulher, depois o hospital ao longe.

**LUCAS —** Você terá o que precisar para funcionar. Sem obrigação de declarar aberta uma ala que não está pronta.

Maelis assentiu. Não agradeceu como quem recebe uma graça. Era uma profissional assumindo responsabilidade real.

Perto dali, as primeiras unidades de tratamento de água começaram a operar em circuito de ensaio. Os quatro módulos arcanos de cinquenta megawatts do distrito foram energizados com redundância, reservação e sistemas de isolamento. Não eram uma promessa de abastecer toda a cidade antiga sem dimensionar sua demanda. As redes históricas receberam derivações e proteções próprias, testadas por setores.

Houve um problema que nenhum espetáculo antecipara.

Uma senhora apareceu reclamando que a água de sua rua estava fazendo barulho dentro de uma tubulação antiga.

**SENHORA —** Não quero que o cano cante. Quero lavar minhas panelas.

Os técnicos verificaram o registro. Uma válvula de ligação fora aberta no setor errado. Lucas podia reconstruir toda a tubulação de uma só vez — e o fez no trecho necessário, sem tocar nas casas —, mas deixou que a equipe identificasse primeiro a causa.

**LUCAS —** Está resolvido.

A senhora cruzou os braços.

**SENHORA —** Ainda não lavei as panelas.

O fluxo foi testado. A torneira voltou a correr normalmente.

**SENHORA —** Agora sim. Pode voltar a fazer milagres.

Lysa, que chegara a tempo de ouvir a conclusão, quase perdeu o fôlego de tanto rir.

**LYSA —** A primeira cidadã a conceder licença formal para a sua GÊNESE.

**LUCAS —** Os três poderes são pouco. Precisamos criar o quarto: a autoridade das panelas.

A cidade técnica continuou funcionando mesmo com as ruas novas praticamente vazias. Iluminação, reservatórios, limpeza, jardins, estações e oficinas tinham manutenção. Não havia cem mil moradores escondidos em edifícios recém-criados. Havia espaço para futuros habitantes, e gente real preparando a chegada deles.

---

## VIII — O palácio onde o fundador podia ouvir um “não”

**DIA 540 · 17h12 — GRANDE CASA DOS TRÊS PODERES**

A luz da tarde atravessava os vitrais do salão central da Grande Casa.

Era monumental.

Colunas brancas erguiam-se sobre jardins e espelhos d'água. Três alas partiam do núcleo preservado da antiga Casa Cívica. Nenhuma delas estava acima das outras. Era arquitetura feita para que o poder lembrasse diariamente que não devia se concentrar numa única mão.

Kael aguardava com representantes civis. Sua futura candidatura à presidência legislativa seria submetida à confirmação pública prevista na transição. Varo participava da organização inicial do Judiciário, ainda responsável por concluir a transferência regular do comando da Legião. Lysa tratava dos fundamentos econômicos e da Casa da Moeda; nenhuma moeda nova havia sido lançada. Maelis trazia a lista de profissionais e serviços de saúde que ainda exigiam implantação. Brannik tinha desenhos suficientes para ocupar uma mesa e metade do chão.

A reunião começou com uma pergunta desconfortável.

Uma representante dos bairros antigos levantou-se.

**REPRESENTANTE —** Fundador, você ergueu prédios, distritos e máquinas. É impressionante. Mas quem garante que amanhã você não vai decidir que o povo precisa viver como você imaginou?

O silêncio que se seguiu foi genuíno.

Kael não interveio para proteger Lucas.

Miren, que havia chegado após sua jornada em AERÚN, permaneceu junto à janela, observando. Ela também esperava a resposta.

Lucas caminhou até o centro do salão.

**LUCAS —** Ninguém deve depender da minha boa vontade para ser livre. Nem da de Kael, de Varo, de Lysa, ou de quem vier depois deles.

Ele mostrou as três alas com um gesto.

**LUCAS —** Eu posso construir uma ponte em minutos. Mas não posso exigir que vocês a atravessem só porque a considero bonita. Posso criar uma Casa para os poderes. Não vou fingir que isso me dá o direito de ser os três.

Uma voz veio das cadeiras do fundo.

**MORADOR —** Então você é o quê?

Lucas abriu aquele sorriso insuportavelmente seguro que seus amigos conheciam.

**LUCAS —** Eu? Sou o sujeito que vai dar muito trabalho a todos vocês.

Algumas pessoas riram.

**LUCAS —** Um rei olha para uma porta e pergunta quem tem permissão para entrar. Eu olho para uma parede e pergunto por que ainda não construímos mais portas.

O silêncio mudou de natureza.

**LUCAS —** Sou o fundador. Não o dono do futuro. Se as instituições forem incapazes de me contrariar, então construí um monumento à vaidade, não uma cidade livre.

Varo levantou-se.

**VARO —** E uma Justiça independente deve ter poder para examinar as decisões de qualquer cidadão, inclusive as suas. Minha transição só estará completa quando o comando da Legião estiver separado do meu futuro cargo.

Kael concordou.

**KAEL —** O Legislativo precisa ser legitimado por seus representantes. Não vou sentar na presidência como se ela tivesse sido entregue de presente.

**LYSA —** E o orçamento será público. Recursos para transporte, saúde e manutenção não desaparecem por entusiasmo arquitetônico.

**BRANNIK —** A INOVAÇÃO, POR OUTRO LADO—

**DOREK —** Também terá orçamento.

**BRANNIK —** EU NÃO ESTAVA RECLAMANDO!

**DOREK —** Ainda.

A representante que fizera a pergunta encarou Lucas.

**REPRESENTANTE —** Você aceita que possamos suspender uma obra sua?

Lucas respondeu sem perder o sorriso.

**LUCAS —** Aceito. Mas quero a razão por escrito, porque pretendo discutir de maneira absolutamente irritante.

Desta vez, a gargalhada se espalhou pelo salão.

Miren aproximou-se quando a reunião terminou.

**MIREN —** Você foi bem.

**LUCAS —** Fui extraordinário.

**MIREN —** Estava indo bem até essa frase.

**LUCAS —** A modéstia é um preço que a grandeza não deveria pagar.

**MIREN —** Venha. Antes que te elejam presidente de alguma coisa por engano.

---

## IX — Uma janela para o pôr do sol

**DIA 540 · 19h02 — PONTE DAS FONTES, PRIMEIRA LINHA PÚBLICA**

A composição da Linha das Três Fontes saiu devagar da estação.

Agora não levava apenas técnicos e participantes de um ensaio. Transportava moradores inscritos para os primeiros trajetos acompanhados, trabalhadores que precisavam voltar para casa e curiosos que desejavam saber se o futuro tinha bancos confortáveis.

As lanternas da cidade antiga se acendiam.

Do outro lado do rio, o Horizonte Aberto brilhava com centenas de pequenas luzes. Os pavilhões de comunicação exibiam avisos públicos; um quiosque orientava viajantes até o mercado; uma oficina ainda preparava a escala de manutenção noturna. As pontes refletiam as cores do céu.

Lucas e Miren estavam sentados juntos, por uma vez sem discutir projetos.

**MIREN —** Conseguiu fazer tudo que queria?

Lucas observou uma mulher mostrar a uma criança o mapa luminoso das paradas.

**LUCAS —** Não.

**MIREN —** Ainda bem.

**LUCAS —** Descobri uma coisa terrível. Toda vez que resolvemos um problema, as pessoas ficam livres para ter ideias melhores.

Miren apoiou a cabeça no ombro dele.

O veículo passou pela parte da ponte em que uma menina, no Dia 538, pedira um lugar para ver o pôr do sol. A plataforma de observação havia sido integrada à travessia, acessível, com bancos baixos e espaço seguro junto à água.

Havia crianças ali agora.

Uma delas acenou para o veículo.

Lucas acenou de volta com os dois braços, como um homem que acabara de ganhar uma batalha.

**MIREN —** Era isso, não era?

Ele ficou em silêncio.

Lembrou-se de Três Arcos quando mal começara a acreditar que poderia pertencer a algum lugar. Dos amigos que não tinham se tornado seguidores. Das pessoas que continuavam dizendo o que pensavam. Das ruas que agora carregavam novos caminhos, mas ainda tinham o cheiro do pão assando nas esquinas.

**LUCAS —** Eu queria construir algo tão grande que o mundo tivesse de prestar atenção.

Miren ergueu os olhos.

**LUCAS —** Mas acho que as coisas mais importantes não fazem barulho nenhum.

O veículo reduziu a velocidade.

Uma criança apontou para o horizonte vermelho.

**CRIANÇA —** Mãe, olha!

A mãe se inclinou ao lado dela.

Lucas sorriu.

**LUCAS —** Está vendo? Agora elas podem chegar lá.

Miren o beijou.

Por um instante, o fundador esqueceu ministérios, estações e sistemas. O mundo se tornou aquele beijo, o ruído suave dos trilhos e as mãos entrelaçadas dos dois.

*【NÓX — Registro histórico: o Criador concluiu a maior revolução de transporte da cidade e continua sendo guiado pela esposa.】*

**LUCAS —** Guiado? Eu diria inspirado.

*【SISTEMA — Termo mais exato: frequentemente corrigido.】*

Miren riu sem soltar a mão dele.

---

## X — A guardiã e o metal sem nome

**DIA 540 · 20h18 — FLORESTA DISTANTE, CASA DE PESQUISA DE ELYRIEN**

O homem capturado não falara.

Elyrien não interpretou seu silêncio como confissão de qualquer coisa.

Neris acendeu uma lâmpada sobre a mesa e estendeu o pequeno cilindro recuperado no ataque da véspera. A peça havia sido isolada de outras amostras. A guardiã examinara sua superfície, pesara-a, comparara marcas de manufatura com registros locais. Nenhuma dessas verificações apontava com segurança para um reino ou império.

**NERIS —** Pode ser um selo militar?

**ELYRIEN —** Pode. Também pode ser mercantil, ritual ou uma imitação de qualquer uma dessas coisas.

**NERIS —** Então não sabemos quase nada.

**ELYRIEN —** Sabemos que dois homens atacaram uma casa de pesquisa. Sabemos que um deles carregava isto e tentou alcançá-lo antes de se render. Sabemos que o outro escapou.

Ela girou o cilindro com cuidado.

**ELYRIEN —** Não é pouco. Só não é suficiente.

Uma criança da comunidade entrou para avisar que o prisioneiro recebera água e que as patrulhas haviam reforçado as trilhas. Elyrien agradeceu. Não ordenou uma perseguição cega pela mata. Neris queria voltar aos registros do local onde encontraram certos fragmentos antigos. A guardiã prometeu acompanhá-la quando fosse seguro.

Do lado de fora, a floresta respirava.

Elyrien foi até o jardim e encontrou, finalmente, a xícara esquecida sobre uma pedra.

O chá estava frio.

**ELYRIEN —** A maior conspiração de todas.

**NERIS —** O quê?

**ELYRIEN —** O tempo. Sempre contra meu chá.

A jovem riu.

Aquelas duas mulheres ainda não conheciam Lucas. Não tinham recebido notícia da revolução urbana de Três Arcos. O cilindro não revelara a identidade de seu dono. O mundo permanecia vasto, cheio de distâncias reais e intenções que não se entregavam a um olhar.

Mas agora havia uma pergunta registrada, um objeto guardado e pessoas dispostas a descobrir a verdade.

---

## XI — O Criador e a cidade que ainda precisava viver

**DIA 540 · 21h17 — CASA DO JARDIM BRANCO, VARANDA**

Lucas chegou em casa carregando um pequeno pacote.

Miren estreitou os olhos.

**MIREN —** O que é isso?

**LUCAS —** Um presente extraordinário, proveniente dos avanços mais sofisticados da engenharia urbana.

Ela abriu o embrulho.

Era um pão doce comprado no mercado.

**MIREN —** Você comprou pão.

**LUCAS —** Comprei tempo. Dália disse que a padaria da esquina agora consegue entregar produtos ao mercado usando o novo veículo de carga. O pão chegou ainda quente.

Miren provou um pedaço.

**MIREN —** Está muito bom.

**LUCAS —** Eu sei. A civilização finalmente alcançou seu apogeu.

Lá fora, a cidade antiga cintilava. As primeiras composições continuavam em circulação nas rotas autorizadas; parte da frota permanecia em reserva ou ensaio. O Horizonte Aberto, quase vazio de moradores, era mantido por suas equipes técnicas. Os novos serviços de comunicação já aproximavam vizinhos e trabalhadores. Hospitais e escolas preparados esperavam sua implantação humana. A Grande Casa dos Três Poderes ainda precisaria de deliberações, eleições, regras, nomeações e compromissos reais.

Nada disso diminuía a maravilha.

Apenas a tornava pertencente às pessoas.

Miren encostou-se ao marido.

**MIREN —** Você mudou a cidade em três dias.

**LUCAS —** Não sozinho.

**MIREN —** Eu sei.

**LUCAS —** E não acabou.

**MIREN —** Eu sei disso também.

Ele sorriu, olhando as duas Três Arcos ligadas por fios de luz e por caminhos de pedra.

**LUCAS —** Sabe o que é o mais impressionante?

**MIREN —** Que Brannik ainda não incendiou o Ministério da Inovação?

**LUCAS —** Isso é o segundo lugar.

Ela gargalhou.

Lucas ficou sério por um instante.

**LUCAS —** Ontem construímos espaço para cem mil pessoas. Hoje construímos caminhos para quem já está aqui. Um dia, talvez sejamos um milhão. Mas eu não quero uma cidade enorme só para poder dizer que ela é enorme.

Ele segurou a mão dela.

**LUCAS —** Quero um lugar onde alguém que chegou sem nada possa descobrir que não está sozinho.

Miren o beijou na face.

**MIREN —** Então amanhã ainda teremos trabalho.

**LUCAS —** Amanhã, depois de dormirmos?

**MIREN —** Principalmente depois.

*【SISTEMA — Terceiro marco: manifestações físicas concluídas; implantação civil e operação contínua em evolução.】*

Lucas ergueu um dedo.

**LUCAS —** Viu, NÓX? Até o Sistema reconhece minha grandeza.

*【NÓX — Reconhece que você construiu coisas. Não extrapole.】*

**LUCAS —** Eu me cerco de ingratos.

Miren apoiou a cabeça em seu ombro. Abaixo deles, uma composição luminosa atravessou uma ponte e desapareceu entre as árvores.

Não havia coroa sobre a cabeça do fundador.

Havia uma cidade inteira encontrando novos caminhos.

E, além das estradas e dos mares, o mundo continuava a viver histórias que Três Arcos ainda não conhecia.

**FIM DA PARTE IV DE V · CAPÍTULO 1**

*O primeiro marco mudara as ruas. O segundo construíra o horizonte e as instituições. No terceiro, Três Arcos aprendera a se mover e a conversar consigo mesma. O futuro chegara cedo — e agora teria de aprender a conviver com as pessoas que encontrara.*

<box border radius="lg" padding={3} gap={2}>
  <text color="secondary" size="xs" weight="medium">WORLDROOT · CHECKPOINT NARRATIVO · RASCUNHO ARQUIVADO</text>
  <grid columns={2} gap={2}>
    <grid-item>**Dia 540 · 21h17**</grid-item>
    <grid-item>**Casa do Jardim Branco**</grid-item>
    <grid-item>**Marco 3/3 realizado**</grid-item>
    <grid-item>**Próxima parte: V de V**</grid-item>
  </grid>
  **Fatos narrados:** 24 composições arcanas e 96 veículos coletivos criados; primeiros trajetos públicos supervisionados e implantação por etapas; expansão municipal da Costura de Dados com 6 núcleos, 24 repetidores e 60 quiosques; 1.500 novos autômatos técnicos funcionais, distintos dos 3.600 existentes e de Rumo; operação setorial de energia, água e manutenção; início do funcionamento das novas estruturas cívicas sem concentração de poder.

  **Permanecem abertos:** contratação humana de saúde e educação, horários e tarifas definitivos, formação e eleição de lideranças, investigação de Miren e Astra sobre a Rede e Talis, origem do cilindro de Elyrien e a trajetória não comprovada de Caedren após sua aparição do Dia 539. Os antagonistas distantes não receberam conhecimento instantâneo.

  <text color="secondary" size="xs">Este episódio é um novo rascunho. O HEAD canônico permanece no Dia 539, Parte III, até uma escolha posterior e verificação de promoção.</text>
</box>

## Escolha o próximo passo — Parte V de V

<box gap={3}>
  <box gap={1}>
    **1 — A cidade recebe o mundo**

    Na próxima etapa, caravanas, mercadores e famílias começam a chegar por rotas verificáveis. Lucas, Kael e Lysa precisarão transformar capacidade em acolhimento real.
    <button block color="primary" variant="outline" onClick={() => GenUI.issueNewTurn("WORLDROOT — Livro VI, Capítulo 1, Parte V de V. Escolho a opção 1: A cidade recebe o mundo. Continue a partir da Parte IV D540 arquivada, consultando HEAD e matriz de personagens e registrando no GitHub.")}>Escolher opção 1</button>
  </box>
  <box gap={1}>
    **2 — O primeiro problema que nenhuma máquina resolve**

    Maelis e os cidadãos enfrentam os desafios de serviços humanos numa cidade fisicamente pronta. Lucas poderá fazer maravilhas, mas não substituir decisões das pessoas.
    <button block color="primary" variant="outline" onClick={() => GenUI.issueNewTurn("WORLDROOT — Livro VI, Capítulo 1, Parte V de V. Escolho a opção 2: O primeiro problema que nenhuma máquina resolve. Continue a partir do episódio D540, respeitando o cânone, personagens e registro GitHub.")}>Escolher opção 2</button>
  </box>
  <box gap={1}>
    **3 — As perguntas de AERÚN**

    Miren e Astra conduzem sua própria investigação do Coração de Convergência e dos arquivos ligados a Talis. Evidências antes de revelações.
    <button block color="primary" variant="outline" onClick={() => GenUI.issueNewTurn("WORLDROOT — Livro VI, Capítulo 1, Parte V de V. Escolho a opção 3: As perguntas de AERÚN. Priorize Miren, Astra e evidências sobre a Rede e Talis, sem antecipar conclusões; arquive novo episódio no GitHub.")}>Escolher opção 3</button>
  </box>
  <box border radius="lg" padding={3} gap={2}>
    <row align="center" gap={2}><icon name="sparkles"/><text weight="medium">4 — ESPECIAL: A cidade livre e as primeiras ondas do mundo</text></row>
    Combine o acolhimento público, as instituições, descobertas graduais em AERÚN, a liberdade dos amigos e os movimentos independentes de Elyrien e Tharvek, com a mesma grandiosidade, humor, romance e GÊNESE intacta.
    <button block color="primary" onClick={() => GenUI.issueNewTurn("WORLDROOT — Livro VI, Capítulo 1, Parte V de V. Escolho a opção 4 ESPECIAL: A cidade livre e as primeiras ondas do mundo. Continuar do Dia 540, Parte IV, preservando o texto integral, as decisões e todos os pontos de continuidade e realizar arquivamento verificado no GitHub antes da entrega.")}>Escolher especial 4</button>
  </box>
  <box gap={2}>
    **5 — AÇÃO LIVRE**

    <textarea rows={3} value={acaoLivre540} onChange={setAcaoLivre540} disabled={false} placeholder="Descreva o que Lucas fará, dirá ou mudará na história..."/>
    <button block disabled={!acaoLivre540.trim()} variant="outline" onClick={() => GenUI.issueNewTurn("WORLDROOT — Livro VI, Capítulo 1, Parte V de V. Escolho a opção 5, AÇÃO LIVRE: " + acaoLivre540 + " Continue com cânone verificado e novo episódio arquivado no GitHub.")}>Confirmar ação livre</button>
  </box>
</box>

<!-- WORLDROOT LIVRO-VI-C01 PARTE V / LVI-C01-PV-D541-AUTHOR-SOURCE -->

{@body const [acaoC2,setAcaoC2] = DIL.useState("");}
<box align="center" gap={1}>
  <text color="secondary" size="xs" weight="medium">CRÔNICAS DE UM NOVO MUNDO · WORLDROOT · HISTÓRIA VIVA</text>
  <title size="md" textAlign="center">A ERA DAS NOVE COROAS</title>
  <title size="xl" textAlign="center">LIVRO VI — AS COROAS PARTIDAS</title>
  <title size="lg" textAlign="center">CAPÍTULO 1 — O CRIADOR E A CIDADE DAS MIL FONTES</title>
  <title size="md" textAlign="center">PARTE V DE V · AÇÃO LIVRE ESPECIAL</title>
  <title size="xl" textAlign="center">A TORRE DO IMPOSSÍVEL</title>
  <text italic textAlign="center" color="secondary" size="sm">“Depois de abrir as portas de uma cidade para milhares de desconhecidos, o Criador precisou descobrir onde guardar aquilo que não cabia em nenhum mapa: a própria saudade.”</text>
</box>

<box border radius="lg" padding={3} gap={2}>
  <text size="xs" color="secondary" weight="medium">CALENDÁRIO DO HORIZONTE</text>
  <grid columns={2} gap={3}>
    <grid-item>
      <text color="secondary" size="xs">Dia acumulado</text>
      **541**
    </grid-item>
    <grid-item>
      <text color="secondary" size="xs">Calendário</text>
      **Ano II · Mês 06 · Dia 26**
    </grid-item>
    <grid-item>
      <text color="secondary" size="xs">Abertura</text>
      **06h52 · Casa do Jardim Branco**
    </grid-item>
    <grid-item>
      <text color="secondary" size="xs">Estado do capítulo</text>
      **Parte V de V · O grande encerramento**
    </grid-item>
  </grid>
  <text color="secondary" size="xs">Continuidade literal: Dia 540, 21h17. Transporte arcano, Costura de Dados municipal e o terceiro marco já foram narrados. A Parte IV está canônica; a torre ainda não existe no início desta parte.</text>
</box>

## I — O endereço que faltava no impossível

**DIA 541 · 06h52 — CASA DO JARDIM BRANCO, QUARTO DE LUCAS E MIREN**

A primeira coisa que Lucas encontrou naquela manhã foi um objeto de outro mundo.

Não um artefato dos Arquitetos.

Não uma relíquia de eras mortas.

Uma caneca.

De barro simples, com uma pequena imperfeição na alça, que Miren usava quando queria tomar alguma coisa quente sem pensar no fim dos continentes.

Estava na janela, onde ele a deixara na noite anterior.

Lucas a ergueu e ficou olhando para ela como se descobrisse um segredo.

**MIREN —** Se você disser que vai revolucionar o conceito de caneca, eu volto a dormir.

**LUCAS —** Eu jamais ousaria. A caneca é uma instituição que funciona.

Miren estava deitada de lado, com uma mecha de cabelo sobre o rosto. Tentou afastá-la, falhou, e Lucas se aproximou para prendê-la atrás de sua orelha.

**MIREN —** Está muito quieto.

**LUCAS —** Isso não deveria ser uma boa notícia?

**MIREN —** Normalmente é sinal de que você teve uma ideia tão absurda que ainda não encontrou uma forma de anunciá-la.

Ele colocou a caneca sobre a mesa.

**LUCAS —** Ontem fizemos a cidade conversar. Antes disso, construímos lugar para cem mil pessoas que nem conhecemos.

**MIREN —** E você está feliz com isso.

**LUCAS —** Muito. Mas quando cheguei aqui ontem à noite… percebi que tenho a Casa do Jardim Branco, tenho a Forja, as ruas, a cidade, amigos, você… e mesmo assim existe uma parte de mim que não tem endereço.

Ela se sentou.

Lucas sorriu, mas não tentou transformar a frase em piada imediatamente.

**LUCAS —** É aquele garoto da Terra, sabe? O sujeito que olhava para máquinas, filmes, aviões e coisas que não podia ter e pensava: um dia eu ainda vou fazer uma coisa impossível.

Miren permaneceu em silêncio. Não porque não tivesse resposta, mas porque compreendeu que, naquele momento, ouvir era a resposta.

**LUCAS —** Eu consigo desenhar uma cidade inteira com GÊNESE. Mas não tenho um lugar onde esse garoto possa deixar as coisas dele. Os sonhos ridículos. As lembranças. Um carrinho antigo que faz barulho. Uma televisão de tubo. Um objeto que ninguém aqui vai entender e que eu vou achar maravilhoso.

**MIREN —** Você está querendo uma oficina.

**LUCAS —** Uma oficina.

Uma pausa.

**LUCAS —** Com alguns quartos.

Outra pausa.

**LUCAS —** Talvez um observatório.

Miren estreitou os olhos.

**LUCAS —** E uma garagem.

**MIREN —** Lucas.

**LUCAS —** E uma cozinha.

**MIREN —** Lucas.

**LUCAS —** E uma torre.

Ela fechou os olhos.

**MIREN —** Lá vem.

Lucas abriu os braços com uma expressão de ofendido histórico.

**LUCAS —** NÃO É UMA TORRE QUALQUER, AMOR. É A MINHA TORRE!

*【NÓX — Recomendo evacuar o bairro. O discurso de apresentação está chegando.】*

A voz veio da armadura viva, que repousava próxima ao leito, sem perder a própria presença.

**LUCAS —** TRAIDOR!

*【SISTEMA — Estimativa de probabilidade de uma proposta modesta: desprezível.】*

**LUCAS —** VOCÊ TAMBÉM NÃO FOI CONVIDADO A OPINAR!

Miren riu tanto que precisou segurar o lençol.

Depois, quando o riso se aquietou, ela tocou o rosto dele.

**MIREN —** Você não precisa pedir permissão para ter um sonho pessoal.

Lucas piscou.

**MIREN —** Mas eu quero uma promessa.

**LUCAS —** Qualquer coisa.

**MIREN —** Não transforme a nossa Casa do Jardim Branco numa casa antiga de que ninguém precisa. Eu amo este lugar. Foi aqui que uma parte da nossa vida aconteceu.

O sorriso de Lucas mudou.

**LUCAS —** Esta casa não vai desaparecer. Nem ser desmontada. Nem virar museu sem a nossa vontade.

**MIREN —** E não decida por mim que devo morar na torre só porque você a construiu.

**LUCAS —** Você pode morar onde quiser. Pode ter um laboratório lá, pode ter um quarto, pode me mandar dormir no observatório, pode passar metade da semana aqui… Desde que continue me beijando de vez em quando, o contrato é bastante favorável.

**MIREN —** Ainda não assinei esse contrato.

Lucas caiu de joelhos junto à cama.

**LUCAS —** SENHORA MIREN, EU OFEREÇO O UNIVERSO E UMA COZINHA COM VISTA PANORÂMICA!

Ela segurou seu queixo.

**MIREN —** Ofereça primeiro o café da manhã.

O beijo que se seguiu não foi rápido.

Quando se separaram, Lucas ainda estava sorrindo daquela maneira indecente de quem conhecia a maior de suas fortunas.

Ao fundo, NÓX declarou:

*【NÓX — Registro de segurança: o Criador foi derrotado sem qualquer resistência.】*

**LUCAS —** EU ESCOLHI NÃO RESISTIR!

*【SISTEMA — Alegação não verificável.】*

E a manhã começou.

---

## II — Um lote, três amigos e a diferença entre ter poder e ter direito

**DIA 541 · 08h23 — HORIZONTE ABERTO, ALAMEDA DO MIRANTE SUL**

Lucas havia escolhido o terreno antes mesmo de conseguir descrevê-lo.

Era uma área ampla junto à borda elevada do novo distrito, afastada das rotas mais movimentadas e voltada para a cidade histórica. De um lado, o parque público descia entre espelhos d'água e árvores jovens. Do outro, uma rua de serviço encontrava o corredor de transporte criado no Dia 540.

A terra estava vazia.

Vazia, entretanto, não significava sem dono.

E era por isso que Kael e Lysa o acompanhavam.

**KAEL —** Sei perfeitamente por que nos chamou. Não.

**LUCAS —** Eu ainda não pedi nada!

**KAEL —** Exatamente. Estou economizando tempo.

**LYSA —** Kael, deixe-o falar.

**LUCAS —** Obrigado, Lysa. Nesta cidade há pelo menos uma pessoa civilizada.

**LYSA —** Depois eu também direi não se for necessário.

**LUCAS —** UMA CONSPIRAÇÃO! EM SOLO QUE EU MESMO AJUDEI A CRIAR!

Dália, convidada por representantes dos comerciantes para conhecer a proposta, chegou pelo caminho de pedra e examinou o terreno sem qualquer deferência especial.

**DÁLIA —** O que vai construir aqui?

Lucas fez um gesto majestoso.

**LUCAS —** Um monumento ao sonho humano.

**DÁLIA —** Uma casa?

**LUCAS —** Tecnicamente.

**DÁLIA —** Então por que não disse logo?

Ele abriu a boca. Fechou. Kael pareceu profundamente satisfeito.

Um responsável pelo registro de lotes trouxe a planta pública do Horizonte Aberto. A faixa escolhida não fazia parte das praças, dos parques de passagem, das escolas, dos corredores de transporte nem das reservas para serviços comuns. A vistoria do terreno e os registros de destinação, feitos antes da implantação física do bairro, não indicavam moradia deslocada ou pretensão particular anterior naquele setor.

Lucas insistiu que isso fosse conferido em voz alta.

**LUCAS —** Eu não quero que alguém descubra amanhã que perdeu o terreno porque o fundador decidiu construir uma casa enorme.

**LYSA —** Então você terá de ser tratado como qualquer adquirente. Lote individual. Registro público. Condições e valor definidos pelo procedimento municipal. Pagamento feito por seus recursos pessoais. Nenhum serviço público pagando a manutenção da sua residência.

**LUCAS —** Excelente.

**KAEL —** E a edificação não poderá bloquear as rotas aéreas ou tomar o parque.

**LUCAS —** Excelente!

**DÁLIA —** E não quero sua torre fazendo sombra sobre o mercado às dez da manhã.

**LUCAS —** Dália, você está a uma distância considerável do mercado.

**DÁLIA —** Então não será difícil provar que não vai fazer sombra.

Kael ergueu a sobrancelha, como quem observava alguém finalmente encontrar um adversário à altura.

A reunião de vizinhança aconteceu ali mesmo. Trabalhadores do corredor, duas famílias que começavam a examinar o novo distrito e representantes dos serviços olharam a planta, discutiram a posição da torre e seu acesso. Lucas moveu a proposta para preservar a vista pública do parque e manter as passagens abertas. A área privada ficou delimitada; a galeria que ele queria oferecer à cidade teria entrada própria, sem dar aos visitantes acesso à residência.

Não houve proclamação real.

Houve uma decisão de destinação do lote, registro de domínio privado mediante aquisição regular e o pagamento das obrigações correspondentes, documentados pelo órgão civil competente. A torre teria de se sujeitar às mesmas regras de proteção e acesso que qualquer construção, embora sua escala fosse inédita.

Lucas assinou.

Lysa conferiu o registro.

Kael, que não era rei nem podia outorgar propriedades por amizade, limitou-se a observar a conclusão do processo administrativo e a confirmação pública dos responsáveis.

**KAEL —** Pronto. O lote é seu. A cidade não é.

Lucas levou a mão ao coração.

**LUCAS —** Vocês conseguem tornar qualquer conquista emocionante numa experiência de humilhação burocrática.

**LYSA —** Você pediu que não existissem privilégios.

**LUCAS —** Pedi e mantenho! Mas gostaria que isso viesse acompanhado de fanfarras.

Dália bateu palmas três vezes, sem entusiasmo algum.

**DÁLIA —** Pronto. Já pode começar.

Lucas encarou-a.

E, pela primeira vez naquela manhã, ficou genuinamente sem resposta.

Um rapaz que estivera ajudando a marcar a alameda perguntou:

**RAPAZ —** A torre vai ser um palácio do governo?

O fundador abriu um sorriso.

**LUCAS —** Não. O governo já tem prédio. E pessoas suficientemente teimosas para me impedir de usar a torre como outro.

**RAPAZ —** Então é uma torre de quê?

Lucas olhou para o espaço vazio.

O vento atravessou o terreno. Ao longe, uma das novas composições arcanas passou entre árvores, levando passageiros em direção ao mercado.

**LUCAS —** De um homem que encontrou um lugar onde pode continuar sonhando.

O rapaz pareceu considerar a resposta.

**RAPAZ —** Vai ter uma porta?

Lucas arregalou os olhos.

**LUCAS —** VAI TER PORTAS TÃO BONITAS QUE VOCÊ VAI QUERER ESCREVER POESIA SOBRE ELAS!

**DÁLIA —** E fechaduras.

**LUCAS —** E fechaduras, aparentemente.

---

## III — A conversa com alguém que não era uma máquina

**DIA 541 · 09h47 — LIMITE DO LOTE PARTICULAR, HORIZONTE ABERTO**

Quando os outros se afastaram para vistoriar o acesso, Lucas ficou sozinho com NÓX.

Sozinho não era exatamente a palavra.

A armadura viva movia uma parte de suas placas de um modo que, para um desconhecido, poderia parecer mero ajuste de encaixes. Lucas sabia reconhecer a diferença entre movimento e comentário.

**LUCAS —** Já pensou em viver numa casa que tem cento e quarenta e cinco metros de altura?

*【NÓX — Não. Eu preferiria uma casa com alguém capaz de guardar os próprios equipamentos.】*

**LUCAS —** Você precisa parar de usar minhas fraquezas como material de entretenimento.

*【NÓX — Elas são abundantes. Seria desperdício.】*

Lucas riu. Depois parou.

**LUCAS —** Quero lhe fazer uma proposta séria.

*【NÓX — Isso é novo.】*

**LUCAS —** NÓX.

O tom bastou.

A armadura ficou quieta.

Lucas descreveu uma rede doméstica sem consciência própria. Sensores, mecanismos, elevadores, energia, alertas, portas, ferramentas; sistemas que executariam tarefas por funções e permissões, mesmo quando NÓX não estivesse conectado.

**LUCAS —** Mas eu queria que você pudesse se ligar a ela, se quisesse. Falar comigo em outro cômodo. Ver um projeto numa bancada. Me avisar quando eu estiver para incendiar minha própria oficina.

*【NÓX — Isso exigiria vigilância constante.】*

**LUCAS —** Exigiria uma paciência histórica.

*【NÓX — Não são a mesma coisa.】*

Lucas se sentou na borda de uma pedra.

**LUCAS —** Quero que a casa seja mais uma ferramenta para você. Não um corpo em que eu vá prendê-lo. Não quero criar uma cópia sua. Nem outra voz fingindo ser você. É você quem decide quando entra, o que pode ver e quando sai.

*【NÓX — E se eu me recusar?】*

**LUCAS —** Continuamos amigos. Você me chama de idiota como sempre e eu continuo tendo dificuldade em negar suas acusações.

Houve um silêncio.

Não o silêncio de um mecanismo esperando comando.

Era o silêncio de alguém pensando.

*【NÓX — A conexão deve ser reversível. Nenhum acesso automático aos aposentos de Miren. Nenhuma escuta escondida. O SISTEMA permanece fora da minha interface. E eu não assumirei a administração integral de sua bagunça.】*

**LUCAS —** Três das quatro condições são absolutamente razoáveis.

*【NÓX — Lucas.】*

**LUCAS —** ESTÁ BEM! A BAGUNÇA TAMBÉM!

*【SISTEMA — A separação de identidades é tecnicamente recomendável.】*

**LUCAS —** Ninguém perguntou para você!

*【SISTEMA — Precisamente.】*

Lucas se inclinou para a armadura.

**LUCAS —** Então… aceita?

*【NÓX — Aceito experimentar. Não aceito ser transformado numa residência com mau senso de humor.】*

O sorriso de Lucas cresceu lentamente.

**LUCAS —** Meu amigo, você acaba de se tornar o primeiro companheiro convidado a participar da construção da casa de um homem que não consegue organizar uma gaveta.

*【NÓX — Estou reconsiderando.】*

Lucas se levantou, abriu os braços e olhou para o terreno.

A partir daquele instante, a torre não seria apenas dele.

Seria um lugar onde alguém poderia entrar sem deixar de ser quem era.

---

## IV — A Marca do Impossível

**DIA 541 · 10h36 — HORIZONTE ABERTO, ALAMEDA DO MIRANTE SUL**

O chão começou a brilhar antes que Lucas pronunciasse qualquer palavra.

Não por uma limitação da GÊNESE.

Pela antecipação que ele escolheu imprimir à cena.

Havia pessoas observando das ruas próximas. Algumas tinham visto a cidade crescer no Dia 539, outras só haviam chegado à região nos dias seguintes e conheciam aqueles feitos por relatos de vizinhos. Para elas, tudo ainda parecia impossível de aceitar.

A criança que chamara o transporte de dragão estava entre os curiosos. Segurava a mão do pai.

**CRIANÇA —** Ele vai construir outro dragão?

**PAI —** Não sei.

**CRIANÇA —** Uma torre-dragão?

Lucas ouviu.

Virou o rosto.

**LUCAS —** NÃO ME DÊ IDEIAS, PEQUENO GÊNIO!

O pai ficou vermelho. A criança abriu um sorriso de pura felicidade.

Brannik e Dorek observavam a distância técnica dos limites do lote. Kael e Lysa já retornavam aos próprios trabalhos; não precisavam acompanhar cada milagre de Lucas. Dália havia deixado um recado exigindo que a obra não atrapalhasse o horário de entrega do pão.

Naira, no Campo Aurora, recebera apenas a informação de que haveria uma estrutura aérea com área reservada para ensaios futuros. O espaço operacional da aeronave ARGOS não seria invadido por uma nova rota sem levantamento.

Miren estava em AERÚN.

Lucas achou bom que ela estivesse trabalhando.

Queria que a primeira surpresa fosse realmente uma surpresa.

Ele se colocou no centro do terreno.

E respirou.

Não buscou uma força que lhe faltasse.

Não pediu licença a um poder superior para manifestar aquilo que já fazia parte de sua autoridade.

Sentiu, simplesmente, as possibilidades se abrirem diante da vontade.

**LUCAS —** Estou há tempo demais construindo coisas que todo mundo vai usar.

A brisa trouxe o som distante do transporte arcano.

**LUCAS —** Hoje eu vou construir uma coisa que tem a minha cara.

*【NÓX — É possível projetar uma fachada menos expressiva?】*

**LUCAS —** NÃO, PORQUE A ARQUITETURA PRECISA TER PERSONALIDADE!

*【SISTEMA — Manifestação declarativa disponível.】*

Lucas ergueu uma mão.

O gesto foi pequeno.

A resposta do mundo, não.

**LUCAS — GÊNESE.**

Primeiro, a terra se tornou cristalina.

Não vidro frágil. Não gelo. Uma trama de fundamentos arcanos e matéria estrutural brotou do solo em anéis concêntricos, descendo por três subsolos antes de alcançar a superfície. Ao redor, os caminhos já existentes foram preservados. Nenhuma residência vizinha foi tocada. O lote ganhou jardins, lagos rasos, passagens e entradas claramente separadas entre visitantes, moradores e áreas de serviço.

Então ergueu-se o primeiro pavimento.

Era um átrio descomunal, envolto em arcos brancos e estruturas de metal escuro, como se uma catedral renascentista e uma oficina da Terra tivessem passado uma noite inteira discutindo o significado de beleza.

O segundo nível cresceu sobre ele.

O terceiro.

O quarto.

A sombra da torre alongou-se pelo terreno e se afastou das passagens públicas conforme a estrutura assumia a forma que Lucas havia escolhido.

Não era uma pilha de andares.

Era uma espiral ascendente de terraços, colunas, vidro, nervuras e jardins suspensos. Havia elementos que lembravam antigas grandes cidades da Terra e outros que nenhum arquiteto terrestre teria imaginado. A fachada tinha variações de profundidade, aberturas luminosas, passarelas internas e volumes de pedra clara que pareciam flutuar sem abandonar os pilares.

O vento circulou pelas galerias abertas.

Nos níveis superiores, um salão suspenso nasceu dentro de uma coroa de cristal.

Dois elevadores panorâmicos, ainda imóveis, surgiram dentro de eixos transparentes com vista para Três Arcos.

A oeste, um disco externo de setenta metros de diâmetro se estendeu por uma estrutura própria de sustentação: a **Aerodoca do Impossível**. Não era o deck social, nem uma pista pública, nem um pouso já realizado. Seus balizamentos permaneceram em estado de ensaio, à espera de verificação futura com Naira e a equipe de ARGOS.

Mais abaixo, um deck paisagístico aberto de quinhentos e cinquenta metros quadrados abraçou a fachada, separado da área de operação aeronáutica.

Veio a grande oficina.

Vieram laboratórios de experimentação, uma biblioteca, uma arena de treinamento, salas de projeto, o cinema, as cozinhas, os quartos e espaços que ainda não sabiam quais invenções um dia receberiam.

No alto, a estrutura alcançou sua medida final.

**Cento e quarenta e cinco metros.**

**Vinte e dois pavimentos.**

**Três subsolos.**

**Trinta e um mil metros quadrados internos.**

O ápice ganhou a própria assinatura do fundador: um traço ascendente rompendo um halo aberto, com uma centelha pairando acima.

A **Marca do Impossível**.

Não era o brasão da Cidade Livre.

Não havia coroa, trono, estandarte oficial ou pretensão de governar.

Era um símbolo pessoal.

Um lembrete de que um homem que um dia olhara para o céu da Terra sem alcançar certas estrelas agora podia construir um lugar de onde fosse possível contemplá-las.

Quando a luz da GÊNESE diminuiu, a torre permaneceu.

Real.

A terra suportava seu peso. Os sistemas tinham redundância física. Havia acesso, saídas, oficinas, instalações, água, energia e mecanismos de segurança. Os espaços externos se distinguiam dos trinta e um mil metros quadrados internos, sem duplicar a contagem.

E, por um instante que pareceu maior do que todos os três dias anteriores, ninguém falou.

Uma senhora caiu de joelhos.

Um rapaz recuou, assustado.

Um mercador que chegara havia pouco à praça levou as mãos ao peito e perguntou a um vizinho se estavam diante de alguma espécie de deus.

Outros simplesmente choraram.

Lucas viu aquilo.

Sua expressão mudou.

Ele caminhou até a senhora ajoelhada e estendeu a mão.

**LUCAS —** Ei… não precisa.

Ela o encarou com os olhos úmidos.

**SENHORA —** Eu vi uma montanha nascer.

Lucas olhou para a torre.

**LUCAS —** É uma casa. Uma casa muito, muito exagerada. Mas uma casa.

**SENHORA —** Como se deve falar com alguém que faz isso?

Ele pensou.

Depois apontou para a própria roupa.

**LUCAS —** Pode começar perguntando se eu já tomei café. É uma questão importantíssima e sou perigosamente sensível à resposta.

O rapaz assustado riu sem querer.

O mercador ainda parecia incapaz de respirar direito.

Lucas não ordenou que se ajoelhassem nem lhes exigiu que compreendessem o impossível imediatamente. Abriu os portões externos da galeria pública e deixou que as pessoas escolhessem se queriam olhar de perto.

A criança puxou a roupa do pai.

**CRIANÇA —** Pai…

**PAI —** Sim?

**CRIANÇA —** Eu ainda preferia o dragão.

Lucas colocou as mãos na cabeça.

**LUCAS —** EU CRIEI UMA TORRE DE CENTO E QUARENTA E CINCO METROS E CONTINUO PERDENDO PARA UM DRAGÃO IMAGINÁRIO!

Brannik desabou numa gargalhada.

Dorek tentou manter a seriedade.

Falhou.

E Três Arcos ouviu o fundador rir tão alto que a própria construção pareceu ter sido erguida para abrigar aquela risada.

---

## V — O lugar onde um Fusca podia ser uma relíquia

**DIA 541 · 11h48 — TORRE DO CRIADOR, B01 · GARAGEM DO IMPROVÁVEL**

O primeiro problema da torre recém-criada foi que ninguém sabia onde colocar o entusiasmo de Brannik.

O segundo foi que Brannik entrara na garagem.

**BRANNIK —** LUCAS!

**LUCAS —** Brannik.

**BRANNIK —** O QUE É ISSO?!

**LUCAS —** Uma garagem.

**BRANNIK —** EU SEI O QUE É UMA GARAGEM!

**DOREK —** Existem indícios contrários.

Brannik ignorou o comentário e ficou de pé diante do primeiro veículo.

Era baixo, arredondado, de pintura azul profunda e faróis que pareciam olhos curiosos. Nada nele lembrava uma carruagem de Três Arcos. Não havia cavalo, leme, círculo ritual de tração ou reservatório visível de mana.

Lucas passou a mão pela superfície com um cuidado inesperadamente terno.

**LUCAS —** Fusca.

**BRANNIK —** Isso é o nome de um inseto?

**LUCAS —** Em alguns contextos, uma interpretação válida.

**DOREK —** Ele parece ter sido feito para não machucar pedestres com arestas.

**LUCAS —** Não confunda a aparência simpática com a capacidade de causar vergonha ao dono quando resolve não pegar de manhã.

Brannik abriu a porta e ficou observando o painel.

**BRANNIK —** E onde fica o mecanismo arcano?

**LUCAS —** Não tem. É um carro terrestre de combustão, recriado por GÊNESE a partir do modelo que conheci. Está funcionando, mas você não vai ligá-lo num depósito fechado sem ventilação apropriada.

**DOREK —** Finalmente uma frase responsável.

**LUCAS —** MARQUE NO CALENDÁRIO!

A garagem era imensa, mas não parecia depósito de troféus. Havia espaço para trabalhar nos veículos, iluminá-los, mantê-los e compreender suas formas. Os automóveis não estavam ali porque Lucas os possuíra na Terra. Eram reconstruções materiais de modelos de que se lembrava, máquinas e referências culturais do mundo onde nascera.

Ao lado do Fusca estavam um **Opala**, um **Mustang fastback**, um **DeLorean DMC-12** de linhas metálicas quase irreais e uma **Kombi** cuja aparência inspirou imediatamente novas teorias a Brannik.

Havia motocicletas também: uma CB750, uma CG clássica, uma Vespa e uma Ninja, dispostas com espaço entre elas e equipamentos próprios de manutenção.

Brannik parou diante do Mustang.

Passou os olhos pelo capô.

**BRANNIK —** Este parece um animal que pretende devorar outro animal.

**LUCAS —** Essa foi uma avaliação surpreendentemente boa do design.

Dorek agachou-se diante de uma das rodas.

**DOREK —** Suspensão. Direção. Frenagem independente. São máquinas reais, então?

**LUCAS —** Reais. Podem ser desmontadas, ligadas, estudadas, consertadas. Nada de ilusão que desapareça quando alguém abrir a porta. Não precisamos delas para fingir que existiram aqui antes de hoje, e ainda teremos de testar qualquer circulação fora do espaço particular.

Brannik encarava agora o DeLorean.

**BRANNIK —** ESTE VIAJA PELO TEMPO?

Lucas virou-se muito devagar.

**LUCAS —** Não.

**BRANNIK —** MAS PARECE QUE DEVERIA!

**LUCAS —** ESSA É EXATAMENTE A TRAGÉDIA DA BELEZA INDUSTRIAL!

Dorek esfregou o rosto com a mão.

**DOREK —** Vou precisar de férias.

A porta lateral se abriu. Rumo apareceu, trazendo uma bolsa pequena, como quem havia aceitado visitar uma oficina e não um monumento.

**RUMO —** Posso olhar?

Lucas se iluminou.

**LUCAS —** Pode olhar. Pode perguntar. Pode dizer que fui um idiota. Só não pode vender meus carros para a Dália.

**RUMO —** Eu não faria isso.

Uma pausa.

**RUMO —** Sem saber o preço.

O silêncio durou um segundo.

Brannik começou a rir primeiro.

Lucas colocou a mão sobre o peito.

**LUCAS —** VOCÊS ESTÃO ME DESTRUINDO NO DIA MAIS FELIZ DA MINHA VIDA!

Rumo caminhou entre as máquinas. Diante da Kombi, ficou parado por mais tempo.

**RUMO —** Essa parece feita para levar muitas pessoas juntas.

**LUCAS —** Era um pouco essa a ideia. Nem tudo o que minha terra inventou era grandioso. Algumas das melhores coisas eram apenas maneiras de viajar com quem a gente amava.

Rumo tocou o vidro, sem abrir a porta.

**RUMO —** Entendo.

Lucas não perguntou se o amigo queria trabalhar ali. Não lhe ofereceu um emprego compulsório. Em vez disso, mostrou uma oficina reservada para visitantes autorizados e criadores que precisassem de um espaço para experimentar.

**LUCAS —** Se um dia quiser construir algo, pode usar uma bancada. Se não quiser, continua vindo só para me insultar.

**RUMO —** Não preciso de bancada para isso.

Até Dorek riu.

E Lucas, pela primeira vez, sentiu que aquela garagem guardava mais do que objetos: podia oferecer conversas que talvez nunca tivessem existido na Terra, entre amigos que ele jamais teria conhecido lá.

---

## VI — O museu onde ninguém podia roubar uma lembrança

**DIA 541 · 12h39 — TORRE DO CRIADOR, GALERIA PÚBLICA**

A entrada da galeria ficava separada da residência.

Pessoas que chegavam da praça podiam atravessar um pátio coberto e encontrar ali exposições, registros e modelos de invenções, sem subir aos aposentos ou alcançar os laboratórios fechados.

Lucas caminhou pelo átrio na companhia de Dália e de um pequeno grupo de visitantes. Um artesão observava as colunas com desconfiança. Duas crianças acompanhavam a mãe. Um viajante de passagem, que havia presenciado a criação da torre da rua, mantinha-se discretamente afastado.

No centro do espaço, a primeira inscrição dizia:

**O CAMINHO COMPARTILHADO.**

Logo abaixo:

**NENHUM FICA PARA TRÁS.**

Dália leu as palavras.

**DÁLIA —** Isso eu gosto.

**LUCAS —** A parte em que a cidade não deixa ninguém para trás?

**DÁLIA —** A parte em que escreveu sem cobrar ingresso para ler.

Lucas abriu os braços.

**LUCAS —** Uma mulher de princípios inabaláveis.

A galeria tinha oito núcleos de memória. Não eram salões dedicados apenas à glória do fundador. Havia espaço para a história de Três Arcos antes de sua chegada, para os pactos e decisões dos cidadãos, para a Legião e seus feitos documentados, para os amigos que escolhessem compartilhar memórias, para a Forja, para AERÚN em sua parte pública, para o desenvolvimento da Cidade Livre e para as futuras descobertas que pudessem ser verificadas.

Uma reconstrução tridimensional mostrou como parte da Grande Avenida havia sido antes das reformas. A imagem tinha marcas discretas identificando-a como **reconstituição baseada em relatos e levantamentos**, não fotografia.

A criança mais nova levantou a mão.

**CRIANÇA —** Então isto aconteceu exatamente assim?

Lucas se ajoelhou.

**LUCAS —** Sabemos como eram algumas partes. Outras foram desenhadas com a ajuda de quem se lembrava. Quando não sabemos, a galeria diz que não sabemos.

**CRIANÇA —** Por quê?

**LUCAS —** Porque uma mentira bonita continua sendo mentira. E porque as histórias reais são extraordinárias o suficiente.

O artesão aproximou-se de um modelo da primeira ponte construída na cidade. Uma faixa indicava a fonte do desenho e o testemunho de quem acompanhara a obra. Ele fez uma pergunta sobre a inclinação de uma antiga rampa. O arquivo não tinha a medida.

Lucas não a inventou.

Pediu ao curador que acrescentasse a indicação: **medida não preservada**.

O artesão assentiu.

**ARTESÃO —** Assim posso trazer meu caderno amanhã. Eu fazia reparos naquela época.

**LUCAS —** Então a galeria vai melhorar por sua causa.

O homem pareceu mais surpreso com aquilo do que com a torre.

Num outro espaço, um painel mostrava a Forja Aurora em miniatura. Brannik surgiu no enquadramento e exigiu que sua versão tridimensional fosse mais alta.

**BRANNIK —** MINHA POSTURA ERA MAIS HEROICA!

**DOREK —** Naquele dia você estava deitado no chão tentando descobrir onde uma mola tinha ido parar.

**BRANNIK —** ERA UM PROCEDIMENTO HEROICO!

Lucas examinou a reconstituição.

**LUCAS —** Vamos deixar as duas versões: a que Brannik conta e a que Dorek confirma.

**DOREK —** Pela primeira vez, a História terá um bom sistema de controle de qualidade.

Uma das crianças apontou para um salão ainda vazio.

**CRIANÇA —** O que vai aqui?

Lucas observou o espaço. Havia pedestal, iluminação e uma placa sem nome.

**LUCAS —** Coisas que ainda não sabemos que vão acontecer.

**CRIANÇA —** E se for uma coisa triste?

A pergunta o atingiu de maneira estranhamente profunda.

Ele olhou a inscrição sobre o salão.

**LUCAS —** Então vamos contar direito. Sem fingir que tudo foi fácil, e sem esquecer quem ajudou a passar por ela.

Dália, que raramente perdia tempo com solenidades, tocou-lhe de leve o braço.

**DÁLIA —** Você está ficando sentimental.

**LUCAS —** É a idade.

**DÁLIA —** Há três minutos estava gritando porque um carro parecia um cavalo raivoso.

**LUCAS —** São facetas de uma personalidade complexa.

O viajante que observava de longe aproximou-se do modelo da torre. Seus olhos subiram até a marca pessoal de Lucas, gravada acima da porta.

**VIAJANTE —** Não é o símbolo da cidade?

**LUCAS —** Não. É meu.

**VIAJANTE —** Então a cidade não pertence ao homem que a ergueu?

Lucas respondeu sem teatralidade.

**LUCAS —** Não pertence. As pessoas daqui têm suas casas, seus direitos, suas escolhas. Eu tenho esta casa. É uma diferença importante.

O homem ficou quieto.

Não se apresentou como espião nem revelou fidelidade alguma. Era alguém que havia chegado pelas rotas existentes e agora tinha uma história que poderia levar a outros lugares. Talvez escolhesse contar. Talvez não. Se contasse, a notícia viajaria com ele e estaria sujeita à distância, à dúvida e às interpretações de quem a ouvisse.

Lucas não sabia o que aquele homem faria.

E não tinha motivo para saber.

---

## VII — A Terra cabia numa sala. A saudade, não.

**DIA 541 · 14h08 — TORRE DO CRIADOR, P14 · SALA DA TERRA**

Quando as portas do elevador panorâmico se abriram, Lucas descobriu que havia levado Rumo, Brannik e Dorek para o lugar errado.

Ou, talvez, para o lugar mais certo de todos.

O recinto era amplo, mas não procurava parecer um templo.

Havia uma televisão de tubo sobre um móvel baixo. Uma poltrona confortável. Livros que Lucas recriara como edições de referência, sem inventar dedicatórias que nunca recebera. Uma máquina de escrever. Um telefone de disco. Um rádio portátil. Um toca-discos, fitas cassete, um aparelho de música pessoal antigo, mapas reconstruídos da memória e uma pequena bancada de computador.

Num canto ficava um console de videogame de oito bits, ligado a outra televisão. Perto dele, um aparelho portátil de jogos e uma estante com caixas cujos desenhos eram recriações de lembranças incompletas — quando não recordava uma imagem, Lucas deixara a capa simples em vez de fingir que a conhecia.

Brannik entrou.

Observou.

**BRANNIK —** O que é esta caixa?

Ele apontou para a televisão.

**LUCAS —** Uma janela para imagens que não estão acontecendo do outro lado do vidro.

**BRANNIK —** Então… magia?

**LUCAS —** Na minha terra era tecnologia.

**DOREK —** Você chama tudo de tecnologia quando quer parecer superior.

**LUCAS —** Dorek, por favor. Respeite o homem que acaba de criar a maior coleção de máquinas antigas de um mundo que vocês não conhecem.

Rumo pegou o telefone de disco.

**RUMO —** E isto fala com alguém?

Lucas hesitou.

**LUCAS —** Falava. Precisava estar ligado a uma rede e alguém precisava atender do outro lado.

Rumo examinou o disco.

**RUMO —** Podemos chamar alguém da sua terra?

A pergunta foi feita sem malícia.

Por isso doeu tanto.

Lucas olhou o aparelho por um instante mais longo do que esperava.

**LUCAS —** Não. Não com isto.

O silêncio que surgiu não era desconfortável. Era apenas honesto.

Brannik, que costumava preencher qualquer pausa com um estrondo, ficou quieto. Dorek baixou o olhar para um aparelho desmontado sobre a bancada. Rumo devolveu o telefone ao lugar.

**RUMO —** Desculpe.

Lucas balançou a cabeça.

**LUCAS —** Não precisa. É uma boa pergunta.

Ele passou os dedos pelo disco.

**LUCAS —** Eu lembro do som de certas máquinas. De filmes. De estradas. Da sensação de ligar um aparelho e descobrir que podia entrar num mundo inventado por outras pessoas. Lembro de coisas que me faziam querer construir algo extraordinário.

**BRANNIK —** E não pode voltar?

Lucas não fingiu conhecer uma resposta definitiva.

**LUCAS —** Não sei como fazer isso. E não vou dizer que sei só porque posso criar coisas impossíveis.

A porta se abriu novamente.

Miren estava ali.

Trazia uma pequena pasta de registros de AERÚN e a expressão cansada de quem passara horas tentando obter respostas de instrumentos pouco cooperativos.

Ela viu o rosto do marido.

Não perguntou primeiro pelas máquinas.

**MIREN —** Lucas?

Ele sorriu.

**LUCAS —** Bem-vinda à seção do museu onde o fundador fica sentimental por causa de objetos que não funcionam com cristais de mana.

Miren se aproximou, olhou os rostos dos amigos e compreendeu sem que ninguém explicasse muito.

**MIREN —** Gostariam de conhecer a oficina? Acho que Brannik encontrará coisas que podem ser desmontadas com autorização.

**BRANNIK —** COM AUTORIZAÇÃO?!

**DOREK —** Excelente sugestão.

Os dois saíram discutindo. Rumo ficou um instante a mais.

**RUMO —** Gosto desta sala.

Lucas assentiu.

**RUMO —** Não porque as coisas sejam antigas. Porque você se importa com elas.

Então saiu também, sem levar nada.

Miren se sentou ao lado do marido diante da televisão apagada.

**MIREN —** Isto é uma parte de quem você era.

**LUCAS —** E de quem ainda sou.

Ela tocou o telefone.

**MIREN —** Queria ter visto sua Terra.

**LUCAS —** Eu queria ter mostrado. Queria que você experimentasse uma viagem de carro numa estrada interminável, comesse algo completamente absurdo numa lanchonete e discutisse comigo sobre o volume da música.

**MIREN —** Discutiria sobre o volume?

**LUCAS —** Com paixão.

Ela sorriu.

**MIREN —** Então algumas coisas não mudariam.

Lucas levantou-se e ligou o console antigo. Uma imagem simples apareceu na tela: pequenas formas coloridas movendo-se num mundo quadrado.

Ele entregou a Miren um controle.

**LUCAS —** Está preparada para conhecer uma das maiores obras da civilização terrestre?

**MIREN —** Isto é um instrumento científico?

**LUCAS —** Em certo sentido. Testa caráter, reflexos e a capacidade de aceitar derrotas.

Ela apertou um botão.

A pequena figura na tela saltou.

Miren observou.

Apertou outro.

A figura caiu num buraco.

Lucas levou as mãos ao rosto.

**LUCAS —** AH! O DRAMA! A TRAGÉDIA! A INJUSTIÇA!

**MIREN —** Lucas.

**LUCAS —** VOCÊ CAIU NO PRIMEIRO OBSTÁCULO!

Ela olhou para a tela.

Depois olhou para ele.

**MIREN —** Eu posso tentar outra vez?

**LUCAS —** Claro.

Miren tentou.

Desta vez passou do primeiro obstáculo.

Do segundo.

Do terceiro.

Lucas estreitou os olhos.

Ela avançou mais um pouco.

**LUCAS —** Não. Isso não pode estar acontecendo.

Miren estava sorrindo.

**MIREN —** Você disse que era um teste de reflexos.

**LUCAS —** E DOS LIMITES DA HUMILHAÇÃO HUMANA!

Quando a personagem dela terminou a pequena fase, Lucas se jogou no sofá como um general derrotado.

**LUCAS —** Eu trouxe o legado de um mundo inteiro para cá apenas para sofrer dentro da minha própria casa.

Miren riu e se acomodou ao lado dele.

A alegria diminuiu devagar, deixando algo mais suave.

Ela encostou a testa na dele.

**MIREN —** Você não precisa escolher entre guardar a saudade e amar o que encontrou aqui.

Lucas fechou os olhos.

**LUCAS —** Eu sei. Mas às vezes é bom ouvir isso de você.

Ela o beijou.

Por um instante, o homem que podia erguer cento e quarenta e cinco metros de pedra e cristal não precisava provar nada.

Precisava apenas daquele abraço.

---

## VIII — O companheiro que não cabia numa parede

**DIA 541 · 16h03 — TORRE DO CRIADOR, OFICINA DE CONTROLE E SALA DE INSTRUMENTAÇÃO**

A Rede Doméstica do Criador estava pronta.

E não possuía uma personalidade.

Era exatamente como deveria ser.

Os controladores dos elevadores recebiam sinais de portas e cabines. Os sensores de fumaça e temperatura transmitiam dados de ambientes definidos. Os sistemas de emergência funcionavam sem conexão remota. A iluminação obedecia a comandos locais, e as áreas privadas tinham circuitos de acesso separados.

O conjunto não podia ler pensamentos.

Não sabia o que acontecia fora do alcance de seus instrumentos.

E não tomava decisões políticas em nome de ninguém.

Lucas caminhou até uma bancada onde pequenos cristais oscilavam como estrelas dentro de seus suportes.

**LUCAS —** NÓX. O convite continua de pé. Sem obrigação.

*【NÓX — Lembro. Eu estava presente quando você fez a proposta.】*

**LUCAS —** Preciso que você pare de usar fatos contra mim.

A armadura viva, ainda sua companheira e não parte da edificação, aproximou-se do encaixe de interface. Lucas tocou o aro arcano com GÊNESE e deixou surgir uma ligação de ida e volta, verificável e reversível, com um comando físico de desligamento no alcance de NÓX.

**LUCAS —** Se quiser experimentar, basta aceitar a conexão. Os sensores da sala e a projeção lumínica estarão disponíveis. Os quartos privados ficam fora até autorização específica. Se disser não, a casa continua operando. Se quiser sair, sai.

*【NÓX — Aceito esta experiência.】*

A ligação se acendeu.

Um ponto de luz apareceu sobre a bancada.

Depois outro.

Uma figura de contornos discretos surgiu na parede: não uma criatura nova, não uma consciência duplicada. Era somente uma forma luminosa por onde a mesma voz de NÓX podia falar.

*【NÓX — Teste de comunicação. Lucas, sua bancada está desorganizada.】*

Lucas abriu os braços.

**LUCAS —** É UM MILAGRE! MEU AMIGO AGORA CONSEGUE ME INSULTAR EM TRÊS CÔMODOS AO MESMO TEMPO!

*【NÓX — Não estou em três lugares. Você instalou três emissores de voz. Há uma diferença.】*

*【SISTEMA — Precisão conceitual mantida.】*

**LUCAS —** A DIFERENÇA É QUE NINGUÉM MAIS ME RESPEITA!

Dorek testou o interruptor físico.

A projeção se apagou.

NÓX continuou ali, plenamente desperto, na armadura.

**DOREK —** A rede desligou. Ele não.

**LUCAS —** Exato.

*【NÓX — Recomendo repetir o teste até o Criador compreender isso também.】*

O link foi reativado apenas depois que NÓX concordou novamente.

Então Lucas convocou GÊNESE.

Desta vez, não houve uma torre inteira emergindo do solo. Noventa e seis autômatos físicos especializados nasceram em seus espaços de manutenção: mensageiros de recepção, unidades de limpeza, reparadores, manipuladores de oficina, auxiliares de logística, arquivistas, jardineiros, apoios de saúde não clínicos, sentinelas de evacuação e guias de aerodoca.

Não possuíam vontade própria nem vida consciente.

Não eram parte dos três mil e seiscentos autômatos antigos da Malha Aurora, nem dos mil e quinhentos novos criados no Dia 540. Eram unidades privadas, destinadas à manutenção da propriedade e aos serviços autorizados da galeria, com mecanismos de parada e supervisão humana onde necessário.

**LUCAS —** Tudo pronto!

Uma pequena unidade de limpeza aproximou-se carregando um balde.

Brannik examinou-a.

**BRANNIK —** QUE COISA ADORÁVEL!

A unidade fez uma curva perfeita, desviou de uma ferramenta e depositou o balde aos pés de Lucas.

Dentro havia…

Uma única meia.

Lucas encarou a meia.

Depois o balde.

Depois a máquina.

**LUCAS —** Por quê?

Dorek consultou um comando local.

**DOREK —** Você marcou “recolher objeto perdido na bancada”. A meia estava na bancada.

**LUCAS —** MAS POR QUE HAVIA UMA MEIA NA MINHA BANCADA?!

*【NÓX — Essa é precisamente a pergunta que faço há muito tempo.】*

Miren, que observava da porta, começou a rir.

**MIREN —** Essa torre vai exigir mais trabalho do que você imagina.

**LUCAS —** AMOR, EU CRIEI NOVENTA E SEIS AUTÔMATOS!

**MIREN —** E o primeiro encontrou sua meia.

*【NÓX — Um êxito operacional extraordinário.】*

Lucas pegou a meia como se fosse um estandarte capturado na batalha.

**LUCAS —** HOJE A HUMANIDADE ATINGIU O AUGE DA TECNOLOGIA DOMÉSTICA!

Miren o abraçou pela cintura.

NÓX, conectado por escolha própria, manteve uma luz suave no corredor, mas não abriu sensores nem emissores nas áreas reservadas do casal.

O companheiro estava participando da casa.

Não havia se tornado a casa.

---

## IX — O céu ainda precisava de um piloto

**DIA 541 · 17h29 — SALÃO SUSPENSO, DECK DO HORIZONTE E VISTA DA AERODOCA**

Os dois elevadores panorâmicos subiram juntos.

A cidade recuou sob os pés dos passageiros.

Três Arcos antiga apareceu em primeiro plano, com suas praças e as linhas luminosas do transporte. Mais além, o Horizonte Aberto estendia suas avenidas em direção a parques, escolas e moradias ainda aguardando futuros habitantes.

O elevador não possuía uma voz artificial que fingisse ser NÓX.

Mas, como NÓX aceitara acompanhar aquela viagem, sua voz surgiu pelo emissor autorizado.

*【NÓX — À esquerda, uma cidade inteira. À direita, o ego do proprietário refletido no vidro.】*

Lucas levou as mãos ao peito.

**LUCAS —** QUEM PROJETOU ESSA EXPERIÊNCIA TURÍSTICA?!

**DOREK —** Você.

**LUCAS —** MALDITO GÊNIO!

O salão suspenso se abriu diante deles como uma grande sala de convivência acima do mundo. Mesas largas, madeira aquecida pela luz, sofás, esculturas pequenas e uma cozinha aberta se uniam sob uma cobertura de cristal curvo. Acima, o mezanino oferecia mesas de desenho e um mirante para projetos. O deck externo, amplo e protegido, possuía jardins e lugares onde se podia ver o horizonte sem ficar dentro de uma cabine.

Miren saiu primeiro, parou junto à porta e contemplou o fim de tarde.

**MIREN —** …Lucas.

A palavra foi pequena.

O mundo diante dela, não.

Ele se aproximou, quase tímido.

**LUCAS —** Gostou?

Ela olhou as nuvens coloridas.

Os telhados antigos.

A nova linha de transporte atravessando uma ponte.

**MIREN —** É lindo.

Lucas abriu um sorriso lento.

**MIREN —** E você continua completamente exagerado.

**LUCAS —** São características inseparáveis.

Na lateral oeste, a Aerodoca do Impossível avançava sobre uma estrutura de sustentação própria. O círculo de setenta metros parecia uma lua de metal claro suspensa sobre o vazio, com uma faixa exterior de segurança separando a área de aproximação do seu centro.

O deck social permanecia isolado da zona de voo.

A imagem de Naira apareceu num terminal de comunicação regional autorizado.

**NAIRA —** Já vi os desenhos. Não confunda a existência da plataforma com a autorização para pousar.

**LUCAS —** Eu nem tinha aberto a boca.

**NAIRA —** É por isso que falo primeiro.

Dorek aproximou um conjunto de medições. Havia verificações estruturais preliminares no próprio projeto, mas nenhum ensaio de aproximação de ARGOS, nenhuma validação de rajadas junto à torre e nenhuma operação real de pouso.

**NAIRA —** ARGOS continua no Campo Aurora. Antes de trazê-lo precisamos conferir trajetória, cargas, afastamento de pessoas, resposta a falha e comportamento da aeronave com o fluxo de ar do edifício. Sem atalhos.

**LUCAS —** Certíssimo. Quando estivermos prontos, faremos o teste. E você vai me deixar ficar na janela fazendo comentários ofensivos à física.

**NAIRA —** Você vai ficar onde eu disser que é seguro.

**LUCAS —** A DITADURA DOS PROFISSIONAIS COMPETENTES CONTINUA!

Naira desligou a comunicação com um sorriso discreto.

Num painel de projeto, Lucas mostrou algo menor.

Era uma silhueta compacta de aeronave pessoal, original, com linhas próprias e um espaço reservado para testes futuros.

**LUCAS —** Asa Livre.

Brannik arregalou os olhos.

**BRANNIK —** JÁ PODEMOS CONSTRUIR?!

**LUCAS —** Ainda não. Quero trabalhar no desenho. Não é um ARGOS pequeno e nem cópia de nave de outro mundo. Vai ser uma coisa nossa. Diferente.

Dorek pareceu aliviado.

**DOREK —** Pela primeira vez, um objeto não existe imediatamente depois de você lhe dar nome.

Lucas apontou para ele.

**LUCAS —** Não provoque o homem que pode mudar essa situação.

Aqueles projetos permaneceram projetos.

A torre, entretanto, estava ali.

As máquinas do B01 estavam ali.

A rede doméstica e os autômatos privados estavam ali.

NÓX podia conversar com seu amigo por meio de uma ligação que escolhera aceitar — e podia encerrá-la.

E o céu, diante do salão, não era mais uma coisa distante que Lucas precisava conquistar antes de se permitir ficar em casa.

---

## X — A montanha não sabia o nome de Lucas

**DIA 541 · 18h11 — TERRAS ANÃS, PASSAGEM DE PEDRA ENTRE AS MONTANHAS**

O som do martelo ecoou três vezes.

Depois parou.

Tharvek não gostava quando um martelo parava de trabalhar antes da hora.

A passagem montanhosa era antiga. Suas pedras haviam sido erguidas e reparadas por gerações de trabalhadores que sabiam ler o relevo antes de tocar nele. Nos dias anteriores, homens armados haviam tentado impor uma passagem pela força. O confronto deixara riscos nas paredes, uma ponte provisória danificada e mais perguntas do que respostas.

Naquela tarde, Tharvek acompanhava os reparos com dois guardas e os artesãos que conheciam o lugar.

Não estava em Três Arcos.

Não sabia da torre recém-criada.

Não conhecia Lucas.

Seu problema, naquele instante, era concreto: parte do caminho que deveria sustentar carroças pequenas tinha cedido, deixando uma plataforma de pedra inclinada sobre uma garganta.

**PEDREIRO —** Se arrancarmos a peça de apoio, o restante pode vir junto.

Tharvek se agachou.

Passou a mão pelo veio do rochedo.

**THARVEK —** Não arranquem.

O homem ao lado dele ergueu os olhos.

**PEDREIRO —** Mas precisamos abrir o acesso.

**THARVEK —** Primeiro precisamos impedir que as pedras caiam sobre quem vai trabalhar embaixo. Uma estrada que mata os próprios construtores não merece ser chamada de estrada.

Ele examinou o encaixe.

Havia marcas de desgaste antigas e uma fissura nova. A fissura podia ter sido causada pela sobrecarga do confronto, mas uma de suas bordas apresentava cortes estreitos demais para serem simplesmente rachaduras naturais.

**THARVEK —** Traga uma lanterna para cá.

Um dos guardas obedeceu.

A luz revelou três incisões paralelas feitas numa das peças de sustentação.

Tharvek ficou imóvel.

**GUARDA —** Uma marca de pedreiro?

**THARVEK —** Talvez. Quero saber quem trabalhou nesta peça e quando.

**PEDREIRO —** Esta pedra foi posta há muito tempo.

**THARVEK —** Então procure os registros. E não espalhe uma acusação antes de termos uma prova.

O guarda franziu a testa. Conhecia a cólera do príncipe e parecia esperar uma ordem para perseguir suspeitos montanha abaixo.

Mas Tharvek não dera essa ordem.

Ergueu-se, apontou a área que precisava de escoramento e se ofereceu para sustentar pessoalmente uma das vigas enquanto os outros ajustavam o apoio.

**PEDREIRO —** Alteza, sua mão…

Havia uma abrasão recente sobre os nós dos dedos. Nada que comprovasse ferimento incapacitante ou exigisse uma cura inventada.

**THARVEK —** MINHA MÃO AINDA SERVE PARA SEGURAR MADEIRA!

Ele ergueu a viga como se ela houvesse cometido uma ofensa pessoal.

Os trabalhadores começaram a rir, mas ninguém relaxou o cuidado.

Do outro lado da garganta, um pequeno desprendimento fez cair pedras no vazio.

O estrondo percorreu a montanha.

Tharvek acompanhou o eco com os olhos.

Não havia cerco decretado.

Não havia inimigo identificado.

Havia uma passagem ferida, sinais que precisavam ser examinados e uma região que não podia depender de bravatas para permanecer ligada ao restante de seu povo.

O príncipe apertou a viga.

**THARVEK —** QUEM QUISER DESTRUIR UMA ESTRADA ANÃ VAI TER DE APRENDER O QUANTO CUSTA RECONSTRUÍ-LA!

O pedreiro ao lado dele respondeu sem erguer os olhos do trabalho:

**PEDREIRO —** Se puder fazer menos barulho, talvez descubramos antes de escurecer.

Tharvek encarou-o.

Depois soltou uma gargalhada que competiu com o eco das montanhas.

A reparação continuou.

O mistério também.

---

## XI — A pista que não quis dizer seu nome

**DIA 541 · 19h06 — FLORESTA DISTANTE, CASA DE PESQUISA DE ELYRIEN**

Elyrien colocou o cilindro sobre uma mesa de madeira escura.

Aquele era o terceiro ensaio do dia.

O primeiro comparara as ligas do metal com amostras locais. O segundo procurara resíduos superficiais de materiais de transporte. Nenhum autorizava atribuir a peça a um império, uma ordem antiga ou uma facção específica.

Neris aproximou uma lâmpada de luz branca.

**NERIS —** Se não o abrirmos, podemos passar semanas imaginando o que há dentro.

**ELYRIEN —** E se o abrirmos sem compreender a trava, talvez não sobre nada para examinar.

**NERIS —** Você parece gostar de respostas que começam com “não”.

**ELYRIEN —** É uma das maneiras mais úteis de impedir que uma hipótese vire superstição.

Neris suspirou. Depois aproximou uma das lentes preparadas por ela.

A guardiã inclinou o cilindro.

Uma sombra fina atravessou o metal.

**NERIS —** Pare.

Elyrien imobilizou a mão.

**NERIS —** Volte um pouco.

A luz atravessou o mesmo ângulo. Na borda da peça, sob uma camada de desgaste, surgiram três marcas muito pequenas.

Não eram as linhas grandes e visíveis da parte externa.

Eram entalhes quase ocultos na junção.

Neris desenhou-os numa folha.

**NERIS —** Não consigo identificar uma língua.

**ELYRIEN —** Talvez nem sejam letras.

**NERIS —** Podem indicar uma ordem de montagem.

**ELYRIEN —** Podem.

Ela aproximou a lente de outra peça da bancada. O formato dos cortes não correspondia aos padrões de ferramentas locais catalogados naquele recinto. Isso não significava, por si só, procedência de outro continente. Significava somente que a comunidade não possuía uma correspondência registrada.

O prisioneiro permaneceu guardado longe da sala. Recebera alimento, água e tratamento compatível com sua condição; sua identidade continuava desconhecida. O segundo agressor havia escapado. Nenhum dos dois se transformara magicamente numa testemunha confiável.

**NERIS —** Vamos perguntar a ele?

**ELYRIEN —** Vamos perguntar. Mas não vamos aceitar uma resposta só porque combina com a nossa vontade de descobrir algo.

Neris guardou o desenho.

Do lado de fora, o canto de alguns pássaros diminuiu com o cair da noite. Não foi uma maldição revelada nem uma floresta inteira silenciada. Elyrien apenas percebeu que os sons familiares se tornavam mais espaçados.

Ela ergueu o olhar para as árvores.

**ELYRIEN —** Amanhã vamos verificar a trilha onde a flecha caiu. Ainda pode haver fragmentos. E quero ouvir os vigias que estavam do outro lado da casa.

**NERIS —** Você acha que voltarão?

**ELYRIEN —** Não sei.

A resposta saiu firme.

A guardiã tocou a pequena folha onde as três marcas estavam desenhadas.

**ELYRIEN —** Mas sabemos um pouco mais do que ontem. E vamos lembrar exatamente o que foi descoberto.

Não havia mensagem enviada a Três Arcos.

Lucas não recebera notícia alguma.

O mundo guardava seus segredos por caminhos que ainda precisavam ser percorridos.

---

## XII — Uma casa grande demais para um homem e pequena demais para os amigos

**DIA 541 · 20h27 — TORRE DO CRIADOR, SALÃO SUSPENSO DO P18**

Quando Lucas chamou os amigos para conhecer a parte alta da torre, Brannik apareceu carregando três ferramentas, um conjunto de anotações e a firme convicção de que todos os experimentos deveriam acontecer imediatamente.

Dorek confiscou duas das ferramentas na entrada.

**BRANNIK —** NÃO SE PODE ENTRAR NA CASA DE UM INVENTOR DESARMADO DE IDEIAS!

**DOREK —** Você não está desarmado de ideias. Está desarmado de uma chave que eu não autorizei.

**BRANNIK —** ISSO É PERSEGUIÇÃO TECNOLÓGICA!

Lysa chegou depois de concluir sua tarde com registros e responsabilidades econômicas. Kael havia saído de uma conversa com representantes civis. Nenhum deles abandonara as próprias funções para passar o dia aplaudindo Lucas.

Varo apareceu quando seus assuntos com a Legião permitiram. Sua presença na reunião não significava que já tivesse deixado o comando militar ou assumido de fato a presidência de um tribunal.

Miren, por sua vez, voltara de AERÚN porque desejava estar ali naquela noite.

Ela avisara que permaneceria com as medições e os registros no dia seguinte.

Lucas não exigira outra coisa.

A mesa estava posta.

Pão, frutas, pratos simples, alimentos preparados por mãos humanas e alguns utensílios estranhamente modernos apareciam diante de cadeiras que pareciam feitas para receber um conselho de aventureiros profundamente indisciplinado.

Nenhum banquete havia sido arrancado à despensa pública.

Aquela era a primeira refeição oferecida por Lucas em sua casa particular.

**LUCAS —** SENHORAS E SENHORES! BEM-VINDOS À MAIS GLORIOSA RESIDÊNCIA QUE UMA PESSOA HUMILDE JÁ CONSTRUIU!

**LYSA —** Você vai perder a palavra “humilde” por uso indevido.

**KAEL —** Não tinha mais direito a ela desde o terceiro andar.

**VARO —** Talvez desde a fundação.

**BRANNIK —** EU ACHO QUE ELE DEVERIA CONSTRUIR MAIS UMA TORRE!

**DOREK —** Não.

Lucas levou a mão ao peito.

**LUCAS —** Vocês vieram jantar na minha casa ou realizar meu julgamento?

**VARO —** Considerando que estamos na sua casa, não seria uma sede apropriada para um tribunal.

Kael olhou para Varo.

Depois para Lucas.

Os dois começaram a rir.

**LUCAS —** ATÉ A JUSTIÇA AINDA NÃO INAUGURADA ME PERSEGUE!

Miren beijou-lhe o rosto ao passar.

**MIREN —** Sente-se antes que a comida esfrie.

Ele obedeceu imediatamente.

*【NÓX — O fundador acaba de demonstrar sua verdadeira cadeia de comando.】*

**LUCAS —** NÓX!

*【SISTEMA — Observação consistente com registros anteriores.】*

**LUCAS —** EU VOU DESLIGAR OS DOIS!

*【NÓX — Você não dispõe de um botão para desligar a sua esposa.】*

A mesa explodiu em gargalhadas.

Lucas esperou que o riso diminuísse. Tinha preparado um discurso. Um discurso extraordinário, com frases que, em sua opinião, deveriam ser gravadas em pedra.

Mas, olhando os amigos, percebeu que não precisava dele.

**LUCAS —** Eu… queria agradecer.

O silêncio veio sem constrangimento.

**LUCAS —** Não por vocês estarem aqui para ver o que fiz. Isso eu faria sozinho, se fosse preciso. E provavelmente faria muito mais barulho.

**BRANNIK —** PROVAVELMENTE!

Lucas sorriu.

**LUCAS —** Quero agradecer porque nenhum de vocês virou extensão da minha vontade. Kael ainda discute comigo. Lysa ainda me pergunta de onde vem o dinheiro. Dorek ainda acha metade das minhas ideias perigosas. Brannik continua provando que Dorek tem motivos para se preocupar.

**DOREK —** Finalmente um reconhecimento formal.

**LUCAS —** Varo continua dizendo coisas difíceis que eu preciso ouvir. Miren continua escolhendo sua própria vida. Rumo cria coisas que não me deve. E NÓX…

A voz na sala se manteve quieta.

Lucas ergueu os olhos.

**LUCAS —** NÓX poderia ter dito não a esta casa. Mas aceitou experimentar a ideia de estar comigo aqui também.

*【NÓX — Continuo considerando a decisão reversível.】*

**LUCAS —** E é por isso que ela significa alguma coisa.

Varo ergueu sua taça.

**VARO —** Então brindemos a uma casa que não exige lealdade de quem entra.

**KAEL —** E a um fundador que aprendeu a não se considerar a resposta para todas as perguntas.

**LYSA —** Aprendeu?

**MIREN —** Está estudando.

Todos brindaram.

Lucas ergueu a taça por último.

**LUCAS —** A vocês.

E, por alguns instantes, não houve salões monumentais, impérios distantes ou tecnologias capazes de mudar a história.

Houve pessoas dividindo a mesa.

Algumas rindo.

Outras apenas felizes por estarem ali.

A torre não precisava de um trono.

Precisava exatamente daquilo.

---

## XIII — O homem da Terra e o horizonte de dois mundos

**DIA 541 · 22h06 — TORRE DO CRIADOR, P22 · OBSERVATÓRIO DO HORIZONTE**

A maioria dos convidados já havia descido.

Kael e Lysa se despediram para retomar os próprios compromissos na manhã seguinte. Varo retornaria aos assuntos da Legião. Brannik partiu levando uma autorização escrita de Lucas para estudar um dos protótipos — e Dorek levou a folha consigo para garantir que ninguém confundisse autorização de estudo com permissão de explodir coisas.

Rumo não ficara para o jantar inteiro. Despedira-se quando quis, depois de olhar uma última vez a garagem.

Ninguém o impedira.

O observatório estava quase silencioso.

A cúpula de cristal podia se abrir ao céu. Estrelas atravessavam a noite. Num dos lados, um grande mapa físico da Terra estava preso à parede, recriado segundo o que Lucas lembrava. Não era um portal. Não era promessa de viagem. Era um mapa.

A cidade de Três Arcos brilhava abaixo.

A antiga.

A nova.

E as estradas entre as duas.

Lucas entrou sozinho.

Havia escolhido os aposentos do vigésimo pavimento para si. As portas do vigésimo primeiro permaneciam com ambientes compartilhados disponíveis e um espaço de trabalho que Miren poderia aceitar, modificar ou recusar quando quisesse.

A Casa do Jardim Branco continuava a existir, intacta, com sua história própria.

Lucas podia ser um dos primeiros residentes permanentes do Horizonte Aberto sem exigir que qualquer outra pessoa abandonasse uma casa amada.

Ele tocou o vidro do observatório.

E a voz de NÓX surgiu, não dos sensores da casa, mas da armadura que o acompanhara até ali.

*【NÓX — Você não está olhando a torre. Está olhando muito além dela.】*

**LUCAS —** Hoje eu pensei na Terra.

*【NÓX — Percebi quando você ficou quieto diante do telefone.】*

**LUCAS —** Você percebe coisas demais.

*【NÓX — Você fala alto demais. É uma combinação eficiente.】*

Lucas sorriu.

Depois ficou sério.

**LUCAS —** Sabe o que é estranho? Eu achava que, se um dia tivesse poder suficiente, ia conseguir tornar tudo perfeito. Não ter medo de perder nada. Não sentir falta de nada. Não precisar de ninguém.

*【NÓX — E conseguiu?】*

**LUCAS —** Não.

Ele soltou uma pequena risada.

**LUCAS —** Graças a todos os céus, não.

A porta se abriu.

Miren apareceu com uma manta dobrada sobre o braço.

**MIREN —** Você continua esquecendo que faz frio no alto.

Lucas apontou para os cristais.

**LUCAS —** Eu poderia regular a temperatura do observatório inteiro.

**MIREN —** Poderia. Mas trouxe uma manta.

Ela se aproximou e a colocou sobre os ombros dele.

Lucas a puxou para perto.

**LUCAS —** Ficou feliz com a torre?

**MIREN —** Fiquei feliz com você.

Ele olhou para ela.

**MIREN —** E com o fato de ter feito uma coisa pessoal sem tentar transformar sua vontade numa obrigação para os outros.

Lucas encostou a testa na dela.

**LUCAS —** O quarto do vigésimo primeiro pavimento…

**MIREN —** Ainda não decidi.

**LUCAS —** Eu sei.

**MIREN —** Talvez eu queira um estúdio lá. Talvez continue preferindo a Casa do Jardim Branco por mais algum tempo. Talvez use as duas.

**LUCAS —** Qualquer uma dessas opções me parece excelente.

Ela sorriu.

**MIREN —** Você quer mesmo a minha resposta?

**LUCAS —** Mais do que qualquer outra.

Miren o beijou longamente.

**MIREN —** Minha resposta é que esta noite quero ficar aqui com você.

Aquelas palavras fizeram a torre inteira parecer pequena demais para conter o que Lucas sentiu.

Ele a abraçou com força.

Não como alguém que capturara a decisão de outra pessoa.

Como alguém que recebera uma escolha livre.

**LUCAS —** Então esta noite o observatório tem a melhor vista do mundo.

**MIREN —** A cidade?

**LUCAS —** Não.

Ele olhou para ela.

Miren riu baixinho e o beijou outra vez.

Atrás deles, o céu se iluminou com o rastro distante de uma estrela cadente.

Lucas acompanhou seu caminho até desaparecer.

*【SISTEMA — Registro do Capítulo 1: três marcos urbanos e uma criação pessoal concluídos.】*

**LUCAS —** Você vai me dar uma nota?

*【SISTEMA — Não há avaliação universal apropriada para pertencimento.】*

Lucas piscou.

Pela primeira vez, não tinha uma resposta espirituosa.

*【NÓX — O silêncio também é histórico. Recomendo preservá-lo.】*

Miren se encostou ao peito dele.

Abaixo, o Horizonte Aberto estava pronto para receber histórias que ainda não existiam.

As quarenta mil moradias não haviam sido preenchidas por magia. A população de cem mil permanecia uma capacidade futura. As novas instituições ainda precisariam trabalhar para merecer a confiança que sua arquitetura prometia. As máquinas teriam de ser mantidas, os hospitais precisariam de profissionais, as crianças de escolas e os recém-chegados de acolhimento real.

Longe dali, uma guardiã examinava marcas num cilindro sem origem confirmada.

Nas montanhas, um príncipe anão mantinha uma viga no lugar enquanto seu povo reconstruía uma passagem.

Outros homens e mulheres, desconhecidos de Lucas, continuavam a fazer escolhas que um dia poderiam alcançar Três Arcos — por caminhos e tempos que ainda não tinham sido percorridos.

O mundo não havia parado por causa da torre.

E essa era, talvez, a melhor parte.

Lucas olhou sua casa.

A marca pessoal brilhava acima deles: o traço ascendente, o halo aberto, a centelha suspensa.

Não era uma coroa.

Não era uma bandeira de conquista.

Era um endereço.

**LUCAS —** NÓX?

*【NÓX — Sim, Lucas?】*

**LUCAS —** Acho que estou em casa.

A resposta veio sem sarcasmo.

*【NÓX — Eu também.】*

Miren apertou-lhe a mão.

O fundador ergueu os olhos às estrelas.

E, naquele instante, compreendeu que sua maior criação não era uma torre capaz de tocar o céu.

Era a possibilidade de olhar para o impossível e, mesmo assim, encontrar alguém com quem dividir a vista.

**FIM DO CAPÍTULO 1 — O CRIADOR E A CIDADE DAS MIL FONTES**

*Três Arcos tinha um horizonte. O Criador tinha um lar. E, pelas estradas ainda distantes, o mundo começava a caminhar na direção de histórias que nenhum deles poderia escrever sozinho.*

---

<box border radius="lg" padding={3} gap={2}>
  <text color="secondary" size="xs" weight="medium">WORLDROOT · CHECKPOINT NARRATIVO · RASCUNHO ARQUIVADO</text>
  <grid columns={2} gap={2}>
    <grid-item>
      <text color="secondary" size="xs">Última cena</text>
      **Dia 541 · 22h06**
    </grid-item>
    <grid-item>
      <text color="secondary" size="xs">Local</text>
      **Torre do Criador · Observatório P22**
    </grid-item>
    <grid-item>
      <text color="secondary" size="xs">Capítulo</text>
      **1 encerrado · Parte V de V**
    </grid-item>
    <grid-item>
      <text color="secondary" size="xs">Próxima etapa</text>
      **Capítulo 2 · Parte I de V**
    </grid-item>
  </grid>
  **Conquistas narradas:** terreno particular adquirido e registrado legitimamente; Torre do Criador V3 materializada no Horizonte Aberto com 145 m, 22 pavimentos, três subsolos e 31.000 m² internos; Aerodoca do Impossível externa de 70 m e deck de 550 m², sem pousos; garagem com modelos da Terra recriados, Sala da Terra, Galeria do Caminho Compartilhado e oficinas; Rede Doméstica não consciente, conexão voluntária e reversível da armadura viva NÓX; 96 autômatos privados operacionais, sem alterar a Malha municipal; Lucas passa a ter sua residência pessoal no distrito.

  **Autonomias e limites preservados:** Miren não foi obrigada a mudar; a Casa do Jardim Branco permanece; a Torre não pertence ao governo nem o substitui. O SISTEMA não se fundiu a NÓX. Os ambientes reservados não recebem vigilância compulsória. ARGOS permanece no Campo Aurora e o projeto ASA LIVRE ainda não foi construído. As imagens da galeria distinguem fatos de reconstruções.

  **Outras tramas:** Tharvek investiga três incisões numa passagem anã avariada; Elyrien e Neris identificam marcas minúsculas no cilindro sem comprovar procedência. Nenhum deles recebeu notícias imediatas de Três Arcos. Caedren permanece com afiliação e trajeto não comprovados desde a cena D539.

  <text color="secondary" size="xs">Este episódio é o rascunho arquivado da Parte V. A escolha seguinte poderá autorizar sua promoção; não encerra o Livro VI.</text>
</box>

## As cinco portas do Capítulo 2

<box gap={3}>
  <box gap={2}>
    **1 — As primeiras vozes além das muralhas**

    Notícias avançam pelas estradas no tempo que lhes cabe. Testemunhas e caravanas começam a trazer às portas de Três Arcos perguntas sobre a Cidade Livre e seu fundador.
    <button block variant="outline" color="primary" onClick={() => GenUI.issueNewTurn("WORLDROOT — Livro VI, Capítulo 2, Parte I de V. Escolho a opção 1: As primeiras vozes além das muralhas. Validar e fechar só a Parte V D541 anterior, preservar todas as cenas e arquivar a próxima como draft integral verificado no GitHub.")}>Escolher opção 1</button>
  </box>
  <box gap={2}>
    **2 — O céu exige uma primeira prova**

    ARGOS, Naira e a Forja enfrentarão as questões reais da Aerodoca, com oportunidade de invenção, riscos técnicos e humor. ASA LIVRE continua projeto original futuro.
    <button block variant="outline" color="primary" onClick={() => GenUI.issueNewTurn("WORLDROOT — Livro VI, Capítulo 2, Parte I de V. Escolho a opção 2: O céu exige uma primeira prova. Respeitar teste futuro ARGOS, autonomia de Naira e preservação da Torre; verificar e arquivar GitHub.")}>Escolher opção 2</button>
  </box>
  <box gap={2}>
    **3 — As marcas na pedra e no metal**

    As pistas de Tharvek, Elyrien e as pesquisas de Miren e Astra ganham espaço com descobertas próprias, sem confundir mistérios ou compartilhar segredos à distância.
    <button block variant="outline" color="primary" onClick={() => GenUI.issueNewTurn("WORLDROOT — Livro VI, Capítulo 2, Parte I de V. Escolho a opção 3: As marcas na pedra e no metal. Respeitar fontes, conhecimento, localização, três descobertas independentes e continuação GitHub.")}>Escolher opção 3</button>
  </box>
  <box border radius="lg" padding={3} gap={2}>
    <row align="center" gap={2}>
      <icon name="sparkles"/>
      **4 — ESPECIAL: O mundo começa a procurar o impossível**
    </row>
    Uma abertura épica com Três Arcos, a vida na Torre, notícias que levam tempo, pistas de espionagem, campeões, os conflitos anões e élficos e a pesquisa de AERÚN, sem forçar encontros nem resultados.
    <button block color="primary" onClick={() => GenUI.issueNewTurn("WORLDROOT — Livro VI, Capítulo 2, Parte I de V. Escolho a opção 4 ESPECIAL: O mundo começa a procurar o impossível. A partir da Parte V D541, manter GÊNESE plena, todas as criações, narrativa extensa e acontecimentos independentes, fechar anterior apenas após validação e arquivar novo draft no GitHub.")}>Escolher especial 4</button>
  </box>
  <box gap={2}>
    **5 — AÇÃO LIVRE**

    <textarea rows={3} value={acaoC2} onChange={setAcaoC2} disabled={false} placeholder="Descreva a decisão de Lucas ou a direção que deseja para o Capítulo 2..."/>
    <button block variant="outline" disabled={!acaoC2.trim()} onClick={() => GenUI.issueNewTurn("WORLDROOT — Livro VI, Capítulo 2, Parte I de V. Escolho a opção 5, AÇÃO LIVRE: " + acaoC2 + ". Verificar Parte V D541, fechar apenas episódio anterior, arquivar nova história integral no GitHub e preservar política editorial v14.")}>Confirmar ação livre</button>
  </box>
</box>